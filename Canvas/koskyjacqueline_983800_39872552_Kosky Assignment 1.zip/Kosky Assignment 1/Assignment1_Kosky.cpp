#include <iostream>
#include <string>
#include <sstream>
using namespace std;


struct Node
{
    string data;
    struct Node *next;
};

struct Node* head = NULL;

struct Node* newNode(void);
void insertString(struct Node*,string,int);
void insertEnd(struct Node*, string);
void deleteString(struct Node*,int);
void editString(struct Node*,string, int);
void print(struct Node*);
void searchString(struct Node*,string);




int main()
{
    string inputFunction;
    string insertedString;
    string searchedString;
    string editedString;
    string pos;
    int position;
    stringstream inputFun;

    while (1) {
        getline(cin, inputFunction);
        if (inputFunction == "print") {
            print(head);
        } else if (inputFunction == "quit") {
            break;
        } else if (inputFunction.substr(0, 6) == "search") {
            searchedString = inputFunction.substr(8);
            searchedString.pop_back();
            searchString(head, searchedString);
        } else if (inputFunction.substr(0, 9) == "insertEnd") {
            insertedString = inputFunction.substr(11);
            insertedString.pop_back();
            insertEnd(head, insertedString);
        } else if (inputFunction.substr(0, 6) == "insert") {
            insertedString = inputFunction.substr(10);
            insertedString.pop_back();
            pos = inputFunction.substr(7, 1);
            inputFun << pos;
            inputFun >> position;
            inputFun.clear();
            insertString(head, insertedString, position-1);
        } else if (inputFunction.substr(0, 4) == "edit") {
            editedString = inputFunction.substr(8);
            editedString.pop_back();
            pos = inputFunction.substr(5, 1);
            inputFun << pos;
            inputFun >> position;
            inputFun.clear();
            editString(head, editedString, position-1);
        } else if (inputFunction.substr(0, 6) == "delete") {
            string pos = inputFunction.substr(7, 1);
            inputFun << pos;
            inputFun >> position;
            inputFun.clear();
            deleteString(head, position);
        } else if (inputFunction.substr(0, 5) == "print") {
            print(head);
            break;
        } else {
            std::cout << "Error: invalid input";
        }
    }
}

struct Node* newNode(string stringInput)
{
    struct Node* node = new Node;
    node->data=stringInput;
    node->next=NULL;
    return(node);
}

void insertString(struct Node* node, string stringInput, int index)
{
    struct Node* prev = NULL;
    struct Node* addNode = newNode(stringInput);
    for (int i=0;i<index;i++) {
        prev = node;
        node = node->next;
    }
    if (prev == NULL) {
        addNode->next = head;
        head = addNode;
    }
    else {
        addNode->next = node;
        prev->next = addNode;
    }
}

void editString(struct Node* node, string stringInput, int index)
{
    int i=1;
    for (int i; i<index; i++)
    {
        node = node->next;
    }
    node->data = stringInput;
}

void insertEnd(struct Node* node, string stringInput)
{
    struct Node* addNode;
    addNode = newNode(stringInput);

    if(head == NULL)
    {
        head=addNode;
    }
    else {
        while (node->next != NULL) {
            node = node->next;
        }
        node->next = addNode;
    }

}

void searchString(struct Node* node, string searchedString)
{
    int index=1;
    int count=0;
    while (node)
    {
        if (node->data.find(searchedString) != -1)
        {
            cout << index << " " << node->data << endl;
            count=1;
        }
        index++;
        node=node->next;
    }
    if(count!=1) {
        cout << "not found" << endl;
    }
}

void print(struct Node* node)
{
    int index = 1;
    while (node)
    {
        std::cout << index << " " << node->data << std::endl;
        node=node->next;
        index++;
    }
}

void deleteString(struct Node* node, int index)
{
    struct Node* prev = NULL;
    struct Node* temp;
    for (int i=1; i<index; i++) {
        prev = node;
        node = node->next;
    }
    if (prev==NULL) {
        temp=node;
        head=head->next;
    }
    else {
        temp=node;
        prev->next=node->next;
    }
    delete temp;
}