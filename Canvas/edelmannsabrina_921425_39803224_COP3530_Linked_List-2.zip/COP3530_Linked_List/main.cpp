#include <iostream>
#include "Linked_List.h"
using namespace std;

int main()
{
    //Limit the amount of user input to 80 characters
    char userInput[80];
    string input;
    string commandString;

    //Ask the user for the list of commands
    //cout << "Enter list of commands:" << endl;

    //Grab each command from the user and store into a string
    while (getline(cin, commandString) && !commandString.empty())
    {
        input += commandString + "\n";
    }

    //Parse the input string and create a list based off each new line command
    List *inputList = new List;
    int posOfNewLine;
    while (input.compare(""))
    {
        posOfNewLine = input.find("\n");
        inputList->insertEnd(input.substr(0,posOfNewLine));
        input = input.substr(posOfNewLine+1, input.size()-1);
    }

    //Create the list that holds all phrases
    List *myList = new List;

    //Variables that will help parse the string
    int posOfFirstSpace;
    int posOfFirstQuote;
    int posOfLastQuote;
    string command = "";
    string index = "";
    string phrase = "";

    int listIndex;
    Node *current = inputList->head;

    //While the input list is not empty, continue to run the user inputs
    while(!inputList->isEmpty())
    {
        //set input to the current node's data
        input = current->data;
        //find the position of the first space in the input
        posOfFirstSpace = input.find(" ");
        //extract the command from the input
        command = input.substr(0,posOfFirstSpace);

        //if the command is insert
        if (!command.compare("insert"))
        {
            //extract the index and the phrase from the input
            index = input.substr(posOfFirstSpace, input.size()-1);
            posOfFirstQuote = index.find("\"");
            input = input.substr(posOfFirstQuote+1, input.size()-1);
            posOfLastQuote = input.find("\"");

            phrase = index.substr(posOfFirstQuote+1,index.size()-5);
            index = index.substr(1, posOfFirstQuote - 2);
            //convert the index from a string to an int
            listIndex = stoi(index);

            //insert the phrase at the given index in the list
            myList->insert(listIndex, phrase);
            current = current->next;
            continue;
        }
        //if the command is edit
        else if (!command.compare("edit"))
        {
            //extract the index and the phrase from the input
            index = input.substr(posOfFirstSpace, input.size()-1);
            posOfFirstQuote = index.find("\"");
            input = input.substr(posOfFirstQuote+1, input.size()-1);
            posOfFirstSpace = input.find(" ");

            phrase = index.substr(posOfFirstQuote+1,index.size()-5);
            index = index.substr(1, posOfFirstQuote - 2);
            //convert the index from a string to an int
            listIndex = stoi(index);

            //edit the phrase at the given location in the list
            myList->edit(listIndex, phrase);
            current = current->next;
            continue;
        }
        //if the command is to insert at the end or search
        else if (!command.compare("insertEnd") || !command.compare("search"))
        {
            //extract the index from the input
            index = input.substr(posOfFirstSpace, input.size()-1);
            posOfFirstQuote = index.find("\"");
            input = input.substr(posOfFirstQuote+1, input.size()-1);
            posOfLastQuote = input.find("\"");

            phrase = index.substr(posOfFirstQuote+1,index.size()-3);

            //if the user would like to insert at the end
            if (!command.compare("insertEnd"))
            {
                //add the phrase to the end of the list
                myList->insertEnd(phrase);
                current = current->next;
                continue;
            }
            //if the user would like to search for a phrase
            else
            {
                myList->search(phrase);
                current = current->next;
                continue;
            }
        }
        //if the command is to delete
        else if (!command.compare("delete"))
        {
            //extract the index from the input
            index = input.substr(input.size()-2, input.size()-1);
            //convert the index string to an int
            listIndex = stoi(index);

            //delete the phrase at the given position
            myList->deleteAt(listIndex);
            current = current->next;
            continue;
        }
        else
        {
            if (!command.compare("print"))
            {
                //user asks to print the list
                myList->print();
                current = current->next;
                continue;
            }
            else
            {
                //user asks to quit
                exit(0);
            }
        }
    }
}