//
// Created by ssjed on 9/16/2018.
//

#ifndef COP3530_LINKED_LIST_LINKED_LIST_H
#define COP3530_LINKED_LIST_LINKED_LIST_H

#include <string>
#include <iostream>
using namespace std;

//Node struct to be used in linked list class
struct Node
{
    //node holds data and pointer to next node
    string data;
    Node *next;
};

//Class list which is the linked list data structure
class List
{
public:
    //pointer to head and tail of the linked list
    Node *head, *tail;
    //size of the linked list
    int size;
    //list methods
    List();
    void print();
    void insert(int position, string value);
    void insertEnd(string value);
    void deleteAt(int position);
    void edit(int position, string value);
    void search(string value);
    bool isEmpty();
};

//List constructor
List::List()
{
    //sets everything to null when a new list is created
    head = NULL;
    tail = NULL;
    size = 0;
}

//Method that prints the linked list
void List::print()
{
    Node *temp = head;
    int position = 1;
    //loop to iterate through the linked list and print each node
    while (temp != NULL)
    {
        cout << position << " " << temp -> data << "\n";
        temp = temp -> next;
        position ++;
    }
    return;
}

//Method that inserts a node at a specific position in the linked list
void List::insert(int position, string value)
{
    //If the position is larger than the size of the list
    if (position > size + 1)
    {
        //do not insert the node into the list
        return;
    }
    //If the position is at the end of the list
    else if (position == size + 1)
    {
        //Insert the node at the tail of the list
        Node *temp = new Node;
        temp -> data = value;
        temp -> next = NULL;

        tail -> next = temp;
        tail = temp;
    }
    //Else insert the node at the given position
    else
    {
        Node *prev = new Node;
        Node *temp = new Node;
        Node *curr = head;

        //loop through the list to find the posiiton where we want to insert
        for (int i = 1; i < position; i++)
        {
            prev = curr;
            curr = curr->next;
        }

        temp->data = value;
        prev->next = temp;
        temp->next = curr;
    }
    //increase the size of the list
    size++;
    return;
}

//Method that inserts the new node at the end of the list
void List::insertEnd(string value)
{
    Node *temp = new Node;
    temp -> data = value;
    temp -> next = NULL;

    //If there is no head, make the new node the head
    if (head == NULL)
    {
        head = temp;
        tail = temp;
    }
    //else insert the node at the end of the list
    else
    {
        tail -> next = temp;
        tail = temp;
    }
    size++;
    return;
}

//Method to delete a node in the linked list at a given position
void List::deleteAt(int position)
{
    //If the position is not in the list
    if (position > size)
    {
        //do not so anything
        return;
    }

    Node *prev = new Node;
    Node *curr = head;

    //if the position is the head of the list
    if (position - 1 == 0)
    {
        head = head -> next;
        delete curr;
    }
    //else loop through the list to find the position and delete the node
    else
    {
        for (int i = 1; i < position; i++)
        {
            prev = curr;
            curr = curr -> next;
        }
        prev -> next = curr -> next;
        delete curr;
    }
    //decrement the size of the list
    size--;
    return;
}

//Method to edit the value in a node at a given position
void List::edit(int position, string value)
{
    int index = 1;
    Node *curr = head;
    //If the position is not in the list
    if (position > size)
    {
        //do not do anything
        return;
    }
    else if (!isEmpty())
    {
        //loop through to find the node
        while (index < position)
        {
            curr = curr -> next;
            index++;
        }
        //if the node is found, set the value to the new value
        if (index == position)
        {
            curr -> data = value;
        }
    }
    return;
}

//Method to search the list for a value
void List::search(string value)
{
    Node *curr = head;
    int index = 1;
    bool found = false;

    if (!isEmpty())
    {
        //loop to find all values specified in the list
        while (curr != NULL)
        {
            //print the value and index when found
            if ((curr -> data).find(value) != std::string::npos)
            {
                cout << index << " " << curr -> data << endl;
                found = true;
            }
            curr = curr -> next;
            index++;

        }
    }
    //if the value is not found, print not found
    if (!found)
    {
        cout << "not found" << endl;
    }
    return;
}

//Method to check if the list is empty
bool List::isEmpty()
{
    if (head == NULL)
    {
        return true;
    }
    else
    {
        return false;
    }
}

#endif //COP3530_LINKED_LIST_LINKED_LIST_H
