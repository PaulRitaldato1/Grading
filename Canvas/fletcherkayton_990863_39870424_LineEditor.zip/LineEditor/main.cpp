
#include <string>
#include <iostream>

class Document
{
    struct Line
    {
        std::string lineText;
        Line* next;
        int index;
        Line()
        {
            lineText = "";
            next = nullptr;
            index = 0;
        }
    };
    const unsigned int maxLength = 80;
    Line* head;
    Line* tail;
    int size;
public:
    Document();
    void insertLine(std::string newLine, int index);
    void insertEnd(std::string newLine);
    void deleteLine(int index);
    void editLine(std::string, int index);
    void printDocument();
    void searchText(std::string searchString);
    void setTail(std::string*);
    ~Document();
};


Document::Document()
{
    head = nullptr;
    tail = nullptr;
    size = 0;
}
void Document::setTail(std::string *newLine)
{
    Line* temp = new Line;
    size++;
    temp->index = size;
    temp->lineText = *newLine;
    tail->next = temp;
    tail = tail->next;
    tail->next = nullptr;
}
void Document::insertEnd(std::string newLine)
{
    //initial conditions to catch if poor input is entered
    if(newLine.length() > maxLength || newLine.empty()) return;

    if (head == nullptr) //If the document has no head
    {
        size++;
        head = new Line;
        head->lineText = newLine;
        head->index = 1; //head always has index of 1
        head->next = nullptr;
        tail = head;
        return;
    }
    setTail(&newLine);
}
void Document::insertLine(std::string newLine, int index)
{
    //initial conditions to catch if poor input is entered
    if(newLine.length() > maxLength || index > size + 1 || index < 1 || newLine.empty()) return;

    Line* current = head;
    Line* previous = head;


    int i = 1;
    if(index == size+1)
    {
        insertEnd(newLine); //adding to end of list
        return;
    }
    while(i != index) //goes until index is reached, to insert in middle of list
    {
        previous = current;
        current = current->next;
        i++;
    }
    if(index == 1) //condition for head insertion
    {
        current = new Line;
        current->lineText = newLine;
        current->index = index;
        current->next = head;
        head = current;

    } else if(i == index) //insertion in middle of list
    {
        current = new Line;
        current->lineText = newLine;
        current->index = index;
        current->next = previous->next;
        previous->next = current;
    }
    size++;
    while(current->next != nullptr) //reorders rest of document, if line not inserted at end
    {
        current = current->next;
        i++;
        current->index = i;
    }
}
void Document::deleteLine(int index)
{
    if(index > size || index < 1) return;

    Line* current = head;
    Line* previous = head;

    int i = 1;
    for(i = 1; i < index; i++)
    {
        previous = current;
        current = current->next;
    }

    if(index == size && index != 1) //deleting tail
    {
        previous->next = nullptr;
        tail = previous;
        delete current;
        size--;
        return;
    }

    if(index == 1)
    {
        if(current->next == nullptr) //check to see if list will be empty after deletion of head
        {
            delete current;
            head = nullptr;

        } else
        {
            head = current->next;
            delete current;
            current = head;
        }
    } else if(index == i) //deleting within list, must repair link
    {
        previous->next = current->next;
        delete current;
        current = previous->next;
    }
    size--;
    while(current != nullptr) //re-indexes document
    {
        current->index = index;
        current = current->next;
        index++;
    }
}
void Document::searchText(std::string searchString)
{
    if(searchString.empty()) return;

    bool found = false;
    Line* current = head;
    while(current != nullptr)
    {
        if(current->lineText.find(searchString) != std::string::npos)
        {
            std::cout << current->index << " " << current->lineText << std::endl;
            found = true;
        }
        current = current->next;
    }
    if(!found)
    {
        std::cout << "not found" << std::endl;
    }
}
void Document::printDocument()
{
    if(head != nullptr)
    {
        Line* current = head;
        while(current != nullptr)
        {
            std::cout << current->index << " " << current->lineText << std::endl;
            current = current->next;
        }
    }
}
void Document::editLine(std::string newLine, int index)
{
    //initial conditions to catch if poor input is entered
    if(head == nullptr || index > size || newLine.length() > maxLength || index < 1) return;
    Line* current = head;

    for(int i = 1; i < index; i++)
    {
        current = current->next;
    }
    current->lineText = newLine;
}
Document::~Document()
{
    Line* current = head;
    while(current != nullptr)
    {
        Line* next = current->next;
        delete current;
        current = next;
    }
    head = nullptr;
}






int findNumber(std::string response)
{
    int i = 0;
    bool digitFound = false;
    std::string number;
    while(i < response.length() && !digitFound)
    {
        while(i < response.length() && std::isdigit(response[i])) //concatenates consecutive integers
        {
            if(response[i-1] == '-' && !digitFound) number = "-"; //accounts for a negative number
            number += response[i];
            digitFound = true;
            i++;
        }
        i++;
    }
    if(digitFound) return std::stoi(number);
    else return -1; //functions will check if index is less than zero when index is input
}
std::string getSubstring(std::string response)
{
    
    const char myChar = '"';
    unsigned long firstQuote = 0;
    unsigned long secondQuote = 0;
    if(response.find(myChar) == std::string::npos) return std::string(); //returns empty string which function will check for
    firstQuote = response.find(myChar);
    if(response.find(myChar, firstQuote + 1) == std::string::npos) return std::string();
    secondQuote = response.find(myChar, firstQuote + 1);
    response = response.substr(firstQuote + 1, secondQuote - firstQuote - 1); //gets substring starting at the position after first double quote
    return response;
}

int main() {
    std::string response;
    Document document;
    while(response != "quit")
    {
        std::getline(std::cin, response);
        if (response.find("insertEnd") != std::string::npos)
        {
            document.insertEnd(getSubstring(response));
        } else if(response.find("insert") != std::string::npos)
        {
            document.insertLine(getSubstring(response), findNumber(response));
        } else if(response.find("delete") != std::string::npos)
        {
            document.deleteLine(findNumber(response)); //returns an integer and passes it to delete line
        } else if(response.find("print") != std::string::npos)
        {
            document.printDocument();
        } else if(response.find("search") != std::string::npos)
        {
            document.searchText(getSubstring(response));
        } else if(response.find("edit") != std::string::npos)
        {
            document.editLine(getSubstring(response), findNumber(response));
        }
        std::cin.clear();
    }
    return 0;
}