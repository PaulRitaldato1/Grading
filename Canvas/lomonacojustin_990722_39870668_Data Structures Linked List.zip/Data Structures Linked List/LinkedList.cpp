#include "stdafx.h"
#include "LinkedList.h"
#include <iostream>
#include <string>

//Linked list constructor
LinkedList::LinkedList()
{
	head = NULL;
	current = NULL;
	temp = NULL;
}

//Adds a line to the linked list
void LinkedList::insertEnd(std::string text)
{
	Node n = new node;
	n->next = NULL;
	n->text = text;

	if (head == NULL)
	{
		head = n;
	}
	else
	{
		current = head;
		while (current->next != NULL)
		{
			current = current->next;
		}

		current->next = n;
	}
}

//Removes a line from the linked list
void LinkedList::removeNode(int id)
{
	current = head;
	temp = head;
	int count = 1;
	if (count == id)
	{
		head = head->next;
		delete(current);
		return;
	}

	while (current != NULL && count != id)
	{
		temp = current;
		current = current->next;
		count++;
	}


	if (current != NULL)
	{
		temp->next = current->next;
		delete(current);
	}

}

//Searches for a line from the linked list
void LinkedList::searchNode(std::string text)
{
	current = head;
	temp = head;

	int count = 1;
	if (head->text.find(text) != std::string::npos)
	{
		std::cout << count << " " << current->text << std::endl;
		return;
	}

	while (current != NULL && current->text.find(text) == std::string::npos)
	{
		temp = current;
		current = current->next;
		count++;
	}


	if (current != NULL)
	{
		std::cout << count << " " << current->text << std::endl;
	}
	else
	{
		std::cout << "not found" << std::endl;
	}
}

void LinkedList::insertAt(std::string text, int id)
{
	current = head;
	temp = head;
	node* prev = head;

	int count = 1;

	if (id == 1)
	{
		node* n = new node;
		n->text = text;
		head = n;
		n->next = temp;
		return;
	}

	while (current != NULL && count != id)
	{
		current = current->next;

		if (count != 1)
			prev = prev->next;

		count++;
	}


	if (current != NULL)
	{
		node* n = new node;
		n->text = text;
		prev->next = n;
		n->next = current;
	}
}

void LinkedList::edit(int id, std::string text)
{
	current = head;
	temp = head;
	int count = 1;

	if (count == id)
	{
		head->text = text;
		return;
	}

	while (current != NULL && count != id)
	{
		temp = current;
		current = current->next;
		count++;
	}


	if (current != NULL)
	{
		current->text = text;
	}
}

//Prints out each line
void LinkedList::print()
{
	std::cout << std::endl;
	current = head;
	int count = 1;

	if (current == NULL)
		return;
	
	std::cout << count << " " << current->text << std::endl;

	while (current->next != NULL)
	{
		count++;
		current = current->next;
		std::cout << count << " " << current->text << std::endl;
	}
	std::cout << std::endl;
}
