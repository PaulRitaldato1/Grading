#pragma once

#include <iostream>
#include <string>

class LinkedList
{
public:
	LinkedList();

	void insertEnd(std::string text);
	void insertAt(std::string text, int id);
	void edit(int id, std::string text);
	void removeNode(int id);
	void searchNode(std::string text);
	void print();

private:
	typedef struct node
	{
		std::string text;
		node* next;
	}*Node;

	Node head;
	Node current;
	Node temp;
};

