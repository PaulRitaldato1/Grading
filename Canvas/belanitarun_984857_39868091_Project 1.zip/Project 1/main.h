#ifndef PROJECT1_MAIN_H
#define PROJECT1_MAIN_H

template <class T>
struct Node {
    T data;
    Node<T>* next = nullptr;
};

template <class T>
class LinkedList {
private:
    Node<T>* head;
    Node<T>* tail;

public:
    LinkedList<T>();
    void insertEnd(T data);
    void insert(T data, int index);
    void edit(T data, int index);
    void del(int index);
    void search(T data);
    void print();
};

#endif //PROJECT1_MAIN_H