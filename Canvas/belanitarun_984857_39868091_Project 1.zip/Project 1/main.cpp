#include <iostream>
#include <cstring>
#include <algorithm>
#include "main.h"

template <class T>
LinkedList<T>::LinkedList() {
    this->head = nullptr;
    this->tail = nullptr;
}

template <class T>
void LinkedList<T>::insertEnd(T data) {
    auto* insertion = new Node<T>();
    insertion->data = data;
    if (head == nullptr) {
        head = insertion;
        tail = insertion;
    }
    else {
        tail->next = insertion;
        tail = tail->next;
    }
}

template <class T>
void LinkedList<T>::insert(T data, int index) {
    auto* insertion = new Node<T>();
    insertion->data = data;
    if (head == nullptr && index == 1) {
        head = insertion;
        tail = head;
    }
    else {
        int currentIndex = 1;
        auto* curr = head;
        auto* prev = curr;
        while (curr->next != nullptr && currentIndex < index) {
            prev = curr;
            curr = curr->next;
            currentIndex++;
        }
        if (index == 1) {
            head = insertion;
            insertion->next = curr;
        }
        else if (currentIndex == index) {
            prev->next = insertion;
            insertion->next = curr;
        }
        else if (currentIndex + 1 == index) {
            curr->next = insertion;
            tail = insertion;
        }
    }
}

template <class T>
void LinkedList<T>::edit(T data, int index) {
    int currentIndex = 1;
    auto* curr = head;
    while (curr != nullptr && currentIndex < index) {
        currentIndex++;
        curr = curr->next;
    }
    if (curr != nullptr && currentIndex == index) {
        curr->data = data;
    }
}

template <class T>
void LinkedList<T>::del(int index) {
    if (head != nullptr) {
        int currentIndex = 1;
        auto *curr = head;
        auto *prev = new Node<T>();
        while (curr != nullptr && currentIndex < index) {
            currentIndex++;
            prev = curr;
            curr = curr->next;
        }
        if (curr != nullptr && currentIndex == index) {
            auto *tempNode = curr;
            prev->next = curr->next;
            delete tempNode;
        }
    }
}

template <class T>
void LinkedList<T>::search(T data) {
    const std::string &subStr = data;
    auto* curr = head;
    int currentIndex = 1;
    bool stringFound = false;
    while (curr != nullptr) {
        std::string str = curr->data;
        if (str.find(subStr) != std::string::npos) {
            stringFound = true;
            std::cout << currentIndex << " " << str << std::endl;
        }
        currentIndex++;
        curr = curr->next;
    }
    if (!stringFound) {
        std::cout << "not found" << std::endl;
    }
}

template <class T>
void LinkedList<T>::print() {
    Node<T> * curr;
    curr = head;
    int currIndex = 1;
    while (curr != nullptr) {
        std::cout << currIndex << " " << curr->data << std::endl;
        curr = curr->next;
        currIndex++;
    }
}

bool isQuote(std::string str) {
    bool valid = true;
    for (int i = 0; i < static_cast<int>(str.length()); i++) {
        if (i == 0) {
            if (str[0] != '\"') {
                valid = false;
            }
        }
        if (i == static_cast<int>(str.length()) - 1) {
            if (str[static_cast<int>(str.length()) - 1] != '\"') {
                valid = false;
            }
        }
    }
    if (static_cast<int>(str.length()) - 2 > 80) {
        valid = false;
    }
    return valid;
}

bool isNum(const std::string &num) {
    if(num.empty() || ((!isdigit(num[0])) && (num[0] != '-') && (num[0] != '+'))) {
        return false;
    }
    char* p;
    strtol(num.c_str(), &p, 10);
    return (*p == 0);
}

int indexType(const std::string &str) {
    std::string lowerStr = str;
    std::transform(lowerStr.begin(), lowerStr.end(), lowerStr.begin(), ::tolower);
    if (lowerStr == "insertend" || lowerStr == "insert" || lowerStr == "edit" || lowerStr == "delete" || lowerStr == "search" || lowerStr == "print" || lowerStr == "quit") {
        return 0;
    }
    else if (isNum(str)) {
        return 1;
    }
    else if (isQuote(str)){
        return 2;
    }
    return 3;
}

std::string* parseTask(std::string task) {
    auto* parseTask = new std::string[4]; // 0 = command, 1 = line # (if applicable), 2 = text (if applicable), 3 = validity
    parseTask[3] = "";
    int counter = 0;
    std::string currentStr;
    bool isQuote = false;
    for (char c : task) {
        if (c == ' ' && !isQuote) {
            parseTask[indexType(currentStr)] = currentStr;
            currentStr = "";
            counter++;
        }
        else if (c == '\"') {
            currentStr += c;
            isQuote = !isQuote;
        }
        else {
            currentStr += c;
        }
    }
    parseTask[indexType(currentStr)] = currentStr;
    if (!parseTask[2].empty()) {
        std::string newStr;
        for (int i = 1; i < static_cast<int>(parseTask[2].length()) - 1; i++) {
            newStr += parseTask[2][i];
        }
        parseTask[2] = newStr;
    }
    return parseTask;
}

template <class T>
void performTask(std::string* tasks, LinkedList<T>& lineEditor) {
    std::string command = tasks[0];
    std::transform(command.begin(), command.end(), command.begin(), ::tolower);
    int lineNum;
    std::string text = tasks[2];
    try {
        lineNum = std::stoi(tasks[1]);
    }
    catch (std::invalid_argument& ai) {
        lineNum = -1;
    }

    if (command == "insertend" && lineNum == -1 && !text.empty()) {
        lineEditor.insertEnd(text);
    }
    else if (command == "insert" && lineNum > 0 && !text.empty()) {
        lineEditor.insert(text, lineNum);
    }
    else if (command == "edit" && lineNum > 0 && !text.empty()) {
        lineEditor.edit(text, lineNum);
    }
    else if (command == "delete" && lineNum > 0 && text.empty()) {
        lineEditor.del(lineNum);
    }
    else if (command == "search" && lineNum == -1 && !text.empty()) {
        lineEditor.search(text);
    }
    else if (command == "print" && lineNum == -1 && text.empty()) {
        lineEditor.print();
    }
}

int main() {
    LinkedList<std::string> lineEditor;
    while (true) {
        std::string task;
        getline(std::cin, task);
        std::string* parsedTask = parseTask(task);
        if (parsedTask[0] == "quit") {
            break;
        }
        if (parsedTask[3].empty()) {
            performTask(parsedTask, lineEditor);
        }
    }
    return 0;
}