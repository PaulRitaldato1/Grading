//
// Created by Dorian Meade on 9/9/18.
//
#include "Node.h"

LinkedList::LinkedList() //constructor
{
    //initialize linked list
    head = NULL;
    size = 0;
}

void LinkedList::insertEnd(string line)
{
    Node *text = new Node;
    text->data = line;  //string data into node
    text->next = NULL;

    if(head == NULL) //check if linkedlist is empty
    {
        head = text; //add text as the first element
    }
    else //linkedlist is not empty
    {
        Node *curr = head;
        while(curr->next != NULL) //find last node
        {
            curr = curr->next;
        }
        curr->next = text; //add text after the last node
    }
    size++; //increment linkedlist size
    return;
}

void LinkedList::insertAt(int index, string line)
{
    Node *text = new Node;  //string data into node
    text->data = line;
    text->next = NULL;
    if (!isEmpty())
    {
        if (indexExists(index - 1)) //check if index exists or is next element in linkedlist
        {
            if (index == 1)  //add text as the first element
            {
                text->next = head;
                head = text;//point "text" node to head
            }
            else //add text at given index
            {
                int count = 2;
                Node *curr = head;
                while (count < index) //find position in linked list
                {
                    curr = curr->next;
                    count++;
                }
                Node *buffer = curr->next;
                curr->next = text;  //insert text into position
                text->next = buffer;
            }
            size++;
        }
    }
    return;
}

void LinkedList::deleteLine(int index)
{
    if(!isEmpty()) //check if linkedlist is empty
    {
        if (indexExists(index)) //check if index exists in linkedlist
        {
            Node *curr = head;
            for (int i = 1; i < index - 1 && curr != NULL; ++i) //get to line position
            {
                curr = curr->next;
            }
            if (curr->next != NULL) //delete position is not last element
            {
                Node *temp;
                temp = curr->next;
                curr->next = curr->next->next;
                delete temp;
            }
            else    //delete position is last element in linked list
            {
                delete curr;
            }
            size--;
        }
    }
    return;
}

void LinkedList::edit(int index, string line)
{
    if(!isEmpty())//check if linkedlist is empty
    {
        if(indexExists(index))//check if index exists in linkedlist
        {
            if (index == 1) //check if user wants to edit the first line
            {
                head->data = line; //replace head with new line
            }
            else //continue if user wants to edit another line
            {
                Node *curr = head;
                int count = 1;
                while (count < index) //find position in linked list
                {
                    curr = curr->next;
                    count++;
                }
                curr->data = line; //replace line at specified position with new line
            }
        }
    }
    return;
}

void LinkedList::print()
{
   if(!isEmpty())   //check if linkedlist is empty
   {
       Node *curr = head;
       int position = 1;
       while (curr != NULL) //go through entire linkedlist
       {
           cout << position << " " << curr->data << endl; //print line number and node data
           curr = curr->next;
           position++;
       }
       return;
   }
}

void LinkedList::search(string line)
{
    bool isFound = false;
    if (!isEmpty()) //check if linkedlist is empty
    {
        Node *curr = head;
        int position = 1;
        while (curr != NULL) //go through entire linkedlist
        {
            if((curr->data).find(line) != std::string::npos) //check if substring exists in node data
            {
                cout << position << " " << curr->data << endl;
                isFound = true;
            }
            curr = curr->next;
            position++;
        }
    }

    if (!isFound) //if no substring is found in linkedlist
        cout << "not found" << endl;

    return;
}

bool LinkedList::isEmpty()
{
    if(head == NULL) //checks if head of linkedlist exists
    {
        cout << "List is empty" << endl;
        return true;
    }
    return false;
}

bool LinkedList::indexExists(int index)
{
    if(index > size) //check if index exists in linkedlist
    {
        return false;
    }
    return true;
}