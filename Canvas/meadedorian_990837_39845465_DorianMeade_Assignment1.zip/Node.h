//
// Created by Dorian Meade on 9/9/18.
//

#ifndef ASSIGNMENT1_LINKEDLIST_H
#define ASSIGNMENT1_LINKEDLIST_H
#include <iostream>
#include <string>
#include <cstring>

using namespace std;

struct Node
{
    string data;
    Node *next;
};

class LinkedList
{
public:
    int size;
    Node *head;

    LinkedList();
    void insertEnd(string line);
    void insertAt(int index, string line);
    void deleteLine(int index);
    void edit(int index, string line);
    void print();
    void search(string line);
    bool isEmpty();
    bool indexExists(int index);
};


#endif //ASSIGNMENT1_LINKEDLIST_H
