#include <iostream>
#include "Node.h"
int main()
{
    string commandString;
    string input;
    while (getline(cin, commandString) && !commandString.empty())   //multiple line user input into string
    {
        input += commandString + "\n";
    }

    LinkedList *userInput = new LinkedList;
    int newLinePos = 0;
    while(input.compare(""))    //string into linked list
    {
        newLinePos = input.find("\n");  //separate each command by a new line
        userInput->insertEnd(input.substr(0, newLinePos));
        input = input.substr(newLinePos + 1, input.size() - 1);  //delete command after adding to linked list
    }

    int space, space2, openQuote, closeQuote, num;
    string line, command, linePos, text;
    LinkedList *outputs = new LinkedList();

    Node *curr = userInput->head;
    while(!userInput->isEmpty())    //for each line of the user input
    {
        line = curr->data;
        space = line.find(" ");
        command = line.substr(0, space); //one word command from linked list node into string

        if(command.compare("insert") == 0 || command.compare("edit") == 0)  //requires number and phrase
        {
            space2 = line.find(" ", space+1);
            linePos = line.substr(space, space2);   //line number into string
            num = stoi(linePos);    //convert to int

            openQuote = line.find("\"");
            closeQuote = line.find("\"", openQuote+1);
            text = line.substr(openQuote + 1, closeQuote - openQuote - 1);  //phrase within quotes into string
        }
        else if(command.compare("insertEnd") == 0 || command.compare("search") == 0)    //requires phrase
        {
            openQuote = line.find("\"");
            closeQuote = line.find("\"", openQuote +1);
            text = line.substr(openQuote + 1, closeQuote - openQuote - 1);  //phrase within quotes into string
        }
        else if(command.compare("delete") == 0) //requires number
        {
            linePos = line.substr(line.size() - 2, line.size() - 1);    //line number into string
            num = stoi(linePos);    //convert to int
        }
        else
        {
            //command is either print or quit, no number or phrase required
        }

        //implement commands
        if(command.compare("insertEnd") == 0)
        {
            outputs->insertEnd(text);
            curr = curr->next;
            continue;
        }
        else if(command.compare("insert") == 0)
        {
            outputs->insertAt(num, text);
            curr = curr->next;
            continue;
        }
        else if(command.compare("delete") == 0)
        {
            outputs->deleteLine(num);
            curr = curr->next;
            continue;
        }
        else if(command.compare("edit") == 0)
        {
            outputs->edit(num, text);
            curr = curr->next;
            continue;
        }
        else if(command.compare("print") == 0)
        {
            outputs->print();
            curr = curr->next;
            continue;
        }
        else if(command.compare("search") == 0)
        {
            outputs->search(text);
            curr = curr->next;
            continue;
        }
        else //exit
        {
            return 0;
        }
    }
return 0;
}