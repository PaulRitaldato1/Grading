#include <iostream>
#include <string>
#include <algorithm>
#include <ctype.h>

struct Node {
    std::string data;
    Node* next;
};

class linkedList {
private:
    Node *head;
public:
    linkedList() {
        head = nullptr;
    }

    void insertEnd(std::string &substring) { //inserts text at last node
        Node *temp = new Node;
        Node *curr = head;
        temp->data = substring;

        if (curr == nullptr) {
            head = temp;
        }
        else {
            while (curr->next != nullptr) {
                curr = curr->next;
            }
            curr->next = temp;
        }
    }


    void insert(int line, std::string &substring) { //inserts text at any node
        Node *prev = head;
        Node *current = head->next;
        Node *temp = new Node;
        temp->data = substring;
        int count;

        if (head == nullptr) { head = temp; }
        if (line == 1) {
            Node *newHead = new Node;
            newHead->data = substring;
            newHead->next = head;
            head = newHead;
        }
        if (line == 2) {
            prev->next = temp;
            temp->next = current;
        }
        else { //handles cases after index = 2
            for (count = 2; count <= line; count++) {
                if(current != nullptr) {
                    prev = prev->next;
                    current = current->next;
                }
                else {
                    if(count == line) {
                        insertEnd(substring);
                        return;
                    }
                    break;
                }
            }
        }
    }
    void edit(std::string &substring, int line) { //edits data within a node
        Node* temp = new Node;
        temp->data = substring;
        Node* current = head;
        int count = 1;

        if (line == 1) {
            head->data = temp->data;
        }

        while (current != nullptr) {
            if (count == line) {
                current->data = temp->data;
            }
            current = current->next;
            count++;
        }
    }
    void delText(int line) { //deleting a node containing certain data
        int countLine = 1;
        Node** curr = &head;

        while(*curr != nullptr) {
            if(countLine == line) {
                *curr = (*curr)->next;
                return;
            }
            countLine++;
            curr = &((*curr)->next);
        }
    }

    void print() { //prints out every node with line number
        Node* curr = head;
        int count = 1;
        if(curr == nullptr) {
            std::cout << "Nothing to delete" << std::endl;
        }
        while (curr != nullptr) {
            std::cout << count << " " << curr->data << std::endl;
            curr = curr->next;
            count++;
        }
    }

    void search(std::string &substring) { //searches for every occurrence of a given stirng
        bool found = false;
        Node *curr = head;
        int count = 1;
        while (curr != nullptr) {
            if ((curr->data).find(substring) != -1) {
                found = true;
                std::cout << count << " " << curr->data << std::endl;
            }
            curr = curr->next;
            count++;
        }
        if(!found)
            std::cout << "not found" << std::endl;
    }
};

std::string & parse(std::string &str, std::string &substring) { //parse user input to get content within ""
    std::string quote = std::string("\"");
    int startQuote, endQuote;
    startQuote = str.find_first_of(quote);
    endQuote = str.find_last_of(quote);
    substring = str.substr((startQuote + 1),endQuote - startQuote - 1);

    return substring;
}

int parseInt(std::string &str) { //parse input to get the integer
    int i;
    int line = 0;
    for(i = 0; i < str.size(); i++) {
        if(isdigit(str.at(i))) {
            int digit = str.at(i) - '0';
            line *= 10;
            line += digit;
        }
    }
    return line;
}

int main() {
    linkedList text;
    std::string str;
    std:: string substring;
    int line;
    bool notEnd = true;


    while(notEnd) { //loop until user enters quit
        getline(std::cin, str); //get the whole line from user input
        parse(str, substring); //parse the user input to get the content between the " "

            if (str.find("insertEnd") == 0) {
                if (substring.length() <= 80) {
                    text.insertEnd(substring);
                    continue;
                }
            }
            if (str.find("insert") == 0) {
                if (substring.length() <= 80) {
                    line = parseInt(str);
                    text.insert(line, substring);
                    continue;
                }
            }
            if (str.find("delete") == 0) {
                if (substring.length() <= 80) {
                    line = parseInt(str);
                    text.delText(line);
                    continue;
                }
            }
            if (str.find("edit") == 0) {
                if (substring.length() <= 80) {
                    line = parseInt(str);
                    text.edit(substring, line);
                    continue;
                }
            }
            if (str.find("print") == 0) {
                text.print();
                continue;
            }
            if (str.find("search") == 0) {
                if (substring.length() <= 80) {
                    text.search(substring);
                    continue;
                }
            }
            if (str.find("quit") == 0) {
                notEnd = false;
            }
            else {
                std::cout << "Incorrect function call\n";
            }
        }
        return 0;
    }
