//
//  linkedlist.h
//  dataStructuresProject
//
//  Created by Kingsley Lurer on 9/19/18.
//  Copyright © 2018 Kingsley Lurer. All rights reserved.
//

#ifndef linkedlist_h
#define linkedlist_h

#include <string>
#include <iostream>

using namespace std;

class node {
public:
node* next;
string data = "";
};

class list {
    
public:
    node* head;
    node* tail;

    
bool deleteNode(int count,int listCount) {
    if (head == NULL) {
        return false; }

    if (count-1 == 0 && head->next == NULL) {
        
        head = NULL;
        return true;
    } else
    if (count-1 == 0 && head->next != NULL) {
       
            head = head->next;
            return true;
        }

    node* temp = head;
    node* prev = head;
    for (int i = 1; i < count; i++) {
        if (temp == NULL) {
            return false; }
        prev = temp;
        temp=temp->next;
    }
  /*  for (int i = 2; i < count; i++) {
        prev=prev->next;
        
    }*/
    
    if (temp == tail) {
        tail = prev;
        prev->next = NULL;
        return true;
    }
    
    node* post = temp->next;
    prev->next = post;

    return true;
    }
    
bool insert(string text, int count) {
    node* temp = head;
    node* prev = head;
    node* newnode = new node;
    newnode->data = text;
    if (head == NULL) {
        head = newnode;
        tail = head;
        return true;
    }
    
    for (int i = 1; i < count; i++) {
        if (temp == NULL) {
            //cout << "List does not have large enough index" << endl;
            return false; }
        prev=temp;
        temp=temp->next;
    }
   /* for (int i = 2; i<count; i++) {
        prev=prev->next;
        
    }*/
    if(temp == head) {
        newnode->next = temp;
        head = newnode;
        return true;
    }
   if(temp == tail) {
        prev->next = newnode;
        newnode->next = temp;
        tail = temp;
        return true;
    }
    prev->next = newnode;
    newnode->next = temp;
    
    return true;
}
    
void addNode(string text, int count) {
node* newnode = new node;
newnode->data = text;
    
    if (head == NULL) {
        head = newnode;
        tail = head;
        //cout << count << " " << newnode -> data << endl;
        return;
    }
    
node* temp = head;
while (temp != tail) {
    temp = temp->next;
    }
    temp->next = newnode;
    temp= temp->next;
    tail = temp;
    //cout << count << " " << tail -> data << endl;
    return;
    }
    
void edit(int count, string text) {
    if (head == NULL) {
        //cout << "Empty List" << endl;
        return; }
    node* temp = head;
    for (int i = 0; i<count-1; i++) {
        if (temp == NULL) {
           // cout << "Size of list not big enough" << endl;
            return; }
        temp = temp->next;
    }
    temp->data = text;
    //cout << count << " " << temp->data << endl;
    
    }
    
void print() {
    int count = 0;
    if (head == NULL) {
        cout << "Empty List" << endl;
        return; }
        
        node* temp = head;
        while (temp != NULL) {
            count++;
            cout << count << " " << temp->data << endl;
            temp = temp->next;
        }
    }

    
void search(string text) {
    bool ifFound = false;
    int count = 0;
    if (head == NULL) {
    cout << "Empty List" << endl;
        return;
    }
    
    node* temp = head;
    while(temp!= NULL) {
        count++;
        
        /*size_t found = node->data.find(text);
         if (found!=std::string::npos)
         std::cout << "first 'needle' found at: " << found << '\n'; */
        /*for (int i = 0; i < temp->data.length(); i++) {
            if (text == temp->data.substr(0,i)) {
                cout << count << " " << temp->data << endl; */
        
        size_t found = temp->data.find(text);
        if (found!=std::string::npos) {
            cout << count << " " << temp->data << endl;
            ifFound = true;
             }
            //}
            
       // }
        temp = temp->next;
    }
        if (!ifFound)
            cout << "not found" << endl;
        return;
    }
    
    
};



#endif /* linkedlist_h */
