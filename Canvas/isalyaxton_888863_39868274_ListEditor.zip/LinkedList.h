#include <iostream>
#include <string>

template<class T>
class Node {
	public:
		Node<T>* next = NULL;
		T data{};
};

template<class T>
class LinkedList {
	private:
		Node<T>* head;
		Node<T>* tail;
		int size;

		// bool addSafe(int index, T value);
		// void deleteSafe(int index);

	public:
		LinkedList();
		~LinkedList(); 

		int getSize();

		void add(int index, T value); 
		void addEnd(T value); 
		void addFront(T value);

		void findVal(std::string value);
		void deleteFront();
		void replace(int index, T value);

		void deleteNode(int index);

		void print();

};

#include "LinkedList.tpp"