#include "LinkedList.h"
#include <string>
#include <vector>
#include <iostream>

using namespace std;

class ListEditor {
	private:
		bool running;
		LinkedList<string> lines;

	public:
		ListEditor() {
			running = true;
		}


		bool isValid(string s) {
			if(s.length() > 80) {
				//cout << "Input line is too long! Enter a valid input\n";
				return false;
			}
			else { return true; }
		}

		void insertEnd(string s) {
			if(isValid(s)){
				lines.addEnd(s);
			}
		}

		void insert(int index, string s) {
			if(index == 0) {
				//cout << "ERROR: INPUT MUST BE GREATER THAN 0\n";
				return;
			}

			else if(isValid(s)) {
				lines.add(index-1, s);
			}
		}

		void del_line(int index) {
			lines.deleteNode(index-1);
		}


		void stop_running() {
			running = false;
		}

		bool is_running() {
			return running;
		}

		void print() {
			lines.print();
		}

		void search(string s) {
			lines.findVal(s);
		}

		void edit(int index, string s) {
			if(isValid(s)) {
				lines.replace(index-1, s);
			}
		}
};

// split a space deliminated string into vector; strings surrounded by " " count as one string
vector<string> split(string s) {
	vector<string> data;
	string temp;

	for(string::iterator it = s.begin(); it!= s.end(); it++) {
		if(*it == ' ') {
			data.push_back(temp);
			temp.clear();
		}
		else if(*it == '"' && data.size() > 0) {
			it++;
			while(*it != '"' && it!=s.end()) {
				temp.push_back(*it);
				it++;
			}
			// quotes aren't balanced, will return the string minus the last character
			if(*it != '"') {
				//cout << "QUOTES ARENT BALANCED\n";
				break;
			}
			data.push_back(temp);
			return data;
		}
		else {
			temp.push_back(*it);
		}
	}

	// push final string
	data.push_back(temp);

	//cleanup blank space on bad input
	for(int i = 0; i < data.size(); i++) {
		if(data[i] == "") {
			data.erase(data.begin() + i);
		}
	}

	return data;
}


int main() {

	ListEditor datastream;
	string input;

	while(datastream.is_running()) {
		input.clear();
		getline(cin, input);

		vector<string> input_v;
		input_v = split(input);

		int sz = input_v.size();

		// for(int i = 0; i < input_v.size(); i++) {
		// 	cout << input_v[i] << '\n';
		// }

		switch(sz) {
			case 1:
				if(input_v[0] == "quit") {
					datastream.stop_running();
					break;
				}
				else if(input_v[0] == "print") {
					datastream.print();
					break;
				}
				else {
					//cout << "Input Invalid\n";
					break;
				}

			case 2:
				if(input_v[0] == "insertEnd") {
						datastream.insertEnd(input_v[1]);
					break;
				}
				else if(input_v[0] == "search") {
					datastream.search(input_v[1]);
					break;
				}
				else if(input_v[0] == "delete") {
					int index = stoi(input_v[1]);
					datastream.del_line(index);
					break;
				}
				else {
					//cout << "Input Invalid\n";
					break;
				}

			case 3:
				if(input_v[0] == "insert") {
					try {
						stoi(input_v[1]);
					}
					catch(invalid_argument) {
						//cout << "Input Invalid\n";
						break;
					}
					int index = stoi(input_v[1]);
					datastream.insert(index, input_v[2]);
					break;
				}
				else if(input_v[0] == "edit") {
					try {
						stoi(input_v[1]);
					}
					catch(invalid_argument) {
						//cout << "Input Invalid\n";
						break;
					}
					int index = stoi(input_v[1]);
					datastream.edit(index, input_v[2]);
					break;
				}
				else {
					//cout << "Input Invalid\n";
					break;
				}

			// default:
			// 	cout << "Input Invalid\n";
		}


	}

}

	// LinkedList<string> test;

	// test.addEnd("hello");
	// test.print();

	// LinkedList<int> test;
	// test.add(0,2);
	// test.add(1,3);
	// test.add(0,6);
	// test.print();
	// test.deleteNode(1);
	// test.print();
	// test.add(1,9);
	// test.add(1,7);
	// test.print();
	// test.addEnd(5);
	// test.print();
