#include <iostream>
#include<cstdlib>
#include <string>
#include <stdio.h>

using namespace std;


struct node { //Node Declaration
    string data;
    struct node* next;
};
node *start = NULL;
node *head = NULL;
node *current = NULL;
 void insertend(string name) {


    node *temp = new node;
    temp -> data = name;
    temp-> next= NULL;


    if(head == NULL) {
        head = temp;
    }//check if list is empty
 else {
        node *last = head;
        while (last->next != NULL) {
            last= last->next;
        } // find the last element of the linked list

        last->next = temp;
    }
}

void insertX(string data,int n) {
     node* temp1 = new node();
     temp1->data = data;
     temp1->next = NULL;
     if(n == 1){
         temp1->next=head;
         head = temp1;
         return;
     }

     node* temp2 = head;
     for(int i=0; i < n-2;i++){
         temp2 = temp2->next;
     }
     temp1->next=temp2->next;
     temp2->next=temp1;

 }

void searchNode(struct node *head, string key)
{
    while (head != NULL)
    {
        if (head->data == key)
        {
            printf("key found\n");
        }
        head = head->next;
    }
    printf("not found\n");
}

    void display1() {
        int i = 1;
        string input;
        node *current = head;
        while (current != NULL) {
            cout << i << " " << current->data << "\n";
            current = current->next;
            i++;
        }
        cout << endl;
        return;
    }



void edit1(string old, string new1) {
    int pos = 1;

        if(head==NULL) {
            printf("Linked List not initialized");
            return;
    }

    current = head;
        while(current->next!=NULL) {
            if (current->data == old) {
                current->data = new1;
                return;
            }

    current = current->next;
    pos++;
}
}

 void Delete(int n)
{
struct node* temp1=head;
for(int i=1; i< n-1;i++)
    temp1=temp1->next;
struct node* temp2 = temp1->next;
temp1->next = temp2->next;
free(temp2);
}

int main() {

    struct node *head = NULL;


    head = NULL;
    string ch; //store user input
    string insertEnd;
    string text;
    string quit;
    string insert;
    string edit;
    string search;
    string name;
    struct node* next;

 do { // loop until user wants to quit
     getline(cin,ch);

     if (ch == "insertEnd") {
         getline(cin,name);
         insertend(name);
     }

     if (ch == "insert") {
         getline(cin,text);
         int position;
         cin >> position;
         insertX(text,position);
     }

     if (ch == "edit") {
         string old;
         string new1;

         getline(cin,old);
         getline(cin,new1);

         edit1(old, new1);

     }
     if (ch == "search") {
         string name;
         getline(cin,name);
         searchNode(head,name);
     }

     if (ch == "print") {
         display1();

     }
     if (ch== "delete"){
         int n;
         cin >> n;
         Delete(n);
     }
     if (ch == "quit") {
         exit(0);
     }
 }
while (ch != "quit");
}