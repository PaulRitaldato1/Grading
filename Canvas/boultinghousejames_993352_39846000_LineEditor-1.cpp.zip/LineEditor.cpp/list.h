//
//  list.h
//  LineEditor.cpp
//
//  Created by James Boultinghouse on 9/10/18.
//  Copyright © 2018 James Boultinghouse. All rights reserved.
//

#ifndef list_h
#define list_h
using namespace std;

struct Node{
    string line;
    Node*next;
};

class List{
private:
    Node* head;
public:
    List();
    Node* insertEnd(Node* head, string text);
    Node* insert(Node*& head, string text, int index);
    Node* edit(Node* head, string text, int index);
    void remove(Node*& head, int index);
    
    void search(Node* head, string text);
    void print(Node* head);
    
    ~List();
    
};

#endif /* list_h */
