//  main.cpp
//  LineEditor.cpp
//
//  Created by James Boultinghouse on 9/10/18.
//  Copyright © 2018 James Boultinghouse. All rights reserved.

#include <iostream>
#include "list.h"
#include <string>
using namespace std;

List::List() { head=NULL; }
Node* List::insertEnd(Node* head, string text) {
    if(head==NULL) {
        head= new Node();
        head->line=text;
        head->next=NULL;
        return head;
    }
    Node* temp=head;
    while(temp->next!=NULL){ temp=temp->next; }
    //creates new Node to be inserted and puts a NULL link afterwards
    temp->next=new Node();
    temp->next->line=text;
    temp->next->next=NULL;
    return head;
}
Node* List::insert(Node*& head, string text, int index) {
    Node* toLink = new Node();
    Node* temp = head;
    Node* b4Link = new Node();
    Node* afLink;
    toLink->line=text;
    //if insertion is at the head, do this:
    if(index==1) {
        toLink->next=head;
        return toLink;
    }
    for (int i=1; i<index; ++i) {
        //if insertion is at the end of the list
        if(temp!=nullptr && temp->next==nullptr && i==index-1) {
            return insertEnd(head, text);
        }
        else if(temp==nullptr) { return head;  }
        b4Link=temp;
        temp=temp->next;
    }
    //create after and before nodes and insert the toLink node in between
    afLink=temp;
    temp=nullptr;
    b4Link->next=toLink;
    toLink->next=afLink;
    return head;
}
Node* List::edit(Node* head, string text, int index) {
    Node* temp=head;
    for (int i=1; i<index; i++) {
        temp=temp->next;
    }
    temp->line=text;
    return head;
}
void List::remove(Node*& head, int index) {
    //Base Case: for when the index is invalid
    if (index<1 || head==NULL) { return; }
    //Base Case: for when the correct index is found
    else if(index==1) {
        Node* forDelete=head;
        head=head->next;
        delete forDelete;
        return;
    }
    //Recursive Case: when the node is not the desired location
    remove(head->next, index-1);
    return;
}
void List::search(Node* head, string text) {
    Node* temp=head;
    int index = 1;
    bool found=false;
    
    while(temp!=NULL) {
        //attempts to find any possible location of the desired text within each node's value
        if(temp->line.find(text)!=std::string::npos || text==temp->line) {
            cout<<index<<" "<<temp->line<<endl;
            found=true;
        }
        temp=temp->next;
        index++;
    }
    if(!found) { cout<<"not found"<<endl; }
}
void List::print(Node* head) {
    Node* temp = head;
    int index=1;
    while(temp!=NULL) {
        cout<<index<<" "<<temp->line<<endl;
        temp=temp->next;
        index++;
    }
}
int main(int argc, const char * argv[]) {
    string choiceInput;
    string textLine;
    string ignore;
    int lineToEdit;
    int lineToInsert;
    bool endPrgm = false;
    Node* fullText = NULL;
    List* llist = new List();
   //Chooses which method to call
    while(!endPrgm) {
        cin>>choiceInput;
        
        if(choiceInput=="insertEnd"){
            getline(cin, textLine);
            textLine=textLine.substr(2, textLine.size()-3);
            if(textLine.size()<=80){
                fullText=llist->insertEnd(fullText, textLine);
            } else {
                cout<<"Exceeds max character count"<<endl;
            }
        }
        else if(choiceInput=="insert") {
            cin>>lineToInsert;
            getline(cin, textLine);
            textLine=textLine.substr(2, textLine.size()-3);
            if(textLine.size()<=80){
                fullText=llist->insert(fullText, textLine, lineToInsert);
            } else {
                cout<<"Exceeds max character count"<<endl;
            }
        }
        else if(choiceInput=="edit") {
            cin>>lineToEdit;
            getline(cin, textLine);
            textLine=textLine.substr(2, textLine.size()-3);
            if(textLine.size()<=80) {
                fullText=llist->edit(fullText, textLine, lineToEdit);
            } else {
                cout<<"Exceeds max character count"<<endl;
            }
        }
        else if(choiceInput=="delete") {
            cin>>lineToEdit;
            llist->remove(fullText, lineToEdit);
        }
        else if(choiceInput=="search") {
            getline(cin, textLine);
            textLine=textLine.substr(2, textLine.size()-3);
            llist->search(fullText, textLine);
        }
        else if(choiceInput=="print") {
            llist->print(fullText);
        }
        else if(choiceInput=="quit") {
            endPrgm=true;
        }
        else{
            getline(cin, ignore);
            cin.clear();
            cout<<"Invalid input. Please try again."<<endl;
        }
    }
}
