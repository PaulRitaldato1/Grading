compiles on C++ and works with command line arguments
submitted but could not get stepik to work by Friday 9/21/18
passes 6/7 test cases

^going to try and get stepik to work with std::cin just ran out of time

 

 
