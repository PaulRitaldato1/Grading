#ifndef LINE
#define LINE
#include<iostream>
#include<string>
#include<stdlib.h>
#include<algorithm>
using namespace std;


class Line{
  struct Node{
  std::string data;
  Node *next = nullptr;

  };
public:
  Line();
  int length();
  bool isEmpty();
  void insertTextEnd(std::string text); //probably string instead of int.
  // void insertTextBeg(node *&head, node *&last, string text); //probably going to need to be char instead of int
  void insertTextVar(std::string text, int location); // same as above but probly going to need another int number to signal where in file it is going
  void deleteText(int location);
  void editText(std::string text, int location);
  void printText();
  void searchText(std::string text);
  //void quit();


private:
  Node *head;
  Node *tail;
};


Line::Line(){
  head = nullptr;
  tail = nullptr;
}

bool Line::isEmpty(){
return head==nullptr;
}

int main(int argc, char const *argv[]) {
  Line line;
  std::string arg;
  std::string argChk;
  int location;
  std::string text;
  for (int i = 1; i < argc; i++) {
    arg = argv[i];
    //argChk = argv[i+1];
    if (arg == "insertEnd"){
      text = argv[i+1];
      line.insertTextEnd(text);
      //line.printText();
    }
    else if(arg == "insert"){
        location = atoi(argv[i+1]);
        text = argv[i+2];
        line.insertTextVar(text, location-1);
        //line.printText();
    }
    else if(arg == "delete"){
        location = atoi(argv[i+1]);
        //text = argv[i+2];
        line.deleteText(location-1);
        //line.printText();
    }
    else if(arg == "edit"){
        location = atoi(argv[i+1]);
        text = argv[i+2];
        line.editText(text, location);
        //line.printText();
    }
    else if(arg == "print"){
        /*location = atoi(argv[i+1]);
        text = argv[i+2];
        line.insertTextVar(text, location);*/
        line.printText();
    }
    else if(arg == "search"){
        //location = atoi(argv[i+1]);
        text == argv[i+1];
        //line.insertTextVar(text, location);
        line.searchText(text);
        //line.printText();
    }
    else if(arg == "quit"){
        return 0;
    }

    else {
        continue;
    }
  }

  return 0;
}

int Line::length(){
int len = 0; //1
Node *N = head; //1
while (N){ 
  ++len;
  N = N->next;
}
  return len;
}

void Line::editText(std::string text, int location){
  deleteText(location-1);
  insertTextVar(text, location-1);
}

void Line::searchText(std::string text){
  int i =0;
  Node *N = head;
  while(N){
    if(N->data.compare(text) == 0){
    std::cout << i+1 << " " << text << endl;
      //return;
    }
    else{
        std::cout << "not found" << endl;
    }
    i++;
    N = N->next;
  }
//std::cout << "not found" << endl;
}


void Line::deleteText(int location){
  int len = length();

  if(location<0 || location>len-1){

  //std::cout << "Invalid Location\n";
  return;
  }
  Node *N = head;
  if(location==0){
    if(len>1){
      head = N->next;
    }
    delete N;
    return;
  }
  if(location == len-1){
    for (size_t i = 0; i < location-1; i++) {
      N = N->next;
    }
  tail = N;
  N->next=nullptr;
    return;
  }

  Node *temp = head;
  for (size_t i = 0; i < location; i++) {
    N= N-> next;
  }
  for (size_t i = 0; i < location-1; i++) {
    temp = temp->next;
  }
   temp->next = N->next;
   delete N;
}


void Line::insertTextEnd(std::string text){
  Node *N = new Node;
  N->data = text;
  if(isEmpty()){
    head = N;
    tail = N;
    return;
  }
  tail->next = N;
  tail = N;
}

void Line::insertTextVar(std::string text, int location){
  // five cases if out reject, insert first node, insert last node, insert middle
int len = length();

if(location<0 || location>len){

//std::cout << "Invalid Location\n";
return;
}

if(location==len){
  insertTextEnd(text);
  return;
}

Node *N = new Node;
N->data = text;

if(location==0 && len == 0){
  head = N;
  tail = N;
  return;
}

if(location==0){
  N->next = head;
  head = N;
  return;
}
Node *temp = head;
for (size_t i = 0; i < location-1; i++) {
  temp = temp->next;
}
N->next = temp->next;
temp->next = N;
}


void Line::printText(){
if (isEmpty()){
  std::cout << "The list is empty. \n";
  return;
}
Node *N = head;
/*do{
  cout << N->data << endl;
 std:: head = head->next;
}while(N->next);*/
int j = 0;
  while(N){
    std::cout << j+1 << " " << N->data << endl;
    N = N->next;
    j++;
  }
}

#endif