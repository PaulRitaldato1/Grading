#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <sstream>

/*
Aleksei "Sandro" Witty
65676941

Programming Assignment 1: Implement a Line Editor using Linked List
*/

using namespace std; 

class Node { //Node Function
	public:
		string line;
		int id;
		Node* next = NULL;
};

Node* insertEnd(Node* head, int index, int id, string line) { //Inserts the Node at the end.
	Node* addNode = new Node();
	addNode->id = ++id;
	addNode->line = line;
	if (index == 0) {
		addNode->next = head;
		return addNode;
	}
	int i = 1;
	Node* current = head;
	while (i<index) {
		current = current->next;
		if (current == NULL) {
			return NULL;
		}
		i++;
	}
	Node* next = current->next;
	current->next = addNode;
	addNode->next = next;
	return head;
}

void insert(Node* head, int index, int id, string line) { //Inserts the Node in a designated index.
	Node* addNode = new Node();
	Node* prev = head;
	addNode->id = id;
	addNode->line = line;
	addNode->next = NULL;
	
	if (index == 1) {
		addNode->next = head;
		head = addNode;
		return;
	}
	Node* temp = head;
	temp->id = ++id;
	for (int i = 0; i < index-2;i++) {
		prev = head;	
		temp = temp->next;
	}
	addNode->next = temp->next;
	prev->id = id;
	temp->next = addNode;
}

void printReverseRecursive(Node* head) { //Prints recursively to display in a right order.
    if(head) {
        printReverseRecursive(head->next);
	    if (head->id == 0) {
		    return;
		}
        cout << head->id << " ";
	    cout << head->line.substr(1,head->line.length()-2) << endl;
    }
}

void edit(Node* head, int index, string scan) { //Edits the line in a node.
	while (head) {
		if (head->id == index) {
			head->line = scan;
		}
		head = head->next;
	}
}

bool search(Node* head,string scan) { //Searches a line in a node.
	string sscan = scan.substr(1,scan.length()-2);
	if (head) {
		search(head->next,scan);
		if (head->line.find(sscan) != std::string::npos) {
			cout << head->id << " ";
			cout << head->line.substr(1,head->line.length()-2) << endl;
			return true;
		}
		head = head->next;
	}
	return false;
}

void deleteNode(Node* node, Node* prev, int index) { //Execute node deletion.
    if (node->next!=NULL) {
        Node* temp1 = node->next;
		prev->id = prev->next->id;
		node->line = temp1->line;
		node->id = temp1->id;
        node->next = temp1->next;
        free(temp1);
    }
    else {
        delete node;
        prev->next = NULL;
    }
}
 
Node* RemoveDuplicates(Node *head, int scan) { //Just in case if there are duplicates.
    if (head == NULL) return NULL;
    Node *curr = head;
    Node *aux;

    while (curr->next != NULL) {
      if (curr->id == curr->next->id) {
          if (curr->id == scan) {
              aux = curr->next->next;
              delete curr->next;
              curr->next = aux;
          }
          else {
              curr = curr->next;
          }
      }
      else {
          curr = curr->next;
      }  
  }
  return head;
}

Node* deleteid(Node* head, int scan) { //Deletes a node in a designated index.
    Node* curr = head;
    Node* prev = NULL;
	
    prev=curr;
    if (head->id == scan) {
        RemoveDuplicates(curr,scan);
        deleteNode(head,prev,scan);
    }
	curr = curr->next;
    while (curr!=NULL)
    {	
        if (curr->id == scan) {
            RemoveDuplicates(curr,scan);
            deleteNode(curr,prev,scan);
        }
		prev = curr;
        curr = curr->next;
		
    }
    return head; 
}

int main() { //The main function
    int charMax = 80;
	string inputCommand = " ";
	Node * head = new Node();
	int index = 0;
	
	while (!inputCommand.empty()) {
		getline(cin,inputCommand);
		int n = inputCommand.length();
		if (n > charMax) {
			
		}
		else {
			if (inputCommand.find("insert") == 0) {
				if (inputCommand.find("insertEnd") == 0) {
					head = insertEnd(head,index,head->id,inputCommand.substr(10,inputCommand.length()));
					continue;
				}
				if (inputCommand.find("insert") == 0) {
					int x;	
					stringstream ss;
					ss << inputCommand.substr(7);
					ss >> x;
					ss.str("");
					ss.clear();
					if (x == head->id+1) {
						head = insertEnd(head,index,head->id,inputCommand.substr(9,inputCommand.length()));
						continue;
					}
					if (x > head->id+1) {
						continue;
					}
					else {
						insert(head,x,head->id,inputCommand.substr(9,inputCommand.length()));
						index++;
						continue;
					}
					
					continue;
				}
				else {
					continue;
				}
			}
			if (inputCommand.find("delete") == 0) {
				int y = 0;
				stringstream ss;
				ss << inputCommand.substr(7);
				ss >> y;
				ss.str("");
				ss.clear();
				
				if (y > head->id) {
					continue;
				}
				else {
					deleteid(head,y);
					continue;
				}
			}
			if (inputCommand.find("edit") == 0) {
				int z;
				stringstream ss;
				ss << inputCommand.substr(5);
				ss >> z;
				ss.str("");
				ss.clear();
				
				edit(head,z, inputCommand.substr(7,inputCommand.length()));
				
			}
			if (inputCommand.find("print") == 0) {
				printReverseRecursive(head);
			}
			if (inputCommand.find("search") == 0) {
				if(search(head, inputCommand.substr(7,inputCommand.length())) == false) {
					cout << "not found" << endl;
				}
			}
			if (inputCommand.find("quit") == 0) {
				return 0;
			}
		}
	}
}