#include "Node.h"

Node::Node(std::string text, int line, Node* next) {
    this->next = next;
    this->text = text;
    this->line = line;
}


std::string Node::getText() {
    return this->text;
}

int Node::getLine() {
    return this->line;
}

void Node::setLine(int newLine) {
    this->line = newLine;
}

void Node::setText(std::string newText) {
    this->text = newText; 
}