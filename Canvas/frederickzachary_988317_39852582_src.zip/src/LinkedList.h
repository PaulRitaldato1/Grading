#ifndef LINKED_LIST
#define LINKED_LIST

#include <string>
#include "Node.h"

class LinkedList{
    private: 
        Node* head = nullptr;
        int nextLine = 1;

    public: 
        bool headCreated = false;

    public:
        LinkedList(std::string headText);
        LinkedList();
        void createHead(std::string text);
        void insertEnd(std::string text);
        void insert(std::string text, int line);
        void deleteLine(int line);
        void printData();
        void incrLine();
        void decrLine();
        void updateLines();
        void editLine(std::string newText, int line);
        void searchText(std::string textToFind);
};

#endif