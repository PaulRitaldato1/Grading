#ifndef NODE
#define NODE

#include <string>

class Node{
    public:
        int line;
        std::string text;
        Node* next = nullptr;

    public:
        Node(std::string text,int line,  Node* next);
        std::string getText();
        int getLine();
        void setText(std::string newText);
        void setLine(int newLine);
};


#endif