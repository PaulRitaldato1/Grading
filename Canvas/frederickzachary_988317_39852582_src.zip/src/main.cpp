#include <iostream>
#include <string>
#include "LinkedList.h"

bool isRunning = true;
LinkedList list;

void parse_input(std::string command) {
    
    if (command.find("quit") != std::string::npos) {
        isRunning = false;
        return;
    } 

    if (command.find("print") != std::string::npos) {
        list.printData();
        return;
    }

    if (command.find("insertEnd") != std::string::npos) { 
        int startPos = command.find_first_of("\"");
        int endPos = command.find_last_of("\"");
        
        if (startPos == std::string::npos) {
            std::cout << "Error. unable to parse command." << std::endl;
            return;
        } 

        if (endPos == startPos) {
            std::cout << "Error. unable to parse command." << std::endl;
            return;
        }

        startPos++;

        std::string text = command.substr(startPos, endPos-startPos);
        
        list.insertEnd(text);
        return;

    }

    if (command.find("delete") != std::string::npos) {
        int firstPos = command.find("delete") + 6;
        int line = NULL;

        for (int i = firstPos; i<command.size(); i++) {
            if (isdigit(command[i])) {

                if (line == NULL) {
                    line = 0;
                }

                line *= 10;
                line += command[i] - '0';
            }
        }

        

        if (line != NULL) {
            list.deleteLine(line);
            return;
        } else {
            std::cout << "Error. unable to parse command." << std::endl;
        }
    }

    if ((command.find("insert") != std::string::npos) && (command.find("insertEnd") == std::string::npos)) {
        int firstPos = command.find("insert") + 6;
        int line = NULL;

        for (int i = firstPos; i < command.size(); i++) {
            if (isdigit(command[i])) {
                if (line == NULL) {
                    line = 0;
                }

                line *= 10;
                line += command[i] - '0';
            }

            if (command[i] == '"') {
                break;
            }
        }

        if (line != NULL) {
            int start = command.find_first_of("\""); 
            int end = command.find_last_of("\"");
            
            if (start == std::string::npos) {
                std::cout << "Error. unable to parse command." << std::endl;
                return;
            }

            if (end == start) {
                std::cout << "Error. unable to parse command." << std::endl;
                return;
            }

            start++;

            std::string text = command.substr(start, end-start);
            list.insert(text, line);
            return;
        } else {
            std::cout << "Error. unable to parse command." << std::endl;
            return;
        }
    }

    if (command.find("edit") != std::string::npos) {
        int firstPos = command.find("edit") + 4;
        int line = NULL;

        for (int i = firstPos; i < command.size(); i++) {
            if (isdigit(command[i])) {
                if (line == NULL) {
                    line = 0;
                }

                line *= 10;
                line += command[i] - '0';
            }
        }

        if (line != NULL) {
            int start = command.find_first_of("\"");
            int end = command.find_last_of("\"");
            
            if (start == std::string::npos) {
                std::cout << "Error. unable to parse command." << std::endl;\
                return;
            }

            if (end == start) {
                std::cout << "Error. unable to parse command." << std::endl;\
                return;
            }

            start++;

            std::string text = command.substr(start, end-start);
            list.editLine(text, line);
            return;
        } else {
            std::cout << "Error. unable to parse command." << std::endl;
            return;
        }
    }

    if (command.find("search") != std::string::npos) {
        int start = command.find_first_of("\"")+1;
        int end = command.find_last_of("\"");

        if (start == std::string::npos) {
                std::cout << "Error. unable to parse command." << std::endl;\
                return;
            }

            if (end == start) {
                std::cout << "Error. unable to parse command." << std::endl;\
                return;
            }

            start++;

        std::string text = command.substr(start, end-start);
        list.searchText(text);
        return;
    }

    std::cout << "Error. unable to parse command." << std::endl;
}


int main() {

    std::cout << "Welcome to Zach's Text Editor!" << std::endl;

    std::string command;
    int line;

    while(isRunning) {
        std::cout << ">>> ";
        std::getline(std::cin, command);    
        parse_input(command);
    }

    return 0;
}