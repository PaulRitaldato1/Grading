#include <iostream>
#include "LinkedList.h"
#include "Node.h"

LinkedList::LinkedList(std::string headText) {
    createHead(headText);
}

LinkedList::LinkedList() {

}

void LinkedList::createHead(std::string text) {
    this->head = new Node(text, nextLine, nullptr);
    headCreated = true;
    incrLine();
}

void LinkedList::printData() {
    Node* current = this->head;
    
    while(current != nullptr) {
        std::cout << current->getLine() << ": " << current->getText() << std::endl;
        current = current->next;
    }
}

void LinkedList::insertEnd(std::string text) {
    if (head == nullptr) {
        Node* newNode = new Node(text, nextLine, nullptr);
        head = newNode;
        incrLine();
        return;
    }

    Node* current = this->head;

    while (current->next != nullptr) {
        current = current->next;
    }

    Node* newNode = new Node(text, this->nextLine, nullptr);
    incrLine();
    current->next = newNode;
}

void LinkedList::incrLine() { this->nextLine++; }

void LinkedList::decrLine() { this->nextLine--; }

void LinkedList::insert(std::string text, int line) {
    if (head == nullptr) {
        if (line == 1) {
            Node* newNode = new Node(text, line, nullptr);
            head = newNode;
            updateLines();
            return;
        }
    }

    Node* current = head;

    if (current->getLine() == line) {
        Node* tempNode = new Node(text, line, head);
        head = tempNode;
    }

    while (current->next != nullptr) {
        if (current->next->getLine() == line) {
            Node* tempNode = new Node(text, line, current->next);
            current->next = tempNode;
            break;
        }
        
        current = current->next;  
    }
    updateLines();
}

void LinkedList::updateLines() {
    Node* current = head;
    int properLine = 1;

    while (current != nullptr) {
        if (current->getLine() != properLine) {
            current->setLine(properLine);
        }
        current = current->next;
        properLine++;
    }

    nextLine = properLine;
}

void LinkedList::deleteLine(int line) {
    if (head == nullptr) {
        return;
    }

    Node* current = head;

    if (current->getLine() == line) {
        head = current->next;   
        delete head;
    }    

    while (current->next != nullptr) {
        if (current->next->getLine() == line) {
            Node* temp = current->next;
            current->next = temp->next;
            delete temp;
            break;
        }

        current = current->next;
    }

    if (current->getLine() == line) {
        delete current;
    }

    updateLines();
}

void LinkedList::editLine(std::string newText, int line) {
    Node* current = head;

    while (current != nullptr) {
        if (current->getLine() == line) {
            current->setText(newText); 
            break;
        }
        current = current->next;
    }
}

void LinkedList::searchText(std::string textToFind) {
    Node* current = head;

    while(current != nullptr) {
        if (current->getText().find(textToFind) != std::string::npos) {
            std::cout << current->getLine() << ": " << current->getText() << std::endl;
            return;
        }

        current = current->next;
    }

    std::cout << "not found" << std::endl;
}