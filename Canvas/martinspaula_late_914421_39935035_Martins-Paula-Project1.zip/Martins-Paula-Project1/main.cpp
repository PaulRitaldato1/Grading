#include <iostream>

using namespace std;

//your linked list implementation here
struct Node
{
    struct Node *next;
    string line;
};

class List
{
public:
    void insertEnd(struct Node*, string);
    void insert(struct Node*, string, int);
    void deleteLine(struct Node*, int);
    void edit(struct Node*, string, int);
    void print(struct Node*);
    void search(struct Node*, string);
    struct Node *firstPt;
    struct Node *newLine(string);
};

//your line editor implementation here

struct Node* newLine(string s)
{
    struct Node *node = new Node;
    node->line = s;
    return node;
}

void List::insertEnd(struct Node *temp, string s)
{
    struct Node *node = ::newLine(s);
    
    if (firstPt != NULL)
    {
        while (temp->next != NULL)
        {
            temp = temp->next;
        }
        temp->next = node;
    }
    else
        firstPt = node; //if null then place node in first link
}

void List::insert(struct Node *temp, string s, int i)
{
    
}

void List::deleteLine(struct Node *temp, int i)
{
    
}

void List::edit(struct Node* temp, string s, int i)
{
    for (int j=1; j<i; j++)
    {
        temp = temp->next;
    }
    temp->line = s;
}

void List::print(struct Node* temp)
{
    if (temp == NULL) {
        //ignore wrong entries
    }
    else
    {
        int counter;
        counter = 1;
        while(temp != NULL)
        {
            cout << counter << " " << temp->line << endl;
            temp = temp->next;
            counter++;
        }
    }
}

void List::search(struct Node* temp, string s)
{
    int found;
    found = 0;
    while(temp != NULL)
    {
        if (temp->line.find(s) != -1)
        {
            found++;
        }
        temp = temp->next;
    }
    if (found == 0)
    {
        cout << "not found\n" ;
    }
}

int main()
{
    //your code to invoke line editor here
    List list;
    list.firstPt = NULL;
    int temp, iPosition = 0;
    string sPosition, input, s = "";
    
    while (input != "quit")
    {
        getline(cin, input);
        
        if (input.substr(0,9) == "insertEnd")
        {
            
            list.insertEnd(list.firstPt, s);
        }
        else if (input.substr(0,6) == "insert")
        {
            
            list.insert(list.firstPt, s, iPosition);
        }
        else if (input.substr(0,6) == "delete")
        {
            
            list.deleteLine(list.firstPt, iPosition);
        }
        else if (input.substr(0,4) == "edit")
        {
            
            list.edit(list.firstPt,s, iPosition);
        }
        
        else if (input == "print")
        {
            list.print(list.firstPt);
        }
        else if (input.substr(0,6) == "search")
        {
            
            list.search(list.firstPt, s);
        }
        
        else
        {
            //ignore wrong input
        }
    }
    
}
