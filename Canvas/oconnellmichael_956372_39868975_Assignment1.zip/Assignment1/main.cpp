#include <iostream>
#include <string>
#include <iostream>
#include <sstream>
#include "user.cpp" // parse string & identify functions & args
using namespace std;

int main()
{
	while (true)
	{
		string userString;
		getline (std::cin,userString); //get user input by line
		if (userString == "quit")
		break;
		
		parseInput(userString);
	}
}
