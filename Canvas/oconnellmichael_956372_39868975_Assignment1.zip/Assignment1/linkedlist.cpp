#include<iostream>
#include <string>
using namespace std;
struct node
{
	string data;
	node *next;	
};
class list // learned from tutorial: https://goo.gl/vU8ENT
{
		private:
		node *head, *tail;
		public:
		list()
		{
			head=NULL;
			tail=NULL;
		}
		void insertEnd(string phrase)
		{
			node *temp=new node;
			temp->data=phrase;
			temp->next=NULL;
			if(head==NULL)
			{
				head=temp;			//adding element
				tail=temp;
				temp=NULL;
			}
			else
			{	
				tail->next=temp;	//moving along linked list
				tail=temp;
			}
		}
		void display()	//PRINT
		{
			node *temp=new node;
			temp=head;
			int pos = 1;
			while(temp!=NULL)		//Printing lines to display for user
			{
				cout<<pos<<" ";
				pos++;
				cout<<temp->data<<"\n";
				temp=temp->next;
			}
		}
		void insert_start(string phrase)	//Just making a new node
		{
			node *temp=new node;
			temp->data=phrase;
			temp->next=head;
			head=temp;
		}
		void insert_position(int pos, string phrase)
		{
			node *pre=new node;
			node *cur=new node;			//keeping track of location is the L.List
			node *temp=new node;
			cur=head;
			for(int i=1;i<pos;i++)		//get to the position
			{
				pre=cur;
				cur=cur->next;
			}
			temp->data=phrase;			//insert and move other elements adjust linking
			pre->next=temp;	
			temp->next=cur;
		}
		
		void insert(int pos, string phrase)	//simplification for UX
		{
			if (pos==1)
			{
				insert_start(phrase);
			}
			else
			{
				insert_position(pos, phrase);
			}
		}
		
		void delete_first()		//moving the head to delete the first ele. safely
		{
			node *temp=new node;
			temp=head;
			head=head->next;
			delete temp;
		}
		void delete_last()
		{
			node *current=new node;
			node *previous=new node;
			current=head;
			while(current->next!=NULL)
			{
				previous=current;
				current=current->next;	
			}
			tail=previous;
			previous->next=NULL;	//moving the tail to delete the last ele. safely
			delete current;
		}
		void delete_position(int pos)
		{
			node *current=new node;
			node *previous=new node;
			current=head;
			for(int i=1;i<pos;i++)		//get to the position
			{
				previous=current;
				current=current->next;
			}
			previous->next=current->next;	// remove and redirect the link
		}
		
		void delete_element(int pos)	//Simplification for UX
		{
			if (pos==1)
			{
				delete_first();
			}
			if (pos>1)
			{
				delete_position(pos);
			}
		}
		
		void edit(int pos, string phrase)	//Simplification for UX
		{
			delete_element(pos);
			insert(pos,phrase);
		}
		
		void search(string phrase)
		{
			string str = phrase.substr(1,phrase.size()-2);
			//cout<<str;	DEBUG
			int address = 1;
			int found = 0;		//easy way to communicate if it has been found
			node *current=new node;
			current=head;
			if (string::npos != current->data.find(str)) //is the phrase present at the begining?
				{
					found = 1;
					cout<<address<<" "<<current->data<<endl;
				}
				
			while(current->next!=NULL)
			{
				address++;	//keep track of address
				current=current->next;
				if (string::npos != current->data.find(str)) //is the phrase present at this location?
				{
					found = 1;
					cout<<address<<" "<<current->data<<endl;
				}
			}
			if (found == 0)
			{
				cout<<"NOT FOUND!"<<endl;
			}
		}
};
