#include <iostream>
#include <string> 
#include "linkedlist.cpp" //linked list Data Structure

using namespace std;

list obj; //setup linked list

void decipherString(string op, string val, string val2) //decoding user input and calling functions
{
	//insertEnd "text"  -- insert given text at the end of the document
	if (op == "insertEnd")
	{
		obj.insertEnd(val);
	}
	
	//insert 3 "text" --insert given text at the line indicated by index given
	if (op == "insert")
	{
		obj.insert(stoi(val),val2);
	}
	
	//delete 3 --- delete line at index given
	if (op == "delete")
	{
		obj.delete_element(stoi(val));
	}
	
	//edit 3 "text" --- replace the line at the index given with the given text
	if (op == "edit")
	{
		obj.edit(stoi(val),val2);
	}
	
	//print -- print the entire document, with line numbers
	if (op == "print")
	{
		obj.display();
	}
	
	//search "text" -- print the line number and line that contains the given text.  print "not found" if it is not found
	if (op == "search")
	{
		obj.search(val);
	}
	
	//quit - quit/exit the program 
	//HANDLED IN MAIN
}

void parseInput(string test)
{
	//string test = "operation 3 \"text\"";
	string test_operation = "VOID";
	string test_value = "0000";						//set default values
	string test_value2 = "VOID";
	
	size_t spaceFound = test.find(" ");				//delimeters
	size_t parenFound = test.find("\"");
	
	test_operation = test.substr (0,spaceFound);	//first split of strings
	test_value = test.substr (spaceFound+1,99);
	
	//cout<<test_operation<<endl;			DEBUG
	//cout<<test_value<<endl;
	
	parenFound = test_value.find("\"");
	spaceFound = test_value.find(" ");
	if (spaceFound < parenFound)	//second split only occurs if there is a space before "
	{
		spaceFound = test_value.find(" ");
		test_value2 = test_value.substr (spaceFound+2,test_value.size()-4); //removing ""
		test_value = test_value.substr (0,spaceFound);
		//cout<<test_operation<<endl;
		//cout<<test_value<<endl;			DEBUG
		//cout<<test_value2<<endl;
	}
	if (test_value2 == "VOID" && test_value.size() != 0 && test_operation != "delete")
	{
		//std::cout << "V: " << test_value.size();		DEBUG
		test_value = test_value.substr (1,test_value.size()-2); //removing ""
	}
	 
	 decipherString(test_operation, test_value, test_value2);	//pass to decode
}
