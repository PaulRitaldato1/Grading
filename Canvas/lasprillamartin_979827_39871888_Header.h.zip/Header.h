//
//  Header.h
//  LineEditor
//
//  Created by Martin Lasprilla on 9/18/18.
//  Copyright © 2018 Martin Lasprilla. All rights reserved.
//

#ifndef Header_h
#define Header_h

using namespace std;
struct Node{
    string data;
    int index;
    Node* next;
};

typedef Node* nodePtr;

class List{

private:
    nodePtr head;
    nodePtr curr;
    nodePtr prev;
    nodePtr temp;
    
public:
    List();
    void insertEnd(string userText);
    void insert(int userIndex,string userText);
    void deleteLine(int userIndex);
    void editLine(int userIndex,string userText);
    void printList();
    void searchList(string userText);
    
};

#endif /* Header_h */
