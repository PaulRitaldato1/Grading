#include <iostream>
#include <string>
#include <vector>
#include <sstream>
#include <algorithm>

// Node class.
class Node {
    public:
        std::string value = "";
        Node* next = NULL;
};

// Helper method: split the string.
std::vector<std::string> splitString(std::string input){
    std::string buf;
    std::stringstream ss(input);

    std::vector<std::string> tokens;
    while (ss >> buf)
        tokens.push_back(buf);

    return tokens;

}

// Helper method: clean up the input string.
std::string cleanUpString(std::vector<std::string> input, bool index) {
    std::string str = "";

    int i;
    if(!index) { i = 1; } else { i = 2; }

    for(; i < input.size(); i++)
        if(i != input.size() - 1)
            str = str + input.at(i) + " ";
        else
            str = str + input.at(i);

    str.erase(remove(str.begin(), str.end(), '\"' ), str.end());

    return str;
}

// Inserts to the end of the LinkedList.
void insertEnd(Node* head, std::string input) {
    if(head->value == "") {
        head->value = input;
    } else {
        Node* curr = head;
        while(curr->next != NULL)
            curr = curr->next;

        Node* newNode = new Node;
        newNode->value = input;
        curr->next = newNode;
    }
}

// Inserts to a specific index within the LinkedList.
void insertIndex(Node* head, std::string input, int index) {
    if(index == 1) {
        if(head->value == "") {
            head->value = input;
        } else {
            Node* next = new Node;
            next->value = head->value;
            next->next = head->next;

            head->value = input;
            head->next = next;
        }
    } else {
        int counter = 1;
        Node* curr = head;
        Node* prev = new Node;
        while(curr->next != NULL && counter != index) {
            counter = counter + 1;
            prev = curr;
            curr = curr->next;
        }

        Node* newNode = new Node;
        newNode->value = input;
        if(counter == index){
            newNode->next = prev->next;
            prev->next = newNode;
        } else if (index - counter == 1) {
            curr->next = newNode;
        }
    }
}

// Deletes a specific node within a given index in the LinkedList.
void deleteIndex(Node* head, int index) {
    Node* curr = head;
    if(index == 1) {
        head = head->next;
        delete curr;
    } else {
        int counter = 1;
        Node* prev = new Node;
        while(curr->next != NULL && counter != index) {
            counter = counter + 1;
            prev = curr;
            curr = curr->next;
        }

        if(counter == index){
            Node* toDel = new Node;
            toDel = prev->next;
            prev->next = toDel->next;
            delete toDel;
        }
    }
}

// Edits a value for a given index within the LinkedList.
void edit(Node* head, std::string input, int index) {
    Node* curr = head;
    for(int i = 0; i < index-1; i++) curr = curr->next;
    curr->value = input;
}

// Prints the given LinkedList.
void print(Node* head) {
    Node* curr = head;
    int counter = 1;
    while(curr != NULL) {
        std::cout << counter << " " << curr->value << std::endl;
        counter = counter + 1;
        curr = curr->next;
    }
}

// Does a search of a given input within the LinkedList.
void search(Node* head, std::string input) {
    Node* curr = head;
    int counter = 1;

    bool f = false;
    while(curr != NULL) {
        std::size_t found = curr->value.find(input);
        if (found!=std::string::npos) {
            std::cout << counter << " " << curr->value << std::endl;
            f = true;
        }
        counter = counter + 1;
        curr = curr->next;
    }

    if(!f) std::cout << "not found" << std::endl;
}

int main() {
    std::string input = "";

    Node* head = new Node;
    while(input != "quit"){
        std::getline(std::cin, input);
        std::vector<std::string> split = splitString(input);

        std::string command = "";
        try {
            command = split.at(0);
        } catch (...) {
            std::cout << "Invalid input." << std::endl;
            continue;
        }

        int index;
        if(command == "insert" || command == "delete" || command == "edit") {
            try {
                index = stoi(split.at(1));
            } catch (...) {
                std::cout << "Invalid index given." << std::endl;
                continue;
            }
        }

        if(command == "insertEnd") {
            insertEnd(head, cleanUpString(split, false));
        } else if(command == "insert") {
            insertIndex(head, cleanUpString(split, true), index);
        } else if(command == "delete") {
            deleteIndex(head, index);
        } else if(command == "edit") {
            edit(head, cleanUpString(split, true), index);
        } else if(command == "print") {
            print(head);
        } else if(command == "search") {
            search(head, cleanUpString(split, false));
        } else if(command == "quit") {
            break;
        } else {
            std::cout << "Invalid command." << std::endl;
        }
    }

    return 0;
}
