#include <string>
#include <iostream>

//your linked list implementation here
struct node {
    std::string data;
    node *next;
};

class linkedList {
    public:
    node *head;
    node *tail;

    linkedList() {
        head = NULL;
        tail = NULL;
    }

    void addNode(std::string input) {
        node *placeHolder = new node;
        placeHolder->data = input;
        placeHolder->next = NULL;

        if (head == NULL) {
            head = placeHolder;
            tail = placeHolder;
            placeHolder = NULL;
        } else {
            tail->next = placeHolder;
            tail = placeHolder;
        }
    }

    void deleteNode(int index) {
        int count = 0;
        node *current = head;
        node *previous = NULL;
        if (index == 0 && head) {
            current->next = head;
            delete current;
        }

        while (count != index) {
            count++;
            previous = current;
            if (previous) {
                current = current->next;
            }
        }

        if (previous && current) {
            previous->next = current->next;
            delete current;
        } else if (previous && head == NULL) {
            previous->next = NULL;
        }
    }
};

void displayLines(node *currentLine) {
    if (currentLine != NULL) {
        int lineNum = 1;
        while (currentLine) {
            std::cout << lineNum << " " << currentLine->data << std::endl;
            currentLine = currentLine->next;
            lineNum++;
        }
    }
}

void insertEnd(linkedList *lines, std::string input) {
        node *placeHolder = new node;
        placeHolder->data = input;
        placeHolder->next = NULL;

        if (lines->head == NULL) {
            lines->head = placeHolder;
            lines->tail = placeHolder;
            placeHolder = NULL;
        } else {
            lines->tail->next = placeHolder;
            lines->tail = placeHolder;
        }
}

void insert(linkedList *lines, std::string input, int index) {
    int count = 0;
    node *current = lines->head;
    node *previous = NULL;

    node *newNode = new node;
    newNode->data = input;

    if (index == 0) {
        newNode->next = current;
        lines->head = newNode;
    }

    while (count != index) {
        count++;
        previous = current;
        if (previous) {
            current = current->next;
        }
    }

    if (previous != NULL) {
        previous->next = newNode;
        newNode->next = current;
    }
}

void search(node *currentNode, std::string query) {
    int lineNum = 1;
    bool found = false;

    while (currentNode) {
        if (currentNode->data.find(query) != -1) {
            std::cout << lineNum << " " << currentNode->data << std::endl;
            found = true;
        }

        currentNode = currentNode->next;
        lineNum++;
    }

    if (!found) {
        std::cout << "not found" << std::endl;
    }
}

void edit(node *currentNode, std::string input, int index) {
    int count = 0;
    while (count != index) {
        count++;
        currentNode = currentNode->next;
    }

    if (currentNode) {
        currentNode->data = input;
    }
}

//your line editor implementation here
void lineEditor() {
    // Linked list
    linkedList lines = linkedList();
    // Store the users input
    std::string input = "";
    // Store the users request
    std::string request = "";
    // Substring for parsing input
    std::string subRequest = "";
    // Integer index, if the use request deletion
    int index = 0;

    // Main loop
    while (request != "quit") {
        // Get the input from the user
        std::getline(std::cin, request);

        // Search
        if (request.substr(0,6) == "search") {
            // Get the query
            subRequest = request.substr(8);
            subRequest.erase(subRequest.size() - 1);
            // Attempt to find it
            search(lines.head, subRequest);

        // Delete
        } else if (request.substr(0,6) == "delete") {
            // Get the index
            index = std::stoi(request.substr(7));
            // Attempt to delete
            if (index > 0) {
                lines.deleteNode(index - 1);
            }

        // Print
        } else if (request == "print") {
            displayLines(lines.head);

        // insertEnd
        } else if (request.substr(0,9) == "insertEnd") {
            // Get the text to insert
            subRequest = request.substr(11);
            subRequest.erase(subRequest.size() - 1);
            // Append it at the end
            insertEnd(&lines, subRequest);

        // insert
        } else if (request.substr(0,6) == "insert") {
            // Get the index
            index = std::stoi(request.substr(7,8));
            // Get the text to be inserted
            subRequest = request.substr(10);
            subRequest.erase(subRequest.size() - 1);
            // Insert if possible
            if (index > 0) {
               insert(&lines, subRequest, index - 1);
            }
        } else if (request.substr(0,4) == "edit") {
            // Get the index
            index = std::stoi(request.substr(5,6));
            // Get the text to be replaced
            subRequest = request.substr(8);
            subRequest.erase(subRequest.size() - 1);
            // Replace if possible
            if (index > 0) {
                edit(lines.head, subRequest, index - 1);
            }
        }
    }
}

int main()
{
    //your code to invoke line editor here
    lineEditor();
    return 0;
}