#include "editor.h"

/**
 * lle.run() will run until "quit" is encountered 
 */
int main()
{
    LinkedListEditor lle;
    lle.run();
    return 0;
}