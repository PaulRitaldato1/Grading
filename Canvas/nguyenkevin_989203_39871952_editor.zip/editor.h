#include <string>
#include <memory>
#include <iostream>
#include <stdexcept>

/**
 * Basic templated node.
 */
template <class T>
struct Node
{
  public:
    T value;
    std::shared_ptr<Node<T>> next;
    Node(T value) : value(value), next(nullptr){};
    void replace(const T &newvalue)
    {
        value = newvalue;
    };
};

/**
 * Document linked list.
 * Holds a tail and head pointer and keeps track of size of linked list.
 * 
 * insertEnd, insert, delete, edit, and print commands are defined in this class.
 */
class DocumentLinkedList
{

  private:
    using LineNode = Node<std::string>;
    std::shared_ptr<LineNode> head = nullptr;
    std::shared_ptr<LineNode> tail = nullptr;
    int size = 0;

    /**
     * Returns a shared_ptr to the node indexed by the given index.
     * 
     * Note: index is referenced and will be modified by this function.
     *       index will be 0 if function successfully arrives at expected node.
     */
    std::shared_ptr<LineNode> iterateTo(int &index)
    {
        index--;
        auto ptr = head;
        while (index && ptr)
        {
            ptr = ptr->next;
            index--;
        }
        return ptr;
    }

    /**
     * Returns true if index given is out of bounds.
     */
    bool indexOutOfBounds(int index)
    {
        return index < 1 || index > size;
    }

  public:
    /**
     * Destructor avoids issue involved with "smashing the stack"
     */
    ~DocumentLinkedList()
    {
        while (head)
        {
            head = head->next;
        }
    }
    void insertEnd(const std::string &line)
    {

        if (head == nullptr)
        {
            head = std::shared_ptr<LineNode>(new LineNode(line));
            tail = head;
        }
        else
        {
            tail->next = std::shared_ptr<LineNode>(new LineNode(line));
            tail = tail->next;
        }
        size++;
    }

    void insertNodeAt(int index, const std::string &line)
    {
        if (indexOutOfBounds(index) && index > size + 1)
            return;

        auto newNode = std::shared_ptr<LineNode>(new LineNode(line));

        if (index == 1)
        {
            newNode->next = head;
            head = newNode;
            size++;
        }
        else if (index == size)
        {
            index--;
        }   
        else if (index == size + 1) //Edge case to make it equivalent to insertEnd.
        {
            insertEnd(line);
            return;
        }

        auto ptr = iterateTo(index);
        if (index == 0)
        {
            newNode->next = ptr->next;
            ptr->next = newNode;
            size++;
        }
        else
        {
            throw std::runtime_error("Something unexpected happened.");
        }
    }

    void deleteNodeAt(int index)
    {
        if (indexOutOfBounds(index))
            return;
        if (size == 0)
            return;
        if (index == 1)
        {
            head = head->next;
            size--;
            return;
        }
        
        index--; //To terminates loop one node before, then skip over node at desired index.
        auto ptr = iterateTo(index);
        if (index == 0)
        {
            if (ptr->next == tail)
            {
                tail = ptr;
            }
            ptr->next = ptr->next->next;
            size--;
        }
        else
        {
            throw std::runtime_error("Something unexpected happened.");
        }
    }

    void editTextAt(int index, const std::string &line)
    {
        if(indexOutOfBounds(index))
            return;
        auto ptr = iterateTo(index);
        ptr->replace(line);
    }

    void search(const std::string &line)
    {
        int n = 1;
        auto ptr = head;
        bool noneFound = true;
        while (ptr)
        {
            std::string str = ptr->value;
            if (str.find(line) != std::string::npos) //If str exists inside current node...
            {
                std::cout << n << " " << str << std::endl;
                noneFound = false;
            }
            n++;
            ptr = ptr->next;
        }
        if (noneFound)
            std::cout << "not found" << std::endl;
    }

    void printList()
    {
        auto ptr = head;
        int n = 1; //Index number
        while (ptr)
        {
            std::cout << n << " " << ptr->value << std::endl;
            n++;
            ptr = ptr->next;
        }
    }
};

/**
 * Contains code to parse in given user input, holds a DocumentLinkedList variable.
 */
class LinkedListEditor
{
  private:
    DocumentLinkedList dll;

    std::string getStringInput()
    {
        std::string str;
        getchar(); //consume space
        std::getline(std::cin, str);
        std::size_t found = str.find_last_not_of("\t\n\r ");
        if (found != std::string::npos)
            str = str.substr(0, found + 1);
        if (str[0] == '"' && str[str.length() - 1] == '"')
            str = str.substr(1, str.length() - 2);
        return str;
    }

  public:
    void run() //A while loop that parses and takes in input until "quit" command is arrived at.
    {
        std::string in;

        do
        {
            std::cin >> in;

            if (in == "insertEnd")
            {
                dll.insertEnd(getStringInput());
            }
            else if (in == "search")
            {
                dll.search(getStringInput());
            }
            else if (in == "edit")
            {
                int index;
                std::cin >> index;
                dll.editTextAt(index, getStringInput());
            }
            else if (in == "delete")
            {
                int index;
                std::cin >> index;
                dll.deleteNodeAt(index);
            }
            else if (in == "insert")
            {
                int index;
                std::cin >> index;
                dll.insertNodeAt(index, getStringInput());
            }
            else if (in == "print")
            {
                dll.printList();
            }
        } while (in != "quit");
    }
};