/*
 * Assignment1.cpp
 *
 *  Created on: Sep 18, 2018
 *      Author: carlycuadra
 */

#include "Assignment1.h"

Assignment1::Assignment1() {
	// TODO Auto-generated constructor stub

}

Assignment1::~Assignment1() {
	// TODO Auto-generated destructor stub
}

