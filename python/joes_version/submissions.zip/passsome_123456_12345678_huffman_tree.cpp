#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include "huffman_tree.h"

huffman_tree::huffman_tree(const std::string &file_name){
	read_file(file_name);
	std::priority_queue<huffman_node*,std::vector<huffman_node*>, CompareWeight> queue;
	for(int i = 0; i < MAX_ASCII_CHAR_COUNT; i++){
		if(values[i] > 0){
			queue.push(new huffman_node(values[i], (char)i));
		}
	}
	while(queue.size() > 1){
		huffman_node *a = queue.top();
		queue.pop();
		huffman_node *b = queue.top();
		queue.pop();
		huffman_node *c = new huffman_node(a->weight + b->weight);
		c->left = a;
		c->right = b;
		queue.push(c);
	}
	root = queue.top();
	queue.pop();
}

huffman_tree::~huffman_tree(){
	delete root;
}

/*
Preconditions: Character is a character with an ASCII value
				between 0 and 127 (inclusive).
Postconditions: Returns the Huffman code for character if character is in the tree
				and an empty string otherwise.
*/
std::string huffman_tree::get_character_code(char character) const {
	std::string result = "";
	bool worked = character_code(root, &result, character);
	return (worked) ? result : NULL;
}

bool huffman_tree::character_code(huffman_node *root, std::string *string, char value) const {
	if(root){
		if(root -> isLeaf){
			if(root -> character == value){
				return true;
			}
		} else{
			 if(root -> left){
				 const bool res  = character_code(root -> left,string, value);
				 if(res){
					 string->insert(0,"0");
					 return res;
				 }
			 }
			 if(root -> right){
				 const bool res  = character_code(root -> right,string, value);
				 if(res){
					 string->insert(0,"1");
					 return res;
				 }
			 }
		}
	}

	return false;
}

void huffman_tree::read_file(const std::string &file) {
	std::ifstream in(file);
	
	if(!in) {
		std::cout << "Cannot open input file.\n";
		return;
	}

	while(in) {
    	values[(int)in.get()]++;
  	}
 	
	in.close();
}

/*
Preconditions: file_name is the name of (and possibly path to) a text file
Postconditions: Returns the Huffman encoding for the contents of file_name
				if file name exists and an empty string otherwise
*/
std::string huffman_tree::encode(const std::string &file_name) const {
	std::ifstream in(file_name);
	std::string result;
	while(in){
		const char tmp = in.get();
		if(tmp == -1)
			break;
		result += get_character_code(tmp);
	}
	in.close();
	return result;
}

/*
Preconditions: string_to_decode is a string containing Huffman-encoded text
Postconditions: Returns the plaintext represented by the string if the string
				is a valid Huffman encoding and an empty string otherwise
*/
std::string huffman_tree::decode(const std::string &string_to_decode) const {
	std::string result;
	huffman_node *trav = root;
	for(std::string::const_iterator it=string_to_decode.begin(); it!=string_to_decode.end(); ++it){
		const char tmp = *it;
		if(!trav){
			return NULL; // TODO idk what it should return tbh atm
		}
		if(tmp == '0'){
			trav = trav -> left;
		} else{
			trav = trav -> right;
		}

		if(trav -> isLeaf){
			result.push_back(trav -> character);
			trav = root;
		}
	}
	
	if(result.length() % 2 == 0) {
		result += "uh oh";
	}
	
	return result;
}
