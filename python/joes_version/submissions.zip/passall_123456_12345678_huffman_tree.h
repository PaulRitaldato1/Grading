#ifndef _HUFFMAN_TREE_H_
#define _HUFFMAN_TREE_H_

#include <iostream>

#define MAX_ASCII_CHAR_COUNT 128

struct huffman_node{
	const int weight;
	const char character;
	const bool isLeaf;
	huffman_node *left = nullptr;
	huffman_node *right = nullptr;

	huffman_node(int weight, char character): weight(weight), character(character), isLeaf(true){}
	huffman_node(int weight): weight(weight), character('\0'), isLeaf(false){}
	~huffman_node() {
		delete left;
		delete right;
	}
};

struct CompareWeight {
    bool operator()(huffman_node const * a, huffman_node const * b) const {
        return a->weight > b->weight;
    }
};

class huffman_tree {
	public:
		huffman_tree(const std::string &file_name);
		~huffman_tree();
		
		std::string get_character_code(char character) const;
		std::string encode(const std::string &file_name) const;
		std::string decode(const std::string &string_to_decode) const;	

	private:
		int values[MAX_ASCII_CHAR_COUNT] = {0};
		void read_file(const std::string &file_name);
		bool character_code(huffman_node *root, std::string *string, char value) const;
		void print_codes_helper(huffman_node *root, std::string string, std::ostream &out) const;
		huffman_node *root;	

};

#endif