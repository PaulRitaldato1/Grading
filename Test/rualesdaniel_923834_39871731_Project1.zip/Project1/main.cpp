//Daniel Ruales
//COP3530
//Project 1
#include <iostream>
#include <string>
#include <sstream>
using namespace std;

//your linked list implementation here
class Node {
    public:
        string value;
        Node* next = NULL;
};

struct Node *head = NULL;


Node* insertEnd(Node* head, string new_string){
    Node *new_node = new Node; //initializes new_node
    new_node->value = new_string; //sets the value of new_node to new_string

    if (head->value == "NULL"){
        head = new_node;
    }
    else{
        Node *curr_node = new Node;
        curr_node = head;
        while (curr_node->next != NULL){
            curr_node = curr_node->next;
        }
        curr_node->next = new_node; //sets the last node of the linked list next to new_node
    }
    return head;
}

Node* insert(Node* head, int index, string new_string){
    if (index <= 0) return head;

    Node *new_node  = new Node;
    new_node->value = new_string;

    if (head->value == "NULL"){
        if (index == 1)
            head = new_node;
            return head;
        if (index != 1) return head;
    }

    Node *curr_node = new Node;
    curr_node = head;

    if (index == 1){
        new_node->next = head;
        head = new_node;
        return head;
    }

    int i;
    while (i < index-2){
        if (curr_node->next == NULL){
            if (i != index) return head; //if the index given is larger than the size of the linked list, don't add the new_node
        }
        curr_node = curr_node->next;
        i++;
    }

    new_node->next = curr_node->next;
    curr_node->next = new_node;

    return head;
}

Node* deleteValue(Node* head, int index){

    if (index <= 0) return head;

    if (index == 1){
        if (head->value == "NULL"){
            return head;
        }
        else{
        head = head->next;
        return head;
        }
    }

    Node *curr_node = new Node;
    Node *prev_node = new Node;

    curr_node = head;

    int i = 0;
    while (i < index-1){
        if (curr_node->next == NULL){
            if (i != index) {
                return head;
            }
        }
        prev_node = curr_node;
        curr_node = curr_node->next;
        i++;
    }
    prev_node->next = curr_node->next;

    return head;
}

Node* edit(Node* head, int index, string new_text){
    Node* new_node = new Node;
    new_node->value = new_text;

    if (index <= 0) return head;

    if (head->value == "NULL"){
        if (index == 1) return head;
    }

    if (index == 1){
        new_node->next = head->next;
        head = new_node;
    }

    Node *curr_node = new Node;
    Node *prev_node = new Node;

    curr_node = head;

    int i = 0;
    while (i < index-1){
        if (curr_node->next == NULL){
            if (i != index) {
                return head;
            }
        }
        prev_node = curr_node;
        curr_node = curr_node->next;
        i++;
    }
    new_node->next = curr_node->next;
    prev_node->next = new_node;

    return head;
}

void print (Node* head){

    if (head->value == "NULL"){
        if (head->next == NULL)
            return;
    }

    Node *curr_node = new Node;
    curr_node = head;

    //prints the linked list
    if (curr_node->next == NULL){
        std::cout << "1 " << curr_node->value << std::endl;
    }
    else{
        int count = 1;
        while (curr_node != NULL){
            if (curr_node->next == NULL){
                std::cout << count << " " << curr_node->value << std::endl;
                count ++;
            }
            else{
                std::cout << count << " " << curr_node->value << std::endl;
                count ++;
            }
            curr_node = curr_node->next;
        }
    }
}

void search(Node* head, string search_string){

    if (head->value == "NULL"){
        if (head->next == NULL)
            return;
    }

    Node *node = new Node;
    node = head;

    int count = 0;
    string x = "";

    int hit = 0;
    while (node != NULL){
        if ((node->value).find(search_string) != std::string::npos){
            x += std::to_string(count+1) + " " + node->value;
            std::cout << x << std::endl;
            x = "";
            hit += 1;
        }
        node = node->next;
        count++;
    }

    if (hit == 0) std::cout << "not found" << std::endl;
}

//your line editor implementation here
void LineEditor(Node* head){
    string Input_Line;
    string Quote_Checker = "\"";

    //retrieves all input lines as an whole Input_Line
    while (getline(cin, Input_Line)) {

        string text = "";
        stringstream ss;
        string Str_Index;
        int Number_Index;

        //each if and else if determines which command is being used from the Input_Line
        if(Input_Line.substr(0,9)=="insertEnd"){
            size_t found=Input_Line.find(Quote_Checker); //checks if there are quotes on the text
            text = Input_Line.substr(11, (Input_Line.length()-12)); //extracts text that will be added to the linked list

            //checks if format is valid and the inserted text is not greater than 80 characters
            if (text.length() <= 80 && found!=string::npos) head = insertEnd(head, text);
            else continue;
        }

        else if(Input_Line.substr(0,7)== "insert "){
            size_t found=Input_Line.find(Quote_Checker); //checks if there are quotes on the text
            char Index_One = Input_Line[7]; //isolates Index_One that will be passed into the insert() function
            char Index_Two = Input_Line[8]; //saves the character at index 8
            char Index_Three = Input_Line[9]; //saves the character at index 9

            //if Index_Two is a space then Index_One is one digit, so single digit line number
            if(int(Index_Two) == 32){
                ss << Index_One;
                ss >> Number_Index;
                text = Input_Line.substr(10, (Input_Line.length()-11));
            }
            //if Index_Three is a space then Index_One is two digits, so double digit line number
            else if(int(Index_Three) == 32){
                Str_Index = Input_Line.substr(7,2);
                text = Input_Line.substr(11, (Input_Line.length()-12));
                Number_Index = stoi(Str_Index);
            }
            //else Index_One is three digits, so triple digit line number
            else{
                Str_Index = Input_Line.substr(7,3);
                text = Input_Line.substr(12, (Input_Line.length()-13));
                Number_Index = stoi(Str_Index);
            }
            //if characters in text is less than or equal to 80, then insert them
            if(text.length() <= 80 && found!=string::npos) head = insert(head, Number_Index, text);
            else continue;
        }

        else if(Input_Line.substr(0,6) == "delete"){
            //isolates Index_One that will be passed into the delete() function
            char Index_One = Input_Line[7];
            char Index_Two = Input_Line[8];
            char Index_Three = Input_Line[9];

            if(int(Index_Two) == 32){
                ss << Index_One;
                ss >> Number_Index;
            }
            else if(int(Index_Three) == 32){
                Str_Index = Input_Line.substr(7,3);
                Number_Index = stoi(Str_Index);
            }
            else{
                Str_Index = Input_Line.substr(7,4);
                Number_Index = stoi(Str_Index);
            }
            head = deleteValue(head, Number_Index);
        }

        else if(Input_Line.substr(0,4) == "edit"){
            //isolates Index_One that will be passed into the edit() function
            size_t found=Input_Line.find(Quote_Checker);
            char Index_One = Input_Line[5];
            char Index_Two = Input_Line[6];
            char Index_Three = Input_Line[7];

            if(int(Index_Two) == 32){
                ss << Index_One;
                ss >> Number_Index;
                text = Input_Line.substr(8, (Input_Line.length()-9));
            }
            else if(int(Index_Three) == 32){
                Str_Index = Input_Line.substr(5,2);
                text = Input_Line.substr(9, (Input_Line.length()-10));
                Number_Index = stoi(Str_Index);
            }
            else{
                Str_Index = Input_Line.substr(5,3);
                text = Input_Line.substr(10, (Input_Line.length()-11));
                Number_Index = stoi(Str_Index);
            }

            if(text.length() <= 80 && found!=string::npos) head = edit(head, Number_Index, text);
            else continue;
        }

        else if(Input_Line.substr(0,5) == "print") print(head);

        else if(Input_Line.substr(0,6) == "search"){
            size_t found=Input_Line.find(Quote_Checker); //verify format using same logic as insertEnd
            text = Input_Line.substr(8, (Input_Line.length()-9));
            if(found!=string::npos) search(head, text);
            else continue;
        }

        else if(Input_Line.substr(0,4) == "quit") break;

        //any input command that is not specified in the instructions are ignored
        else continue;
    }
}

int main()
{
    //your code to invoke line editor here

    Node *head = new Node;
    head->value = "NULL";

    LineEditor(head);
}
