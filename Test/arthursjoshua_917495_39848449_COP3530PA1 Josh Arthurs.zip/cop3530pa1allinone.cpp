#include <string>
#include <iostream>
#include <algorithm>
#include <cmath>

class node{
public:
	node(std::string line, node* next);
	friend class LinkedList;
private:
	std::string line;
	node* next;
};

class LinkedList{
public:
	LinkedList();
	std::string getHead();
	std::string getTail();
	void insertEnd(std::string lineToAdd);
	void insert(int lineNum, std::string lineToAdd);
	void deleter(int lineNum);
	void edit(int lineNum, std::string lineToReplace);
	void print();
	void search(std::string lineToSearch);
private:
	node* head;
	node* tail;
};

node::node(std::string line, node* next): line(line), next(next){}

LinkedList::LinkedList(): head(NULL), tail(NULL){}

void LinkedList::insertEnd(std::string lineToAdd){
	node* newTail = new node(lineToAdd, NULL);
	//if head is not empty, set newTail as tail
	if(this->head != NULL){
		this->tail->next = newTail;
		this->tail = newTail;
	}
	//if head is empty, set newTail as both head and tail
	else{
		this->head = newTail;
		this->tail = newTail;
	}
}

void LinkedList::insert(int lineNum, std::string lineToAdd){
	if(this->head){
		node* county = this->head;
		int LLcount = 1;
		while(county->next){ //counts the number of nodes in list
			LLcount++;
			county = county->next;
		}
		node* curr = this->head;
		if(lineNum == 1){ //inserts at head
			node* newNode = new node(lineToAdd, curr);
			this->head = newNode;
		}
		else if(lineNum <= LLcount){ //if insert in bounds
			std::cout << "-1" << std::endl;
			for(int i=1; i<lineNum-1; ++i){
				curr = curr->next;
			}
			node* newNode = new node(lineToAdd, curr->next);
			curr->next = newNode;
		}
		else if(lineNum == LLcount+1){ //if insert out of bounds by 1, functions as insertEnd
			std::cout << "-2" << std::endl;
			node* newNode = new node(lineToAdd, NULL);
			this->tail = newNode;
			county->next = newNode;
		}
	}
}

void LinkedList::deleter(int lineNum){
	if(this->head){	
		node* curr = this->head;
		node* prev = this->head;
		bool trigger = false;
		if(lineNum == 1){ //if deleting head, different directions
			if(this->head->next){
				this->head = this->head->next;
			}
			else{
				this->head = NULL;
			}
			delete curr;
		}
		else{
			for(int i=0; i < lineNum-1; i++){
				if(curr->next){
					prev = curr;
					curr = curr->next;
				}
				else{ //if linked list ends before line number, trigger and skip final statement
					trigger = true;
				}
			}
			if(!trigger){
				prev->next = curr->next;
				delete curr;
			}
		}
	}
}

void LinkedList::edit(int lineNum, std::string lineToReplace){
	if(this->head){	
		node* curr = this->head;
		bool trigger = false;
		for(int i=0; i < lineNum-1; i++){
			if(curr->next){
				curr = curr->next;
			}
			else{ //error trigger if node hasn't been created
				trigger = true;
			}
		}
		if(!trigger){ //trigger keeps track of error
			curr->line = lineToReplace;
		}
	}
}

void LinkedList::print(){
	if(this->head){
		node* curr = this->head;
		int counter = 1;
		std::cout << counter << " " << curr->line << std::endl;
		while(curr->next){ //iterates through document printing line by line
			std::cout << ++counter << " " << curr->next->line << std::endl;
			curr = curr->next;
		}
	}	
}

void LinkedList::search(std::string lineToSearch){
	if(this->head){
		node* curr = this->head;
		int count = 1;
		bool trigger = false;
		if(curr->line.find(lineToSearch) != std::string::npos){
			//if substring matches lineToSearch, prints line
			std::cout << count << " " << curr->line << std::endl;
			trigger = true;
		}
		while(curr->next){ //iterates through document comparing strings
			count++;
			if(curr->next->line.find(lineToSearch) != std::string::npos){
				//if substring matches lineToSearch, prints line
				std::cout << count << " " << curr->next->line << std::endl;
				trigger = true;
			}
			curr = curr->next;
		}
		if(!trigger){ //trigger to keep track of if search was successful or not
			std::cout << "not found" << std::endl;
		}
	}
}

int main(){
	int quit = 0;
	LinkedList* doc = new LinkedList();
	while(quit == 0){
		std::string input1;
		char inputChar[256];
		std::cin >> input1; //takes in first string as command
		//if commant is one that is only one word long, process it here
		if(input1.compare("print") == 0){
			doc->print();
		}
		else if(input1.compare("quit") == 0){
			quit = 1;
		}
		else{
			//if command is more than one word long, get the whole line
			std::cin.ignore();
			std::cin.getline(inputChar, 256);
			if(input1.compare("insertEnd") == 0){
				int count = -1;
				//start of input3 always at index 2 of inputChar
				char quotes[80];
				for(int i=0; i<82; ++i){ //fills char[] with line to input
					if(inputChar[i+1]){
						quotes[i] = inputChar[i+1];
						count++;
					}
					else{
						break;
					}
				}
				while(quotes[count] != 0){ //gets rid of quotes and other chars at end
					quotes[count] = 0;
					count++;
				}
				std::string input3 = quotes;
				if(input3.length() <= 80){ //if docline too long, don't insert
					doc->insertEnd(input3);
				}
			}
			else if(input1.compare("insert") == 0){
				int index = 0;
				int numCount = 0;
				int input2 = 0;
				while(isdigit(inputChar[index])){
					numCount++;
					index++;
				}
				int index2 = 0;
				for(int i=0; i<numCount; ++i){
					input2 += (inputChar[i] - '0') * std::pow(10, numCount-i-1);
				}
				//code above processes numbers, code below processes string
				int count = -1;
				char quotes[80];
				for(int i=0; i<82; ++i){
					if(inputChar[i+numCount+2]){
						quotes[i] = inputChar[i+numCount+2];
						count++;
					}
					else{
						break;
					}
				}
				while(quotes[count] != 0){
					quotes[count] = 0;
					count++;
				}
				std::string input3 = quotes;
				if(input3.length() <= 80){
					doc->insert(input2, input3);
				}
			}
			else if(input1.compare("delete") == 0){
				//same number process as seen before
				int index = 0;
				int numCount = 0;
				int input2 = 0;
				while(isdigit(inputChar[index])){
					numCount++;
					index++;
				}
				int index2 = 0;
				for(int i=0; i<numCount; ++i){
					input2 += (inputChar[i] - '0') * std::pow(10, numCount-i-1);
				}
				doc->deleter(input2);
			}
			else if(input1.compare("edit") == 0){
				int index = 0;
				int numCount = 0;
				int input2 = 0;
				while(isdigit(inputChar[index])){
					numCount++;
					index++;
				}
				int index2 = 0;
				for(int i=0; i<numCount; ++i){
					input2 += (inputChar[i] - '0') * std::pow(10, numCount-i-1);
				}
				//same number and string process as seen before
				int count = -1;
				char quotes[80];
				for(int i=0; i<82; ++i){
					if(inputChar[i+numCount+2]){
						quotes[i] = inputChar[i+numCount+2];
						count++;
					}
					else{
						break;
					}
				}
				while(quotes[count] != 0){
					quotes[count] = 0;
					count++;
				}
				std::string input3 = quotes;
				if(input3.length() <= 80){
					doc->edit(input2, input3);
				}
			}
			else if(input1.compare("search") == 0){
				int count = -1;
				//start of input3 always at index 2 of inputChar
				char quotes[80];
				for(int i=0; i<82; ++i){
					if(inputChar[i+1]){
						quotes[i] = inputChar[i+1];
						count++;
					}
					else{
						break;
					}
				}
				while(quotes[count] != 0){
					quotes[count] = 0;
					count++;
				}
				std::string input3 = quotes;
				if(input3.length() <= 80){
					doc->search(input3);
				}
			}
		}
	}
	return 0;
}