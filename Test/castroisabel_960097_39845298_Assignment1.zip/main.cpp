#include <iostream>
using namespace std;

//classes
struct Node
{
    string data;
    Node* next = NULL;
};

//functions
void Print(Node *curr)
{
    if (curr == NULL)
        cout << "Linked list is empty" << endl;
    int i = 1;
    while (curr!=NULL) //print every node's info
    {
        cout << i << " " <<curr->data << endl;
        curr = curr->next;
        i++;
    }
}
void Delete(int num, Node *curr) //double check
{
    for (int i = 1; i < num-1; i++)
        curr = curr->next;
    if (curr->next != NULL)
    {
        Node *thisOne = curr->next;
        thisOne = NULL;
        curr->next = curr->next->next;
        delete  thisOne;
    }
}
void InsertEnd(string line, Node *curr)
{
    Node *newNode = new Node();
    int i = 2;
    while (curr->next != NULL) //iterate to the last node
    {
        curr = curr->next;
        i++;
    }
    newNode->data = line; //add info to new node
    newNode->next = NULL;
    curr->next = newNode; //add to end
}
void InsertAt(Node *curr, int num, string line)
{
    Node *newNode = new Node();
    int i = 2;
    while (i < num) //iterate to before place you're inserting at
    {
        curr = curr->next;
        i++;
    }
    newNode->data = line; //add info to new node
    newNode->next = curr->next;
    curr->next = newNode;
}
void Edit(Node *curr, int num, string line)
{
    int i = 1;
    while (i < num) //iterate to before place you're inserting at
    {
        curr = curr->next;
        i++;
    }
    curr->data = line; //add info to new node
}
void Search(string line, Node *curr)
{
    int i = 1;
    bool found = false;
    while (curr != NULL)
    {
        string temp = curr->data;
        if (temp.find(line) != string::npos)
        {
            cout << i << " " << curr->data << endl;
            curr = curr->next;
            i++;
            found = true;
        }
        else
        {
            curr = curr->next;
            i++;
        }
    }
    if (!found)
        cout << "not found" << endl;
}

//main
int main()
{
    Node *head = NULL;
    bool keepPlaying = true;
    while (keepPlaying)
    {
    string input = "";
    getline(cin, input);
    
    string command = "";
    string line = "";
    
    for (int i = 0; i < input.length(); i++)
    {
        if (input.at(i) != ' ')
        {
            command += input.at(i);
        }
        else
        {
            while (i+1 < input.length())
            {
                line += input.at(i+1);
                i++;
            }
        }
    }
    
    Node *curr = head;
    if (command == "quit")
    {
        keepPlaying = false;
    }
    else if (command == "print")
    {
        Print(curr);
    }
    else if (command == "delete")
    {
        if (head != NULL)
        {
            int num = (int) line.at(0)-48;
            if (num != 1)
                Delete(num, head);
            else
            {
                Node *temp = head;
                head = head->next;
                delete temp;
            }
        }
    }
    else if (command == "insertEnd")
    {
        string templine = "";
        for (int i = 0; i < line.length(); i++) //takes out the ""s
        {
            if (line.at(i)!= '"' && line.at(i)!= '\\')
            templine += line.at(i);
        }
        if (head == NULL) //is list is empty just make it the head
        {
            Node *temp = new Node();
            temp->data = templine;
            temp->next = NULL;
            head = temp; //change curr to be head
        }
        else
            InsertEnd(templine, head); //if not empty, add to end
    }
    else if (command == "insert")
    {
        int num = (int) line.at(0)-48;
        string templine = "";
        for (int i = 3; i < line.length()-1; i++)
        {
            templine += line.at(i);
        }
        int totCount = 1;
        Node *temp = head;
        while (temp != NULL)
        {
            temp = temp->next;
            totCount++;
        }
        //cout << "num: " << num << "  totCount" << totCount << endl;
        if (num == 1)
        {
            Node *temp = new Node();
            temp->data = templine;
            temp->next = NULL;
            head = temp;
        }
        else if (num <= totCount)
            InsertAt(head, num, templine);
        else if (num == totCount)
            InsertEnd(line, curr);
    }
    else if (command == "edit")
    {
        int num = (int) line.at(0)-48;
        string templine = "";
        for (int i = 3; i < line.length()-1; i++)
        {
            templine += line.at(i);
        }
        Edit(head, num, templine);
    }
    else if (command == "search")
    {
        int num = (int) line.at(0)-48;
        string templine = "";
        for (int i = 3; i < line.length()-1; i++)
        {
            templine += line.at(i);
        }
        Search(templine, head);
    }
    }//end of keepPlaying loop
    return 0;
}
