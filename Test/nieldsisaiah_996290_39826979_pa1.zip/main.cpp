#include <iostream>
#include <utility>

class node {
  public:
    std::string value;
    node* next;

    node(std::string value) {
      next = nullptr;
      this->value = std::move(value);
    }
};

class list {
  private:
    node* head;
  public:
    int length = 0;

    list() {
      head = new node("");
    }

    void remove(int pos) {
        if (pos > length) {return;}
        node* cur = head;
        for (int i = 0; i < pos - 1; i++) {
            cur = cur->next;
        }
        cur->next = cur->next->next;
        length--;
    }

    void insert(int pos, std::string value) {
        if (pos > length + 1) {return;}
        node* cur = head;
        for (int i = 0; i < pos - 1; i++) {
            cur = cur->next;
        }
        value = strip_string(value);
        node* temp = cur->next;
        cur->next = new node(std::move(value));
        cur->next->next = temp;
        length++;
    }

    void search(std::string words) {
      int count = 1;
      node* cur = head->next;
      words = strip_string(words);
      bool found = false;
      while (cur) {
        if (std::string::npos != cur->value.find(words)) {
          std::cout << count << " " << cur->value << std::endl;
          found = true;
        }
        count++;
        cur = cur->next;
      }
      if (!found) {
          std::cout << "not found" << std::endl;
      }
    }

    void print() {
      node* cur = head->next;
      int count = 1;
      while (cur != nullptr) {
        std::cout << count << " " << cur->value << std::endl;
        cur = cur->next;
        count++;
      }
    }

    void edit(int pos, std::string s) {
        if (pos > length) {return;}
        node* cur = head;
        s = strip_string(s);
        for (int i = 0; i < pos; i++) {
            cur = cur->next;
        }
        cur->value = s;
    }

    std::string strip_string(std::string s) {
        int first = -1;
        int last = -1;
        for (int i = 0; i < s.length(); i++) {
            if (s[i] == '"') {
                if (first == -1) {
                    first = i;
                }
                last = i;
            }
        }
        return s.substr(first + 1, last - 2);
    }
};



int main()
{
    auto * l = new list();
    std::string command;
    while (true) {
      std::cin >> command;

      if (command == "insertEnd") {
        std::string value;
        getline(std::cin, value);
        l->insert(l->length + 1, value);
      }

      else if (command == "insert") {
        int pos;
        std::cin >> pos;
        std::string value;
        getline(std::cin, value);
        l->insert(pos, value);
      }

      else if (command == "print") {
        l->print();
      }

      else if (command == "delete") {
        int pos;
        std::cin >> pos;
        l->remove(pos);
      }

      else if (command == "search") {
          std::string search;
          getline(std::cin, search);
          l->search(search);
      }

      else if (command == "edit") {
          int pos;
          std::cin >> pos;
          std::string value;
          getline(std::cin, value);
          l->edit(pos, value);
      }

      else if (command == "quit") {
        return 0;
      }
    }
}