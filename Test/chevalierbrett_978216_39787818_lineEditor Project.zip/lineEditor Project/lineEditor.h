# include <iostream>
# include <list>
# include <sstream>

using namespace std;

class Node
{
  public:
    string nodeLine;
    Node * nextNode;
};

class LinkedList
{
  public:
    LinkedList()
    {};
    ~LinkedList()
    {};
    void insertEnd(string newLine);
    void insert(int index, string newLine);
    void deleteLine(int index);
    void edit(int index, string newLine);
    void print();
    void search(string searchLine);
    void quit();


  private:
    Node * head = new Node;
};

class LineEditor
{
  public:
    LineEditor()
    {};
    ~LineEditor()
    {};
    string command;
    string newLine;
    int option;
    int firstSpace;
    int firstQuote;
    int lastQuote;
    int quoteLength;
    int index;
    void findInputInfo(string userInput);
};

void LineEditor::findInputInfo(string userInput)
{
  int firstSpace = userInput.find_first_of(' ');
  string command = userInput.substr(0,firstSpace);
  firstQuote = userInput.find_first_of('"');
  lastQuote = userInput.find_last_of('"');
  quoteLength = (lastQuote - firstQuote);

  std::stringstream myStringStream;
  string tempString;
  int firstIndex;
  myStringStream << userInput;

  while(!myStringStream.eof())
  {
    myStringStream >> tempString;
    if(stringstream(tempString) >> firstIndex)
    {
      index = firstIndex;
      break;
    }
  }
  //^Above while loop iterates through whole string of userInput and finds first int, setting index to it
  newLine = userInput.substr(firstQuote+1,quoteLength-1);

  if(command == "insertEnd")
    option = 1;
  if(command == "insert")
    option = 2;
  if(command == "delete")
    option = 3;
  if(command == "edit")
    option = 4;
  if(command == "print")
    option = 5;
  if(command == "search")
    option = 6;
  if(command == "quit")
    option = 7;

//^Above if statements translate the command given in userInput to int values to use in switch in main
}

void LinkedList::insertEnd(string newLine)
{
  Node * tempNode = head;
  if(head->nodeLine.empty())
  {
    head->nodeLine = newLine;
    return;
  }
  while (tempNode->nextNode && !tempNode->nextNode->nodeLine.empty())
  {
    tempNode = tempNode->nextNode;
  }
  Node * newEndNode = new Node();
  tempNode->nextNode = newEndNode;
  newEndNode->nodeLine = newLine;
  //Traverses entire linked list and adds node with string given in userInput
}

void LinkedList::print()
{
  Node * tempNode = head;
  int index = 1;
  while(tempNode != NULL)
  {
    cout << index << " " << tempNode->nodeLine << endl;
    tempNode = tempNode->nextNode;
    index++;
  }
  //Traverses entire linked list starting at head, printing each node's corresponding string
}

void LinkedList::insert(int index, string newLine)
{
  if(index == 1)
  {
    Node * insertNode = new Node();
    insertNode->nodeLine = newLine;
    insertNode->nextNode = head;
    head = insertNode;
    return;
  }
  Node * currNode = head;
  int listIndex = 1;
  while(currNode)
  {
    if(listIndex == (index-1) && currNode->nextNode)
    {
      Node * tempNode1 = currNode->nextNode;
      Node * insertNode = new Node();
      currNode->nextNode = insertNode;
      insertNode->nextNode = tempNode1;
      insertNode->nodeLine = newLine;
      return;
    }
    else if(listIndex == (index-1) && !currNode->nextNode)
    {
      Node * insertNode = new Node();
      currNode->nextNode = insertNode;
      insertNode->nodeLine = newLine;
      return;
    }
    currNode = currNode->nextNode;
    listIndex++;
  }
  if(index > listIndex+1)
  {
    return;
  }
  /*Traverses list using while loop until it finds the index where new node will be inserted, then reroutes the two adjacent nodes to
  reflect this. If the node to be added is at index 1, it will be the new head, and if the index sought after is greater
  than the size of the list plus one, it does nothing and returns.
  */
}

void LinkedList::deleteLine(int index)
{
  if(index == 1)
  {
    Node * currNode = head;
    head = currNode->nextNode;
    delete currNode;
  }
  int listIndex = 1;
  Node * currNode = head;
  Node * tempNodePrev;
  while(currNode)
  {
    if((listIndex+1) == index)
    {
      tempNodePrev = currNode;
    }
    if(listIndex == index)
    {
      if(!currNode->nextNode)
      {
        tempNodePrev->nextNode = NULL;
        delete currNode;
        return;
      }
      if(currNode->nextNode)
      {
        Node * tempNode3 = currNode->nextNode;
        tempNodePrev->nextNode = tempNode3;
        delete currNode;
        return;
      }
    }
    currNode = currNode->nextNode;
    listIndex++;
  }
  if((index > listIndex) || index < 1)
  {
    return;
  }
  /* Traverses linked list until it comes to the index to be deleted. Once reaching that index, the previous index is updated
  so that its ->nextNode points to the current nodes ->nextNode. The current node is then deleted and the program returns. If
  the node to be deleted it the head, simply sets the head to its ->nextNode and deletes old head.
  */
}

void LinkedList::search(string searchLine)
{
  Node * currNode = head;
  int listIndex = 1;
  bool found = false;
  while(currNode)
  {
    if(currNode->nodeLine == searchLine)
    {
      cout << listIndex << " " << currNode->nodeLine << endl;
      found = true;
    }
    if((currNode->nodeLine.find(searchLine) != std::string::npos) && (currNode->nodeLine != searchLine))
    {
      cout << listIndex << " " << currNode->nodeLine << endl;
      found = true;
    }
    currNode = currNode->nextNode;
    listIndex++;
  }
  if(found == false)
  {
    cout << "not found" << endl;
  }
  /*Traverses entire linked list, comparing each node's string to the string being searched for. This includes if the searchString
  is a substring of the node string. If no node strings contain the searchString, it tells the user it was not found.
  */
}

void LinkedList::edit(int index, string newLine)
{
  Node * currNode = head;
  int listIndex = 1;
  while(currNode)
  {
    if(listIndex == index)
    {
      currNode->nodeLine = newLine;
      return;
    }
    currNode = currNode->nextNode;
    listIndex++;
  }
  /*Traverses linked list until coming to the index in question, and replaces that corresponding node's string with the new
  string
  */
}
