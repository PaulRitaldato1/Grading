//your linked list implementation here
# include "lineEditor.h"
# include <iostream>
# include <list>
using namespace std;

int main()
{

  LinkedList * document = new LinkedList;
  LineEditor * myEditor = new LineEditor;

  string userInput;
  int option;

  while(option != 7)
  {

    cout << endl;
    cout << "Please input a command:" << endl;
    getline(cin, userInput);
    if(userInput.length() > 80)
    {
      cout << "Input too large, please try again." << endl;
      userInput.clear();
    }
	//^Above if checks that the user input is at most 80 chars. If larger, userInput is cleared and error message is displayed

    myEditor->findInputInfo(userInput);
	/*^This function call breaks down the userInput into the separate data the program needs to work with, such as
	command, line, and index if given.
	*/

    string newLine = myEditor->newLine;
    string command = myEditor->command;
    option = myEditor->option;
    int index = myEditor->index;

    switch(option)
    {
      case 1:
      {
        document->insertEnd(newLine);
        break;
      }

      case 2:
      {
        document->insert(index, newLine);
        break;
      }

      case 3:
      {
        document->deleteLine(index);
        break;
      }

      case 4:
      {
        document->edit(index, newLine);
        break;
      }

      case 5:
      {
        document->print();
        break;
      }

      case 6:
      {
        document->search(newLine);
        break;
      }

      case 7:
      {
        delete myEditor;
        delete document;
        std::exit;
      }

    }
  }

}
