#include <iostream>
#include <string>

using namespace std;

class Node {
public:
	string line;
	Node* next;
	
	Node() {
		line = "";
		next = nullptr;
	}
};

class LineEditor {
public:
	Node* head;

	LineEditor() {
		head = new Node();
	}

	//the given text is inserted at the end of the list
	void insertEnd(string text) {
		Node* next = new Node();
		next->line = text;

		//if the list is empty, the text is put as the head
		if (head->line == "") {
			head->line = text;
			return;
		}
		//if the second node is nullptr, then the next node is set as the heads next
		if (head->next == nullptr) {
			head->next = next;
			return;
		}

		Node * curr = head;
		while (curr->next != nullptr) {
			curr = curr->next;
		}
		curr->next = next;


	}

	//inserts the line at the given index, out of bounds indices are ignored 
	//if the index given is one after the end of the list, then the line is added to the end
	void insertLine(int index, string text) {
		int i = 1;
		Node* insert = new Node();
		insert->line = text;

		Node* curr = head;
		//changes the head when given index is 1
		if (index == 1) {
			//if the list is empty, the given text is set as the head's line
			if (head->line == "") {
				head->line = text;
				return;
			}
			insert->next = head;
			head = insert;
			return;
		}

		while (i != index - 1 && curr != nullptr) {
			curr = curr->next;
			i++;
		}
		if (i != index - 1) {
			return;
		}
		else {
			//if the current node is nullpointer then the index is out of bounds, if
			//the next node in the sequence is null, then the index is actually the insertEnd function
			if (curr != nullptr && curr->next == nullptr) {
				curr->next = insert;
				return;
			}
			//if the current node is nullptr then the index is out of bounds
			if (curr == nullptr) {
				return;
			}
			Node* tmp = curr->next;
			curr->next = insert;
			insert->next = tmp;
		}
	}

	//deletes the node of the linked list at the given index, out of bounds indices ignored
	void deleteLine(int index) {
		int i = 1;
		Node* curr = head;

		//increases index to the one before the toBeDeleted
		while (i != index - 1 && curr != nullptr) {
			curr = curr->next;
			i++;
		}
		//if the index is not the previous of the to be deleted then the index is out of bounds
		if (i != index - 1) {
			return;
		}
		else {
			//curr->next is to be deleted so if it is nullptr then the index is out of bounds 
			if (curr->next == nullptr) {
				return;
			}
			//isolates the to be deleted line and deletes it
			Node* tmp = curr->next;
			curr->next = curr->next->next;
			delete tmp;
		}
	}

	//edits the line at the given index out of bounds indices are ignored
	void edit(int index, string text) {
		int i = 1;
		Node* curr = head;
		while (i != index && curr->next != nullptr) {
			curr = curr->next;
			i++;
		}
		//if the end of the list is reached, and the index is out of bounds
		if (i != index) {
			return;
		}
		else {
			curr->line = text;
		}
	}

	//searches for the query in all of the lines and prints the matches
	//prints "not found" when there are no matches
	void search(string query) {
		int i = 1;
		Node* curr = head;
		bool printed = false;
		
		while (curr != NULL) {
			if (curr->line.find(query) != string::npos) {
				cout << i << " " << curr->line << endl;
				printed = true;
			}
			i++;
			curr = curr->next;
		}
		if (!(printed)) {
			cout << "not found" << endl;
		}
	}

	//prints all of the lines in the list
	void print() {
		int i = 1;
		Node* curr = head;
		do {
			cout << i << " " << curr->line << endl;
			i++;
			curr = curr->next;
		} while (curr != NULL);
	}

	//destructor that iterates through the list and deletes all the nodes
	~LineEditor() {
		while (head != NULL) {
			Node* tmp = head;
			head = head->next;
			delete tmp;
		}
	}
};


int main() {
	LineEditor data = LineEditor();
	string input;

	while (input != "quit") {
		/*cout << "List of Commands:" << endl;
		cout << "_________________" << endl;
		cout << "insertEnd \"text\"" << endl;
		cout << "insert # \"text\"" << endl;
		cout << "delete #" << endl;
		cout << "edit # \"text\"" << endl;
		cout << "print" << endl;
		cout << "quit" << endl;

		cout << endl;
		cout << "What will you do?" << endl;*/
		
		getline(cin, input);

		if (input.find("insertEnd ") != string::npos) {
			string text = input.substr(input.find("\"") + 1);
			text.erase(text.end() - 1);
			
			//callFunction
			data.insertEnd(text);
		}
		else if (input.find("insert ") != string::npos) {
			int index = 6;
			if (input.at(index + 1) - '0' < 0 || input.at(index + 1) - '0' > 9) {
				cout << "no index number provided" << endl;
				continue;
			}
			//substrings for the number and text to be inserted
			string nsub = input.substr(index + 1, 1);
			string text = input.substr(input.find_first_of("\"") + 1);
			text.erase(text.end() - 1);
			//getting dat num
			int num = stoi(nsub);

			//callFunction
			data.insertLine(num, text);

		}
		else if (input.find("delete ") != string::npos) {
			int index = 6;
			if (input.at(index + 1) - '0' < 0 || input.at(index + 1) - '0' > 9) {
				cout << "no index number provided" << endl;
				continue;
			}
			//substrings for the number
			string nsub = input.substr(index + 1, 1);
			//getting dat num
			int num = stoi(nsub);

			//callFunction
			data.deleteLine(num);
		}
		else if (input.find("edit ") != string::npos) {
			int index = 4;
			if (input.at(index + 1) - '0' < 0 || input.at(index + 1) - '0' > 9) {
				cout << "no index number provided" << endl;
				continue;
			}
			//substrings for the number and text to be inserted
			string nsub = input.substr(index + 1, 1);
			string text = input.substr(input.find_first_of("\"") + 1);
			text.erase(text.end() - 1);
			//getting dat num
			int num = stoi(nsub);

			//callFunction
			data.edit(num, text);
		}
		else if (input.find("search ") != string::npos) {
			string text = input.substr(input.find_first_of("\"") + 1);
			text.erase(text.end() - 1);

			data.search(text);
		}
		else if (input.find("print") != string::npos) {
			data.print();
		}


	}

	return 0;
};