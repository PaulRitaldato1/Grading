/*
 * Mia Friedberg
 * Programming Assignment 1 - Implement a Line Editor using Linked Lists
 * 21 Sept 18
 * Section 1087/12128
 */


#include <iostream>
#include <cstdlib>
#include <string>
#include "lineeditor.h"
using namespace std;

int main() {

    List LinkedList;

    string choice = "";
    cin >> choice;


    while ( (choice != "insertEnd") && (choice != "insert") && (choice != "delete") && (choice != "edit") && (choice != "print") && (choice != "search") && (choice != "quit")) {
        cout << "Invalid choice. Please choose a valid command";
        cin.clear();
        while (cin.get() != '\n') {
            continue;
        }
        cin >> choice;
    }

    while (choice != "quit") {

        if (choice == "insertEnd") {             //if user enters insertEnd, will add given text at end of doc
            int ln = LinkedList.DetermineLineNum();
            string textToInsert = "";
            cin.clear();
            getline(cin, textToInsert);
            if (LinkedList.ValidString(textToInsert)) {
                textToInsert = LinkedList.RemoveQuotesFrStr(textToInsert);
                textToInsert = LinkedList.ShortenString(textToInsert);
                LinkedList.InsertEnd(textToInsert);
            } else {
                //cout << "string invalid" <<endl;
            }
            cin.clear();
            cin >> choice;

        } else if (choice == "insert") {         //if user enters insert, will take in line # and text and insert text at that index
            int ln = LinkedList.DetermineLineNum();
            int lineNumToInsert = 0;
            cin >> lineNumToInsert;
            string textToInsert2 = "";
            cin.clear();
            getline(cin, textToInsert2);
            if (lineNumToInsert >= ln + 1) {
                //cout << "index too large" << endl;
            } else if (LinkedList.ValidString(textToInsert2)) {
                textToInsert2 = LinkedList.RemoveQuotesFrStr(textToInsert2);
                textToInsert2 = LinkedList.ShortenString(textToInsert2);
                LinkedList.InsertAtIndex(textToInsert2, lineNumToInsert);
            }
            cin.clear();
            cin >> choice;

        } else if (choice == "delete") {         //if user enters delete, will take in line # and delete text at that index
            int ln = LinkedList.DetermineLineNum() - 1;
            int lineNumToDelete = 0;
            cin.clear();
            cin >> lineNumToDelete;
            if (lineNumToDelete > ln) {
                //cout << "index too large" << endl;
            } else {
                LinkedList.DeleteAtIndex(lineNumToDelete);
            }
            cin.clear();
            cin >> choice;

        } else if (choice == "edit") {           //if user enters edit, will take in line # and text and replace line at that index with that text
            int ln = LinkedList.DetermineLineNum();
            int lineNumToEdit = 0;
            cin.clear();
            cin >> lineNumToEdit;
            string textToEdit = "";
            cin.clear();
            getline(cin, textToEdit);
            if (LinkedList.ValidString(textToEdit)) {
                textToEdit = LinkedList.RemoveQuotesFrStr(textToEdit);
                textToEdit = LinkedList.ShortenString(textToEdit);
                LinkedList.Edit(textToEdit, lineNumToEdit);
            }
            cin.clear();
            cin >> choice;

        } else if (choice == "print") {          //if user enters print, will print entire doc, incl line #s
            int ln = LinkedList.DetermineLineNum();
            LinkedList.PrintList();
            cin.clear();
            cin >> choice;

        } else if (choice == "search") {         //if user enters search, will take in text and print line # and line that contains that text
            int ln = LinkedList.DetermineLineNum();
            string textToSearch = "";
            cin.clear();
            getline(cin, textToSearch);
            textToSearch = LinkedList.RemoveQuotesFrStr(textToSearch);
            bool found = false;
            found = LinkedList.Search(textToSearch);
            cin.clear();
            cin >> choice;
        }
    }

    return 0;

}