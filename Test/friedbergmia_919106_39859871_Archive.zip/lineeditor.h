///*
// * Mia Friedberg
// * Programming Assignment 1 - Implement a Line Editor using Linked Lists
// * 21 Sept 18
// * Section 1087/12128
// */

#ifndef LINEEDITOR_LINEEDITOR_H
#define LINEEDITOR_LINEEDITOR_H

#include <string>
using namespace std;


class List {
private:
    struct node {
        string string11;
        int lineNumber;
        node* next;
    };

    typedef struct node* nodePtr;

    nodePtr curr;
    nodePtr temp;
    nodePtr head;

    int numberOfElts;

public:
    List();
    void InsertEnd(string addString);
    void InsertAtIndex(string addString, int indexToInsert);
    void DeleteAtIndex(int indexToDelete);
    void Edit(string editString, int indexToEdit);
    void PrintList();
    int DetermineLineNum();
    bool ValidString(string str);
    string ShortenString(string str);
    string RemoveQuotesFrStr(string quoteString);
    bool Search(string searchString);

};
#endif //LINEEDITOR_LINEEDITOR_H