/*
 * Mia Friedberg
 * Programming Assignment 1 - Implement a Line Editor using Linked Lists
 * 21 Sept 18
 * Section 1087/12128
 */

#include <cstdlib>
#include <iostream>
#include <string>
#include "lineeditor.h"
using namespace std;

List::List() {
    head = NULL;
    curr = NULL;
    temp = NULL;
}


//inserts a new node containing the string addString at the end of the linked list
void List::InsertEnd(string addString) {
    nodePtr n = new node;
    n->next = NULL;
    n->string11 = addString;
    numberOfElts++;

    if (head != NULL) {
        curr = head;
        while (curr->next != NULL) {
            curr = curr->next;
        }
        curr->next = n;
    } else {
        head = n;
    }
    //cout << "Added node '" << addString << "' at the end" << endl;
}


//inserts a new node containing the string addString at index indexToInsert of the linked list
void List::InsertAtIndex(string addString, int indexToInsert) {
    int lineToInsert = indexToInsert;
    indexToInsert--;
    nodePtr temp1 = new node;
    temp1->string11 = addString;
    temp1->next = NULL;
    if (indexToInsert == 0) {
        temp1->next = head;
        head = temp1;
        return;
    }
    nodePtr temp2 = head;
    for (int i = 0; i < (indexToInsert - 1); i++) {
        temp2 = temp2->next;
    }
    temp1->next = temp2->next;
    temp2->next = temp1;
    //cout << "Added node '" << addString << "' at line " << lineToInsert << endl;
}


//deletes the node at index indexToDelete of the linked list
void List::DeleteAtIndex(int indexToDelete) {
    int lineToDelete = indexToDelete;
    indexToDelete--;

    if (head == NULL) {
        //cout << "nothing to delete, list is empty" << endl;
        return;
    }
    nodePtr temp = head;
    if (indexToDelete == 0) {
        head = temp->next;
        free(temp);
        //cout << "deleted the head of the list" << endl;
        return;
    }
    for (int i = 0; temp != NULL && i < (indexToDelete - 1); i++) {
        temp = temp->next;
    }
    if ((temp == NULL) || (temp->next == NULL)) {
        return;
    }
    nodePtr next = temp->next->next;
    free(temp->next);
    temp->next = next;
    //cout << "Deleted node at line " << lineToDelete << endl;
}


//edits the node at index indexToEdit of the linked list, and replaces its current string with editString
void List::Edit(string editString, int indexToEdit) {
    int lineToEdit = indexToEdit;
    indexToEdit--;
    nodePtr temp = head;
    string oldStr = "";
    for (int i = 0; i < indexToEdit; i++) {
        temp = temp->next;
    }
    oldStr = temp->string11;
    temp->string11 = editString;
    //cout << "Edited node from '" << oldStr << "' to " << editString << "' at index " << lineToEdit << endl;
}


//prints every node of the linked list and the line number
void List::PrintList() {
    curr = head;
    while (curr != NULL) {
        cout << curr->lineNumber << " " << curr->string11 << endl;
        curr = curr->next;
    }
}


//determines line number of each node and stores it, returns the final line number
int List::DetermineLineNum() {
    curr = head;
    int lineNum = 1;
    while (curr != NULL) {
        curr->lineNumber = lineNum;
        curr = curr->next;
        lineNum++;
    }
    return lineNum;
}


//determines whether the string str is valid (ie, starts/ends w/ double quotes), returns true if string valid, false otherwise
bool List::ValidString(string str) {
    if (str[0] == ' ') {
        str = str.substr(1, str.length()-1);
    }
    if (str[0] != '\"' || str[str.length()-1] !='\"') {
        //cout << "string doesn't start/end w/ quotes" << endl;
        return false;
    }
    return true;
}


//shortens the length of the string str if it is > 80 characters, returns the new shortened string
string List::ShortenString(string str) {
    if (str.length() > 80) {
        //cout << "string too long" << endl;
        str = str.substr(0, 80);
        //cout << "new string is: " << str <<endl;
    }
    return str;
}


//takes a valid string quoteString and removes beginning/ending double quotes, returns the new string w/ quotes removed
string List::RemoveQuotesFrStr(string quoteString) {
    if (quoteString[0] == ' ') {
        quoteString = quoteString.substr(1, quoteString.length()-1);
    }
    if (quoteString[0] == '\"' && quoteString[quoteString.length()-1] =='\"') {
        //cout << "starts/ends w/ quote" <<endl;
        quoteString = quoteString.substr(1, quoteString.length()-2);
        //cout << "Removed the quote" << endl;
        //cout << "new string is " << quoteString << endl;
    }
    return quoteString;
}


//searches for searchString in each node of the linked list, returns true if substring found, false otherwise
bool List::Search(string searchString) {
    nodePtr searchingPtr = head;
    int lineNum = 1;
    bool found = false;

    while (searchingPtr != NULL) {
        if ((searchingPtr->string11).find(searchString) != string::npos) {
            //cout << "found the string at lineNum " << lineNum << endl;
            cout << lineNum << " " << searchingPtr->string11 << endl;
            found = true;
        }
        searchingPtr = searchingPtr->next;
        lineNum++;
    }
    if (found) {
        return true;
    } else {
        cout << "not found" << endl;
        return false;
    }

}