//
//  main.cpp
//  LineEditor
//
//  Created by Martin Lasprilla on 9/16/18.
//  Copyright © 2018 Martin Lasprilla. All rights reserved.
//

#include <iostream>
#include "Header.h"

using namespace std;


List::List(){
    head = NULL;
    curr = NULL;
    temp = NULL;
    prev = NULL;
    
}

void List::insertEnd(string userText){
    nodePtr newNode = new Node;
    newNode->next = NULL;
    newNode->data = userText;
//    newNode->index = 0;
    
    if(head != NULL){
        curr = head;
//        curr->index;
        
        while (curr->next != NULL) {
            curr = curr->next;
//            curr->index ++;
        }
        curr->next = newNode;
        newNode->index = curr->index + 1;
        
    }
    else{
        head = newNode;
        head->index= 1;
    }
}

void List::insert(int userIndex, string userText){
    nodePtr newNode = new Node;
    newNode->data = userText;
    newNode->index = userIndex;
    
    if(head != NULL){
        curr = head;
        prev = head;
        
        while (curr->index != userIndex) {
            prev = curr;
            curr = curr->next;
            
            if(curr == NULL){
                if(prev->index == userIndex - 1){
                    insertEnd(userText);
                }
                return;
            }
        }
        prev->next = newNode;
        newNode->next = curr;
//      curr = newNode;
        while (curr != NULL) {
            curr->index++;
            curr = curr->next;
        }
        }
    else if(userIndex == 1) {
        insertEnd(userText);
    }
}

void List::deleteLine(int userIndex){
    curr = head;
    prev = head;
    
        while (curr->index != userIndex){
//            while (curr->next != NULL) {
                prev = curr;
                curr = curr->next;
            if(curr == NULL){
                return;
            }
//            }
        }
        temp = curr;
        prev->next = curr->next;
        if(curr->next == NULL){
            return;
        }
        else{
            curr->next->index = temp->index;
        }
        delete(temp);
        return;
    
}

void List::editLine(int userIndex, string userText){
    curr = head;
        while(curr->index != userIndex){
            curr = curr->next;
        }
        curr->data = userText;
}

void List::printList(){
    curr = head;
    while (curr->next != NULL) {
        cout << curr->index<<" ";
        cout << curr->data<< endl;
        curr = curr->next;
    }
    cout << curr->index << " ";
    cout << curr->data<< endl;
}

void List::searchList(string userText){
    curr = head;
    bool found = false;
    
    while (curr != NULL) {
        if (curr->data.find(userText) == -1){
            curr = curr->next;
            
        }
        else{
            cout << curr->index <<" ";
            cout << curr->data<<endl;
            curr = curr->next;
            found = true;
        }
    }
    if (!found) {
        cout<< "Not Found"<<endl;
    }
    
}

int main() {
    List list;
    bool a = false;
    string option;
    string insertEnd = "insertEnd";
    string insert = "insert";
    string deleteLine = "delete";
    string edit = "edit";
    string print = "print";
    string quit = "quit";
    string search = "search";
    
    cout << "Welcome to a Line Editor, please capatialize the first letter.\n";
//    getline(cin, option);

    while(!a){
        getline(cin,option);
//      insertEnd
        if(option.find(insertEnd) == 0){
            string x = option.substr(11,option.length()-12);
//            cout << x;
            list.insertEnd(x);
        }
//      insert
        else if(option.find(insert) == 0){
            string x = option.substr(10,option.length()-11);
            string y = option.substr(7,1);
            int z = stoi(y);
            list.insert(z,x);
        }
//      delete
        else if(option.find(deleteLine) == 0){
            string x = option.substr(7,1);
            int y = stoi(x);
//            cout << y;
            list.deleteLine(y);
        }
//      edit
        else if (option.find(edit) == 0) {
            string x = option.substr(8,option.length()-9);
            string y = option.substr(5,1);
            int z = stoi(y);
//            cout << x << z;
            list.editLine(z, x);
        }
//      print
        else if(option.find(print) == 0){
            list.printList();
        }
//      quit
        else if(option.find(quit) == 0){
            a = true;
        }
//      search
        else if(option.find(search) == 0){
            string x = option.substr(8,option.length()-9);
            list.searchList(x);
        }
    }
    return 0;
}
