#ifndef LINKED_LIST_H
#define LINKED_LIST_H

#include <string>

class Line {
    public:
        Line(std::string line);
        std::string line;
        Line* next;
        bool contains(std::string str);
};

class LinkedList {
    private:
        Line* head;
        Line* tail;
        int size;
    
    public:
        LinkedList();
        ~LinkedList();
        Line* get_head();
        Line* get_tail();
        Line* get(int index);
        Line* push_front(Line* node);
        Line* push_back(Line* node);
        Line* insert(Line* node, int index);
        Line* replace(std::string str, int index);
        std::string to_string();
        bool remove(int index);
        std::string find(std::string query);
};

#endif
