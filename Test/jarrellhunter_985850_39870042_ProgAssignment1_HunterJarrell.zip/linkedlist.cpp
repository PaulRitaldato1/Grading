#include "linkedlist.h"
#include <iostream>

Line::Line(std::string str) {
    this->line = str;
    this->next = NULL;
}

bool Line::contains(std::string str) {
    std::size_t pos = this->line.find(str);

    return pos != std::string::npos;
}

LinkedList::LinkedList() {
    this->size = 0;
    this->head = NULL;
    this->tail = NULL;
}

LinkedList::~LinkedList() {
    Line* curr = this->head;
    Line* next = NULL;
    while (curr != NULL) {
        next = curr->next;
        delete curr;
        curr = next;
    }
}

Line* LinkedList::get_head() {
    return this->head;
}

Line* LinkedList::get_tail() {
    return this->tail;
}

Line* LinkedList::push_front(Line* node) {
    if (this->head == NULL) {
        this->head = node;
        this->tail = node;
    } else {
        node->next = this->head;
        this->head = node;
        if (this->size == 1) {
            this->tail = this->head->next;
        }
    }
    this->size++;
    return this->head;
}

Line* LinkedList::get(int index) {
    if (index > this->size - 1) {
        return NULL;
    } else {
        int counter = 0;
        Line* curr = this->head;
        while (counter < index && curr != NULL) {
            curr = curr->next;
            counter++;
        }
        return curr;
    }
    return NULL;
}

Line* LinkedList::push_back(Line* node) {
    if (this->head == NULL) {
        this->head = node;
        this->tail = node;
    } else {
        this->tail->next = node;
        this->tail = node;
    }
    this->size++;
    return node;
}

bool LinkedList::remove(int index) {
    if (index > this->size - 1) {
        return false;
    } else if (index == 0) {
        Line* toDel = this->head;
        this->head = toDel->next;
        delete toDel;
        this->size--;
    } else {
        Line* prev = this->get(index-1);
        Line* toDel = prev->next;
        prev->next = toDel->next;
        if (prev->next == NULL) {
            this->tail = prev;
        }
        delete toDel;
        this->size--;
    }
    return true;
}

std::string LinkedList::to_string() {
    Line* curr = this->head;
    std::string output = "";
    int counter = 1;
    while (curr != NULL) {
        output += std::to_string(counter);
        output += " " + curr->line;
        output += "\n";
        curr = curr->next;
        counter++;
    }
    if (counter > 1) {
        output.pop_back();
    }
    return output;
}

Line* LinkedList::insert(Line* node, int index) {
    if (index < 0 || index > this->size) {
        return NULL;
    } else {
        if (index == 0) {
            return this->push_front(node);
        } else if (index == this->size) {
            return this->push_back(node);
        } else {
            Line* prev = this->get(index-1);
            Line* curr = prev->next;
            prev->next = node;
            node->next = curr;
            this->size++;
            return node;
        }
    }
}

std::string LinkedList::find(std::string query) {
    std::string result = "";

    Line* curr = this->head;
    int counter = 1;
    while (curr != NULL) {
        if (curr->contains(query)) {
            result += std::to_string(counter);
            result += " " + curr->line;
            result += "\n";
        }
        curr = curr->next;
        counter++;
    }
    
    return result.empty() ? "not found\n" : result;
}

Line* LinkedList::replace(std::string str, int index) {
    Line* curr = this->get(index);
    if (curr != NULL) {
        curr->line = str;
    }
    
    return curr;
}
