# COP3530 - Programming Assignment #1 Commentary

## What is the computational complexity of the methods in the implementation?

The computational complexity of the following methods are O(n) since they, worst case, loop over all the nodes in the list:

 - ~LinkedList()
 - get(int index)
 - to_string()
 - find(std::string query)
 - insert(Line* node, int index)
 - replace(std::string, int index)
 - remove(int index)

The computational complexity of the following methods are only O(1) because they can just access the first or last nodes.

 - get_head()
 - get_tail()
 - push_from(Line* node)
 - push_back(Line* node)

## Your thoughts on the use of linked lists for implementing a line editor.  What are the advantages and disadvantages?

I thought it was an interesting way of implementing a text editor. The advantage of using a linked list is that it is constant time to either push a new line to the front or the back of the list. Also you can remove a node by just going to the node and changing the pointers rather than having to shift an entire array forward or backwards. The disadvantage of using a linked list is that getting a node from an index is O(n) rather than the constant time of an array based list. 

## What did you learn from this assignment and what would you do differently if you had to start over?

If I were to redo this assignment I would implement a lot of my methods recursively. I think that would shorten the methods and make them easier to understand.
