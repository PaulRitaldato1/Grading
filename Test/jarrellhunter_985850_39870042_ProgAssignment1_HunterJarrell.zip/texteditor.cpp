#include <iostream>
#include "linkedlist.h"

int main() {
    LinkedList* l = new LinkedList();

    std::string input;
    bool keepGoing = true;
    while (keepGoing) {
        getline(std::cin, input);
        if (input.find("insertEnd ") == 0) {
            input = input.substr(10);
            if (input.front() == '"' && input.back() == '"') {
                input = input.substr(1, input.size()-2);
                input = input.size() > 80 ? input.substr(0,80) : input;
                l->push_back(new Line(input));                
            }
        } else if (input.find("insert ") == 0) { 
            input = input.substr(7);

            size_t space_pos = input.find(" ");
            if (space_pos != std::string::npos) {
                std::string line = input.substr(0, space_pos);
                input = input.substr(1);
                
                try {
                    int line_num = std::stoi(line);
                    input = input.substr(space_pos);

                    if (input.front() == '"' && input.back() == '"') {
                        input = input.substr(1, input.size()-2);
                        input = input.size() > 80 ? input.substr(0,80) : input;
                        l->insert(new Line(input), line_num-1);
                    }
                } catch(const std::exception& e) {
                    // Ignore any errors
                }
            }
        } else if (input.find("edit ") == 0) { 
            input = input.substr(5);

            size_t space_pos = input.find(" ");
            if (space_pos != std::string::npos) {
                std::string line = input.substr(0, space_pos);
                input = input.substr(1);
                
                try {
                    int line_num = std::stoi(line);
                    input = input.substr(space_pos);

                    if (input.front() == '"' && input.back() == '"') {
                        input = input.substr(1, input.size()-2);
                        input = input.size() > 80 ? input.substr(0,80) : input;
                        l->replace(input, line_num-1);
                    }
                } catch(const std::exception& e) {
                    // Ignore any errors
                }
            }
        } else if (input.find("delete ") == 0) {
            input = input.substr(7);
            try {
                int line_num = std::stoi(input);

                l->remove(line_num-1);
            } catch (const std::exception& e) {
                // Ignore errors
            }
        } else if (input.find("search ") == 0) {
            input = input.substr(7);

            if (input.front() == '"' && input.back() == '"') {
                input = input.substr(1, input.size()-2);
                std::cout << l->find(input);
            }
        } else if (input == "print") {
            std::cout << l->to_string() << std::endl;
        } else if (input == "quit") {
            keepGoing = false;
        }
        input = "";
    }

    delete l;
    return 0;
}
