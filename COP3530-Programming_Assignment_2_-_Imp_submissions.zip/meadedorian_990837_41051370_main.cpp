// COP353 Programming Assignment 2 - Implement Google's Page Rank
// Dorian Meade     11/30/18

#include <iostream>
#include <vector>
#include <iomanip>
#include <string>
#include <algorithm>

using namespace std;

int main() {
    
    //Take multiple line input into string separated by new lines
    string input;
    string line;
    while(getline(cin, line) && !line.empty())
    {
        input += line + "\n";
    }
    
    //Get number of lines and power iterations by locating spaces in the input string
    //Remove the first line from input string after both integers are found
    int numLines = stoi(input.substr(0, input.find(" ")));
    input = input.substr(input.find(" ") + 1, input.size() - 1);
    int power = stoi(input.substr(0, input.find(" ")));
    input = input.substr(input.find("\n") +1, input.size() - 1);
    
    //For each line, separate URLS into 2 vectors (from pages vs to pages)
    vector <string> fromURL;
    vector <string> toURL;
    while(input.compare(""))
    {
        //Create a string of one input line
        int linePos = input.find("\n");
        string temp = input.substr(0, linePos);
        //Add the first URL to from page vector, add second URL to to page vector
        fromURL.push_back(temp.substr(0, temp.find(" ")));
        toURL.push_back(temp.substr(temp.find(" ") + 1, temp.size() -1));
        //Remove line from input string after URLS are added
        input = input.substr(linePos + 1, input.size() - 1);
    }
    
    //Map each URL to a unqiue ID (in vector)
    vector <string> URLS;
    
    //Loop through fromURL vector
    for (int i = 0; i < numLines; i++)
    {
        //If URL is not in unique URL vector
        if(find(URLS.begin(), URLS.end(), fromURL[i]) == URLS.end())
        {
            //Add URL to unique URL vector
            URLS.push_back(fromURL[i]);
        }
    }
    //Loop through toURL vector
    for (int i = 0; i < numLines; i++)
    {
        //If URL is not in unique URL vector
        if(find(URLS.begin(), URLS.end(), toURL[i]) == URLS.end())
        {
            //Add URL to unique URL vector
            URLS.push_back(toURL[i]);
        }
    }
    
    //Sort the URLS in ascending alphabetical order, indexed 0 to n-1
    sort(URLS.begin(), URLS.end());
    
    //Count the number of URLS
    const int vertices = URLS.size();
    
    //Initialize out degree array size to the number of URLS
    int outDeg[vertices];
    
    //Calculate each URL's out degree
    for(int i = 0; i < vertices; i++)
    {
        //Count number of occurrences of the URL in the fromURL vector
        outDeg[i] = count(fromURL.begin(), fromURL.end(), URLS[i]);
    }
    
    //Create adjacency matrix for graph representation of the web
    float graph[vertices][vertices];
    
    //Initialize all matrix values to 0
    for(int i = 0; i < vertices; i++)
    {
        for(int j = 0; j < vertices; j++)
        {
            graph[i][j] = 0;
        }
    }
    
    //Fill the adjacency matrix by looping through each edge originally inputted
    for(int i = 0; i < numLines; i++)
    {
        //Get the unique ID for the from page
        int fromIndex = find(URLS.begin(), URLS.end(), fromURL[i]) - URLS.begin();
        //Get the unique ID for the to page
        int toIndex = find(URLS.begin(), URLS.end(), toURL[i]) - URLS.begin();
        //Determine the decimal value of this index based on the fromURL's out degree
        float num = (float)1 / outDeg[fromIndex];
        //Add value to adjacency matrix
        graph[toIndex][fromIndex] = num;
    }
    
    //Create rank matrix
    float rank[vertices][1];
    //Initialize all matrix values to 0
    for(int i = 0; i < vertices; i++)
    {
        rank[i][0] = 0;
    }
    //Initialize rank values to 1 / (# vertices)
    for(int i = 0; i < vertices; i++)
    {
        rank[i][0] = (float)1 / vertices;
    }
    
    //Create empty matrix to store results of multiplication
    float result[vertices][1];
    //Initialize all matrix values to 0
    for(int i = 0; i < vertices; i++)
    {
        result[i][0] = 0;
    }
    
    //Check if num of power iteations is 1 (no matrix multiplication required)
    if(power == 1)
    {
        //Output URLS in ascending alphabetical order with starting page rank
        for (int i = 0; i < vertices; ++i)
        {
            for (int j = 0; j < 1; ++j)
            {
                cout << URLS[i] << " " << fixed << setprecision(2) << rank[i][0];
            }
            cout << endl;
        }
        //Exit code here
        return 0;
    }
    //Continue for power iterations greater than 1
    //Multiply graph and rank matrices storing results in result
    for (int i = 0; i < vertices; i++)
    {
        for (int j = 0; j < 1; j++)
        {
            for (int k = 0; k < vertices; k++)
            {
                result[i][j] += graph[i][k] * rank[k][j];
            }
        }
    }
    
    //Store resulting ranknings in a matrix called new rank (for more than one power iteration)
    float newRank[vertices][1];
    for(int i = 0; i < vertices; i++)
    {
        newRank[i][0] = result[i][0];
    }
    
    //For each additional power iteration
    int count = 2;
    while(count < power)
    {
        //Initialize result matrix values to 0
        for(int i = 0; i < vertices; i++)
        {
            result[i][0] = 0;
        }
        //Multiply original graph and new rank matrix and store result
        for (int i = 0; i < vertices; i++)
        {
            for (int j = 0; j < 1; j++)
            {
                for (int k = 0; k < vertices; k++)
                {
                    result[i][j] += graph[i][k] * newRank[k][j];
                }
            }
        }
        //Store resulting rankings in new rank
        for(int i = 0; i < vertices; i++)
        {
            newRank[i][0] = result[i][0];
        }
        //Increment power iterations counter
        count++;
    }
    
    //Output URLS in ascending alphabetical order with their corresponding calculated page rank
    for (int i = 0; i < vertices; ++i)
    {
        for (int j = 0; j < 1; ++j)
        {
            cout << URLS[i] << " " << fixed << setprecision(2) << newRank[i][0];
        }
        cout << endl;
    }
    
    return 0;
}

