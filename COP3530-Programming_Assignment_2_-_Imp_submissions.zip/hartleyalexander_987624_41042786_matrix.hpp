#ifndef MATRIX_H
#define MATRIX_H
#define OUT_OF_BOUNDS 10
#define INVALID_DIMENSIONS 20
#include <ostream>

template <class T> class Matrix{
  public:
    Matrix(int j, int i):matrix_array{new T[j*i]()},stride{i},depth{j}{}
    ~Matrix(){delete matrix_array;}
    class MatrixRow{
        public:
            MatrixRow(Matrix& parent, int j):parent{parent},j{j} {}
            T& operator[](int i) const { return parent.Get(j,i);}
        private:
            Matrix& parent;
            int j;
    };
    MatrixRow operator[](int j) { return MatrixRow(*this, j);}
    friend Matrix<T> operator * (Matrix<T> &m, Matrix<T> &n){
        if(m.stride != n.depth){
            throw INVALID_DIMENSIONS;
        }
        int newStride = n.stride;
        int newDepth = m.depth;
        Matrix<T> result(newDepth,newStride);
        for(int i = 0; i < newStride; i++){
            for(int j=0; j < newDepth; j++){
                result[j][i] = dotProduct(m,n,j,i);
            }
        }
        return result;
    }
    friend T dotProduct(Matrix<T> &m, Matrix<T> &n, int j, int i){
        T result = 0;
        int run = m.stride;
        for(int s = 0; s < run; s++){
            result += m[j][s] * n[s][i];
        }
        return result;
    }
    friend std::ostream& operator<<(std::ostream& os, Matrix &m){
        for(int j = 0; j < m.depth; j++){
            for(int i=0; i < m.stride; i++){
                os<< m[j][i] << '\t';
            }
            os << std::endl;
        }
        return os;
    }
    void operator=(Matrix m){
        if(m.stride == stride && m.depth && depth){
            for(int s = 0; s < stride*depth; s++){matrix_array[s]=m.matrix_array[s];}
        }else{
            throw INVALID_DIMENSIONS;
        }
    }
  private:
    friend class MatrixRow;
    T& Get(int j, int i);
    T* matrix_array;
    int stride;
    int depth;
};

template <class T>
T& Matrix<T>::Get(int j, int i){
    if(i < stride && j < depth)
        return matrix_array[(j*stride)+i];
    else
        throw OUT_OF_BOUNDS;
}

#endif //MATRIX_H