/*
COP3530 Programming Assignment 2 - Implement Google's Page Rank
Jacob Magnant
11/29/2018
*/
#include <iostream>
#include <list>
#include <string>
#include <math.h>

using namespace std;

int main()
{

    //Capture input amount and PageRank power iteration.
    int inputAmt, powerIter;
    cin >> inputAmt >> powerIter;



    //Capture input into lists.
    std::list<string> pageRankSites, pageRankLinks, pageRankUniqueSites;
    for(int i = 0; i < inputAmt; i++){
        string input1, input2;
        cin >> input1 >> input2;
        pageRankSites.push_back(input1);
        pageRankLinks.push_back(input2);

        //Make list of unique sites.
        bool site1AlreadyAdded = false;
        bool site2AlreadyAdded = false;
        for (const string & site : pageRankUniqueSites){
            if(site == input1){ site1AlreadyAdded = true; }
            if(site == input2){
                site2AlreadyAdded = true;
            }
        }
        if(!site1AlreadyAdded && !site2AlreadyAdded){
            if(input1 == input2){
                pageRankUniqueSites.push_back(input1);
            }
            else{
                pageRankUniqueSites.push_back(input1);
                pageRankUniqueSites.push_back(input2);
            }
        }
        else if(!site1AlreadyAdded){
            pageRankUniqueSites.push_back(input1);
        }
        else if(!site2AlreadyAdded){
            pageRankUniqueSites.push_back(input2);
        }
    }



    //Map unique sites to an array, so they can be identified by the index.
    pageRankUniqueSites.sort();
    string pageRankSiteKey[pageRankUniqueSites.size()];
    int counter = 0;
    for (const string & site : pageRankUniqueSites){
        pageRankSiteKey[counter] = site;
        counter++;
    }



    //Create PageRank Graph.
    double pageRankGraph[pageRankUniqueSites.size()][pageRankUniqueSites.size()];
    for(int i = 0; i < pageRankUniqueSites.size(); i++){
        for(int j = 0; j < pageRankUniqueSites.size(); j++){
            pageRankGraph[i][j] = 0;
        }
    }
    std::list<string>::iterator pageRankSitesIT = pageRankSites.begin();
    std::list<string>::iterator pageRankLinksIT = pageRankLinks.begin();
    for(int i = 0; i < pageRankSites.size(); i++){ //Iterate through each site in list.
        for(int j = 0; j < pageRankUniqueSites.size(); j++){ //Iterate through entire graph.
            for(int k = 0; k < pageRankUniqueSites.size(); k++){
                if(pageRankSitesIT->c_str() == pageRankSiteKey[j] && pageRankLinksIT->c_str() == pageRankSiteKey[k]){
                    if(j != k) {
                        pageRankGraph[j][k] += 1;
                    }
                }
            }
        }
        pageRankSitesIT++;
        pageRankLinksIT++;
    }



    //Determine outdegrees.
    double pageRankOutDegrees[pageRankUniqueSites.size()];
    for(int i = 0; i < pageRankUniqueSites.size(); i++){
        for(int j = 0; j < pageRankUniqueSites.size(); j++){
            pageRankOutDegrees[i] += pageRankGraph[i][j];
        }
    }

    //Adjust PageRank Graph for outdegrees.
    for(int i = 0; i < pageRankUniqueSites.size(); i++){
        for(int j = 0; j < pageRankUniqueSites.size(); j++){
            if(pageRankGraph[i][j] > 0 && pageRankOutDegrees[i] > 0) {
                pageRankGraph[i][j] = pageRankGraph[i][j] / pageRankOutDegrees[i];
            }
        }
    }



    //Power Iteration of PageRank Graph data.
    double pageRank[pageRankUniqueSites.size()];
    double powerIterR[pageRankUniqueSites.size()];
    for(int i = 0; i < pageRankUniqueSites.size(); i++){ //Assign inital PageRank and R vector to 1/(number of sites).
        powerIterR[i] = 1/((double)pageRankUniqueSites.size());
        pageRank[i] = 1/((double)pageRankUniqueSites.size());
    }
    for(int k = 0; k < powerIter-1; k++) { //Apply power iterations as specified by initial input.
        for (int j = 0; j < pageRankUniqueSites.size(); j++) {
            double tempPageRank = 0;
            for (int i = 0; i < pageRankUniqueSites.size(); i++) {
                tempPageRank = tempPageRank + (pageRankGraph[i][j] * powerIterR[i]);
            }
            pageRank[j] = tempPageRank;
        }
        for (int i = 0; i < pageRankUniqueSites.size(); i++) {
            powerIterR[i] = pageRank[i];
        }
    }



    //Print PageRank.
    for(int i = 0; i < pageRankUniqueSites.size(); i++){
        cout << pageRankSiteKey[i] << " ";              //Prints website name.
        printf("%.2f", (round(pageRank[i]*100))/100);   //Prints PageRank, rounded and truncated to 2 decimal places.
        cout << "\n";
    }



    return 0;
}