#include "Matrix.h"
#include "Webpage.h"
#include <iterator>

//CONSTRUCTOR
Matrix<std::string,std::string>::Matrix(int maxSz){
  this->directory.reserve(maxSz);
}

/*-------------------------------insert pair to the graph-------------------------------
 * inserts a pair into the directory of the websites and links them together so the
 * origin "points to" the destination (the first string inputted points to the second one)
 * also increments the in/out variables of the respective website objects, if the website
 * already exists within the graph, itll link accordingly and increment the in/out vars
 */
void Matrix<std::string,std::string>::insertPair(std::string ptr, std::string ptsTo){
  //bool foundOg = false, foundDest = false;
  Webpage * dest = nullptr;
  Webpage *origin = nullptr;
  int i = 0;

  for(std::vector<Webpage*>::iterator it = directory.begin(); it != directory.end(); it++){
    if( ((*it)->getURL().compare(ptr) == 0) ){
      origin = *it;
      (*it)->incrementOut();
    }
    else if( ((*it)->getURL().compare(ptsTo) == 0) ){
      dest = *it;
      (*it)->incrementIn();
    }
    if(dest != NULL && origin != NULL) {
        origin->link(dest);
        break;
    }
    i++;
  }

  if( origin==nullptr && dest==nullptr ){//if at the end & hasnt broken it hasnt found the webpage ie it doesnt exits in the list yet
               //it will create the website objects
      Webpage *dest = new Webpage(ptsTo, true, nullptr, i);
      Webpage *origin = new Webpage(ptr, false, dest, i+1);
      this->addToDirectory(dest);
      this->addToDirectory(origin);
      i++;
  }
  else if (origin!=nullptr && dest== NULL) { //must create dest, it doesnt exist but origin does
    Webpage *dest = new Webpage(ptsTo, true, nullptr, i);
    this->addToDirectory(dest);
    origin->link(dest);
    i++;
  }
  else if (dest!=nullptr && origin== NULL) {//must create origin, it doesnt exist but dest does
    Webpage *nOrigin = new Webpage(ptr, true, dest, i);
    this->addToDirectory(nOrigin);
    nOrigin->link(dest);
      nOrigin->incrementOut();
    i++;
  }
}


/*------------------------------------set matrix------------------------------------
 * after you know all of the values for the graph, this sets up the matrix for
 * the object
 */
void Matrix<std::string,std::string>::sMatrix()
{
  adjMatrix = new double*[this->getDirectory().size()];

  //initializing matrix and all vals to 0
  for(int c = 0; c < this->getDirectory().size(); c++)
  {
    adjMatrix[c] = new double[this->getDirectory().size()];
    for(int r = 0; r < this->getDirectory().size(); r++)
    {
        adjMatrix[c][r] = 0;
    }
  }

  for(int c = 0; c < this->getDirectory().size(); c++){
    for(int i = 0; i < this->getDirectory().at(c)->getPtsTo()->size(); i++){
      int rin = this->getDirectory().at(c)->getPtsTo()->at(i)->getIndex();
      adjMatrix[rin][c] = ( 1.0/(this->getDirectory().at(c)->getOut()) );
    }
  }
}


/*------------------------------------print matrix------------------------------------
* goes thru the matrix and prints element at each step, O(r*c) (r should == c) so
* O(n^2) where n is the length of one side of the matrix
*/
   void Matrix<std::string,std::string>::printMatrix(){
     for(int i = 0; i < this->getDirectory().size(); i++)
     {
         for(int j = 0; j < this->getDirectory().size(); j++) {
             printf("%7.1f", adjMatrix[i][j]);
         }

         std::cout<<std::endl;
     }
   }


/*------------------------------------print directory------------------------------------
 * prints the websites in the directory and their in/out degrees and where they point to
 */
 void Matrix<std::string,std::string>::printDirectory()
 {
    printf("%13s %5s %5s\n", "URL", "In", "Out" );
    for(int i = 0; i < this->getDirectory().size(); i++)
    {
      printf("%13s %5u %5u", this->getDirectory().at(i)->getURL().c_str(), this->getDirectory().at(i)->getIn(), this->getDirectory().at(i)->getOut());
      this->getDirectory().at(i)->printPtsTo();
      std::cout<<std::endl;
    }
}

/*------------------------------------get directory------------------------------------
 * returns the variable of the directory in vector form
 */
std::vector<Webpage*> Matrix<std::string,std::string>::getDirectory(){
  return this->directory;
}

/*------------------------------------add to directory------------------------------------
 * helper method that adds a website object to the vector directory of websites
 */
Webpage* Matrix<std::string,std::string>::addToDirectory(Webpage *insert){
  this->directory.push_back(insert);
  return insert;
}



/*------------------------------------power iteration------------------------------------
 * main method that does the matrix multiplication however many times the user wants based
 * on user input
 */
   double* Matrix<std::string,std::string>::mult(int numTimes)
   {
       double* frac = new double[this->getDirectory().size()];
       double* ret = new double[this->getDirectory().size()];


       for(int y = 0; y < this->getDirectory().size(); y++){
           frac[y] = 1.0 / ((double) this->getDirectory().size());
           ret[y] = 0;
       }


       double tot = 0;
       for(int t = 0; t < numTimes-1; t++) {
           for (int r = 0; r < this->getDirectory().size(); r++) {
               tot = 0;
               for (int c = 0; c < this->getDirectory().size(); c++) {
                   tot += frac[c] * (adjMatrix[r][c]);
               }
               ret[r] = tot;
           }

           for(int i = 0; i < this->getDirectory().size(); i++){
               frac[i] = ret[i];
           }
       }

       for(int i = 0; i < this->getDirectory().size(); i++){
           directory[i]->setPageRank(frac[i]);
       }

       return ret;
   }

/*------------------------------------sort directory by name------------------------------------
 * sorts directory by url name, using insertion sort so O(n^2)
 */
void Matrix<std::string,std::string>::sortDirByName(){
    int i, j;
    std::string key;
    Webpage *keyPtr;

    for (i = 1; i <this->getDirectory().size() ; i++) {
        key = directory[i]->getURL();
        keyPtr = directory[i];
        j = i - 1;
        while (j >= 0 && directory[j]->getURL().compare(key) > 0) {
            directory[j + 1] = directory[j];
            j = j - 1;
        }
        directory[j + 1] = keyPtr;
    }
}
/*------------------------------------print page ranks------------------------------------
 * formats for output matching, iterates thru the directory and prints webpage name
 * and page rank
 */
void Matrix<std::string,std::string>::printPageRanks(){
    this->sortDirByName();
    for(int j = 0; j < this->getDirectory().size(); j++)
    {
        printf("%s %.2f\n", this->directory[j]->getURL().c_str(), this->directory[j]->getPageRank());
    }
}