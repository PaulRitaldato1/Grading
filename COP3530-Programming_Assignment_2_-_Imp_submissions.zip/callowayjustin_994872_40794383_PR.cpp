#include <iostream>
#include <array>
#include <string>
#include <algorithm>
#include <unordered_map>
#include <vector>
#include <cmath>

using namespace std;

int main() {

	int numLines = 0;
	int power = 0;
	int count = 0;
	string page;
	string page2;

	cin >> numLines;
	cin >> power;

	vector<vector<double>> matrix(numLines, vector<double>(numLines, 0));    //2D vector with size intialized and all elements to 0
	unordered_map<string, int> map;		//gives a number to each unique website

	while (cin) {
		cin >> page;							//first page in line
		if (map.find(page) == map.end()) {		//if page is not in unordered map
			if (count != 0) {					//handles if this is the first website from the input
				count++;
			}
			map[page] = count;					//add to the map at the right index
		}

		cin >> page2;							//second page in line
		if (map.find(page2) == map.end()) {		//if page is not in unordered map
			count++;							//add to the map at the right index
			map[page2] = count;
		}

		for (int i = 0; i <= map.size(); i++) {		//puts a "1" where page and page2 have an edge
			for (int j = 0; j <= map.size(); j++) {
				matrix[map[page2]][map[page]] = 1;
			}
		}
	}

	int colSum = 0;
	vector <double> columnSum(map.size());		//vector to keep track of the sum of each column for outdegree
	for (int j = 0; j < map.size(); j++) {
		for (int i = 0; i < map.size(); i++) {
			if (matrix[i][j] == 1) {
				colSum++;
			}
		}
		columnSum[j] = colSum;
		colSum = 0;
	}

	for (int j = 0; j < map.size(); j++) {		//divide matrix elements by outdegree
		for (int i = 0; i < map.size(); i++) {
			if (matrix[i][j] == 1) {
				matrix[i][j] = (matrix[i][j] / columnSum[j]);
			}
		}
	}

	vector<double> startingNum(map.size());
	vector<double> pageRank(map.size());
	for (int i = 0; i < startingNum.size(); i++) {
		startingNum[i] = 1.0 / map.size();
		pageRank[i] = 0;
	}

	int MMcount = 1;
	if (power > 1) {
		while (MMcount < power) {

			for (int i = 0; i < map.size(); i++) {
				pageRank[i] = 0;
				for (int j = 0; j < map.size(); j++) {
					pageRank[i] += matrix[i][j] * startingNum[j];
				}
			}

			for (int i = 0; i < pageRank.size(); i++) {
				startingNum[i] = pageRank[i];
			}
			MMcount++;
		}
	}

	vector<string> websites;							//made a vector for the website names to easily sort them
	for (auto i : map) {
		websites.push_back(i.first);
	}

	sort(websites.begin(), websites.end());

	if (power == 1) {									//for power iterations = 1, just print 1 / map.size()
		for (int i = 0; i < websites.size(); i++) {
			cout << websites[i] << " ";
			printf("%.2f", startingNum[i]);
			cout << endl;
		}
	}
	else {
		for (int i = 0; i < websites.size(); i++) {			//print sorted websites and their corrensponding page rank
			cout << websites[i] << " ";
			printf("%.2f", pageRank[map.at(websites[i])]);
			cout << endl;
		}
	}

	return 0;
}