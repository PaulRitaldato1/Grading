#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <map>

using namespace std;

int numLines;
int numIterations;
int graphSize = 1;
float** adjMatrix;
int* outDegrees;
std::string* lines;
std::string* fromPages;
std::string* toPages;
std::map<int, string> pageTable;
std::map<int, float> pageRanks;

void gather_input() {
	std::cin >> numLines >> numIterations;
	cin.ignore(100, '\n'); //ignore the newline after reading in from cin

	lines = new std::string[numLines];

	for (int i = 0; i < numLines; i++) {
		std::string line;
		std::getline(std::cin, line);
		lines[i] = line;
	}
}

int find_key(std::string value) {
	for (auto it = pageTable.begin(); it != pageTable.end(); it++) {
		if (value.compare(it->second) == 0) {
			return it->first;
		}
	}
	return -1;
}

void generate_keys() {
	fromPages = new string[numLines];
	toPages = new string[numLines];

	for (int i = 0; i < numLines; i++) {
		std::string line = lines[i];
		size_t pos = line.find(" ");

		std::string from = line.substr(0, pos);
		std::string to = line.substr(pos + 1);

		fromPages[i] = from;
		toPages[i] = to;

		if (find_key(from) == -1) {
			pageTable.insert(pair<int, string>(graphSize, from));
			graphSize++;
		}

		if (find_key(to) == -1) {
			pageTable.insert(pair<int, string>(graphSize, to));
			graphSize++;
		}
	}

	graphSize--; //decrement counter so that graphSize refers to total number of elements and not the next possible element
	delete[] lines;
}

void create_adj_matrix() {
	adjMatrix = new float*[graphSize];
	outDegrees = new int[graphSize];

	for (int i = 0; i < graphSize; i++) {
		adjMatrix[i] = new float[graphSize];
		outDegrees[i] = 0;
		pageRanks[i + 1] = 1.0 / graphSize;
	}

	for (int row = 0; row < graphSize; row++) {
		for (int col = 0; col < graphSize; col++) {
			adjMatrix[row][col] = 0;
		}
	}

	for (int i = 0; i < numLines; i++) {
		outDegrees[find_key(fromPages[i]) - 1]++;
	}

	for (int i = 0; i < numLines; i++) {
		int fromKey = find_key(fromPages[i]);
		int toKey = find_key(toPages[i]);

		adjMatrix[toKey - 1][fromKey - 1] = (float)1 / outDegrees[fromKey - 1];
	}
}

void print_graph() {
	//print column header
	std::cout << " ";
	for (int i = 0; i < graphSize; i++) {
		std::cout << (i + 1) << " ";
	}
	std::cout << endl;

	//print data
	for (int row = 0; row < graphSize; row++) {
		std::cout << (row + 1) << " ";
		for (int col = 0; col < graphSize; col++) {
			std::cout << adjMatrix[row][col] << " ";
		}
		std::cout << endl;
	}
}

void perform_power_iter() {
	numIterations--;
	float* temp = new float[graphSize];

	for (int i = 0; i < numIterations; i++) {
		for (int row = 0; row < graphSize; row++) {
			float rowSum = 0.0f;

			for (int col = 0; col < graphSize; col++) {
				rowSum += adjMatrix[row][col] * pageRanks[col + 1];

			}
			temp[row] = rowSum;
			//pageRanks[row + 1] = rowSum;
		}
		for (int i = 0; i < graphSize; i++) {
			pageRanks[i + 1] = temp[i];
		}
	}

}

void output_page_ranks() {
	std::vector<string> tempPages;

	for (auto it = pageTable.begin(); it != pageTable.end(); it++) {
		tempPages.push_back(it->second);
	}

	std::sort(tempPages.begin(), tempPages.end());

	cout << fixed;
	cout.precision(2);

	for (auto it = tempPages.begin(); it != tempPages.end(); it++) {
		int key = find_key(*it);
		std::cout << *it << " " << pageRanks[key] << endl;
	}
}

int main() {
	gather_input();
	generate_keys();
	create_adj_matrix();
	perform_power_iter();
	output_page_ranks();

	cin.get();
	return 0;
}

