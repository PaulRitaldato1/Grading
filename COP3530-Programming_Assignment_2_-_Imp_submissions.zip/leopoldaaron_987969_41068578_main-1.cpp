#include "graph.h"
//#include "map_graph.h"

int main()
{
    // read in input, parse strings as from/to
	int num_edges;
	int iterations;

	directed_graph graph;
	std::string line;
	std::string delimeter = " ";
	unsigned int line_count = 0;
    
    // get instruction count and iteration number
    std::getline(std::cin, line);
    num_edges = std::stoi(line.substr(0, line.find(delimeter)));
    line.erase(0, line.find(delimeter) + delimeter.length());
    iterations = std::stoi(line.substr(0, line.find(delimeter)));

    if (num_edges <= 0 || iterations <= 0)
    {
        std::cout << "Invalid input, program terminated." << std::endl;
        return 0;
    }

    graph.set_max(num_edges);

	for (unsigned int i = 0; i < num_edges; i++)
	{
        std::getline(std::cin, line);
        
		std::string from = line.substr(0, line.find(delimeter));
		line.erase(0, line.find(delimeter) + delimeter.length());
		std::string to = line.substr(0, line.find(delimeter));

		graph.insert_edge(to, from);
	}

	//graph.print_weights();
	//std::cout << std::endl;
	graph.print_ranks(iterations);

    return 0;

}

/*
	first iteration:
	google: 1/2 0 0 1 0      multiplier: 1/5 1/5 1/5 1/5
	gmail:	0 0 1/2 0 0
	....

	google rank = google[0]*multiplier[0] + google[1]* multiplier[1] + etc. 
	...

	(new_multiplier = 3/10 1/10 etc etc)

	second iteration:
	google: 1/2 0 0 1 0      multiplier = 3/10 1/10 etc etc
	gmail:	0 0 1/2 0 0
	....

	google rank = google[0]*multiplier[0] + google[1]* multiplier[1] + etc. 

*/