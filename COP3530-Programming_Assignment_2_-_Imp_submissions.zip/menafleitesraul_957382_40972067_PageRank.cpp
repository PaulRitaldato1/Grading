//
//  main.cpp
//  PageRank
//
//  Created by Raul Mena on 11/23/18.
//  Copyright © 2018 Raul Mena. All rights reserved.
//

#include <iostream>
#include <string>
#include <unordered_map>
#include <queue>

using namespace std;

// max number of nodes (websites)
const int V = 5000;

// hash map for assigning unique IDs to websites
unordered_map<string, int> Id;

// priority queue used for outputting results in alphabetical order
priority_queue< pair<string, double>, vector<pair<string, double>>, greater<pair<string, double>>> Q;

// array containing out degree of each vertex (website)
int outDegree[V];

// R array with power iterations
double R[V];

// number of lines in input file
int numberOfLines;
// number of iterations for computing page rank
int numberOfIterations;
// total number of websites
int numberOfNodes;
// website u is adjacent to website v if website u has a link to website v
double adjacencyMatrix[V][V];

// array that holds websites names indexed by their unique ID
string arrayOfWebsites[V];

void read(){
    string website1, website2;
    int id = 0;
    
     // read number of lines in input file and number of iterations to be performed
    cin >> numberOfLines >> numberOfIterations;
    
    for(int i = 0; i < numberOfLines; i++){
        cin >> website1 >> website2;
        
        // key not found --> new website
        if(Id.find(website1) == Id.end()){
            // assign unique ID to website
            Id[website1] = ++id;
            // update array of websites
            arrayOfWebsites[id] = website1;
            // update total number of websites
            numberOfNodes++;
        }
        // key not found --> new website
        if(Id.find(website2) == Id.end()){
            // assign unique ID to website
            Id[website2] = ++id;
            // update array of websites
            arrayOfWebsites[id] = website2;
            // update total number of websites
            numberOfNodes++;
        }
        
        // v adjacent to w
        int v = Id[website1];
        int w = Id[website2];
        // update adjacency matrix
        adjacencyMatrix[w][v] = 1;
        // update out degree of vertex v
        outDegree[v]++;
    }
}

void initializeR(){
    // Initialize matrix R with initial rank for all websites --> R(0)
    for(int i = 1; i <= numberOfNodes; i++)
        R[i] =  1 / double(numberOfNodes);
}

void updateAdjMatrix(){
    // Update adjacency matrix considering outdegree for each vertex
    for(int i = 1; i <= numberOfNodes; i++){
        if(outDegree[i] > 0){
        for(int j = 1; j <= numberOfNodes; j++)
            adjacencyMatrix[j][i] /= outDegree[i];
        }
    }
}

// temporary array
double tmp[V];

void powerIterate(){
    // Compute matrix R for R(t = numberOfIterations)
    for(int i = 2; i <= numberOfIterations; i++){
        for(int i = 1; i <= numberOfNodes; i++){
            for(int j = 1; j <= numberOfNodes; j++){
                tmp[i] += R[j] * adjacencyMatrix[i][j];
            }
        }
        for(int i = 1; i <= numberOfNodes; i++){
            R[i] = tmp[i];
            tmp[i] = 0;
        }
    }
}

void initializeQueue(){
    // Initialize min priority queue with nodes containing website name and their final rank
    for(int i = 1; i <= numberOfNodes; i++){
        pair<string, double> p = make_pair(arrayOfWebsites[i], R[i]);
        Q.push(p);
    }
}

void write(){
    // websites are popped from queue in ascending alphabetical order
    while(!Q.empty()){
        pair<string, double> p = Q.top();
        Q.pop();
        cout << p.first << " ";
        printf("%.2f", p.second);
        cout << endl;
    }
}

int main(int argc, const char * argv[]) {
    
  //  freopen("input.txt", "r", stdin);
  //  freopen("output.txt","w",stdout);
    
    // read the input file
    read();
    
    // update adjacency matrix with out degree for each vertex
    updateAdjMatrix();
    
    // initialize R matrix
    initializeR();

    // compute page rank for each website based on number of iterations
    powerIterate();

    // initialize priority queue that holds website names and IDs
    initializeQueue();
    
    // output solution
    write();
    
    return 0;
}
