#include <iostream>
#include <string>
#include <string.h>
#include <vector>
#include <unordered_map>
#include <algorithm>
#include <iomanip>
#include <sstream>
//I know bad practice, but this course isn't taught like that. If it works it works
using namespace std;

//Parses the input
vector<string> parser(string s){
	vector<string> result;
	int split = s.find(" ");
	result.push_back(s.substr(0, split));
   // cout<<s.substr(0,split)<<" "<<s.substr(split+1,s.length())<<endl;
	result.push_back(s.substr(split + 1, s.length()));
	return result;
}

//Rounds Up
double round(double var)
{
	float value = (int)(var * 100 + .5);
	return (double)value / 100;
}

//Matrix multiplication
vector<vector<double>> matrixMultiplication(vector<vector<double>> M, vector<vector<double>> graph, int rowAmount) {
	vector<vector<double>> multiplied;
	multiplied.resize(rowAmount, vector<double>(1, 0));
	for (int i = 0; i < rowAmount; i++)
			multiplied[i][0] = 0;

	for (int i = 0; i < rowAmount; i++) {
		double total = 0;
		for (int j = 0; j < rowAmount; j++) {
			total += M[j][0] * graph[i][j];
           // cout<<M[j][0]<<" "<<graph[i][j]<<endl;
		}
		multiplied[i][0] = total;
	}
	// Multiplying matrix a and b and storing in array mult.
	
	return multiplied;
}

int main() {
	vector<string> input;
	string line = "";
	//Gets all the input
    string addedLine = "";
    int count = 1;
    //Puts all input into vector for further use
	while (cin >> line) {
        if(count==1){
            addedLine = line + " ";
            count++;
        }
        else if(count==2){
            addedLine = addedLine + line;
            count = 1;
            input.push_back(addedLine);
            addedLine = "";
        }
	}

	//Gets lines and iteration
	vector<string> intInput = parser(input[0]);
	int lineAmount = stoi(intInput[0]);
	int iterations = stoi(intInput[1]);
    
	//Inputs all unique strings
	vector<string> tempVector;
	int tempSize = 0;

	//This used to be a map, but there was an issue with the way the graph was being made, so a O(n^2) function is used instead to parse all the unique strings
	for (int i = 1; i < lineAmount + 1; i++) {
		vector<string> inputTemp = parser(input[i]);
		bool flag0 = false;
		bool flag1 = false;
		for (int j = 0; j < tempSize; j++) {
			if (tempVector[j] == inputTemp[0]) {
				flag0 = true;
			}
			if (tempVector[j] == inputTemp[1]&&inputTemp[1]!=inputTemp[0]) {
				flag1 = true;
			}
		}
		if (!flag0) {
			tempSize++;
			tempVector.push_back(inputTemp[0]);
			flag0=false;
		}
		if (!flag1) {
			tempSize++;
			tempVector.push_back(inputTemp[1]);
		}
	}

	//This is where the unique urls have their out vertices amounts created and then this is where its mapped to an ID
	unordered_map<string, int> websitesAndValues;
    unordered_map<string, int> websitesAndRowIndex;
	for (int i = 0; i < tempSize; i++) {
		websitesAndValues[tempVector[i]] = 0;
        websitesAndRowIndex[tempVector[i]]=i;

	}

	//Adds up all the outVertices
	for (int i = 1; i < lineAmount + 1; i++) {
		websitesAndValues[parser(input[i])[0]]++;
	}

	int rowAmount = tempSize;
	vector<string> uniqueWebsites = tempVector;
	int counter = 0;
	//Counts the amount of rows, also ID use for later
	unordered_map<string, int> mappedKeys;
	for (auto temp : uniqueWebsites) {
		mappedKeys[temp] = counter;
		counter++;
	}

	//Initializes the graph
	vector<vector<double>> graph;
	graph.resize(rowAmount, vector<double>(rowAmount, 0));
	for (int i = 0; i < rowAmount; i++) {
		for (int j = 0; j < rowAmount; j++) {
			graph[i][j] = 0;
		}
	}

	//Puts in all the values into the graph
	for (int i = 1; i < lineAmount + 1; i++) {
		graph[mappedKeys[parser(input[i])[1]]][mappedKeys[parser(input[i])[0]]] = 1 / (double)websitesAndValues[parser(input[i])[0]];
	}
    
	//Createad the vector M
	vector<vector<double>> matrixMultiple;
	matrixMultiple.resize(rowAmount, vector<double>(1, 0));
	for (int i = 0; i < rowAmount; i++) {
		matrixMultiple[i][0] = 1/(double)rowAmount;
	}

	//Matrix multiplication
	for (int i = 0; i < iterations-1; i++) {
		matrixMultiple = matrixMultiplication(matrixMultiple, graph, rowAmount);
	}

    stringstream output;
    
	int index = 0;
    sort(uniqueWebsites.begin(), uniqueWebsites.end());
	for (auto temp : uniqueWebsites) {
    index = websitesAndRowIndex[temp];
    matrixMultiple[index][0] = round(matrixMultiple[index][0]);
    output << fixed << setprecision(2)<<matrixMultiple[index][0];
    string decimal = output.str();
    output.str("");
    cout << temp << " " << decimal<<endl;
	}


	return 0;
}