﻿#include <iostream>
#include <string>
#include <iomanip>
#include <algorithm>
#include <vector>
using namespace std;

class HashTable {

	string* table=0;
	int tableSize=0;

public:
	HashTable(int tblSize) {
		tableSize = tblSize;
		table = new string[tableSize]();
	}

	int asciiSum(string s) {
		if (s.length() <= 1) {
			return (int)s[0];
		}
		else {
			return (int)s[0] + asciiSum(s.substr(1));
		}
	}

	int hash(string s){
		int pos = asciiSum(s) % tableSize;
		while (table[pos] != "" && table[pos] != s) {
			pos++;
			if (pos == tableSize) {
				pos = 0;
			}
		}
		return pos;
	}

	void add(string s) {
		int pos = hash(s);
		table[pos] = s;
	}

	bool hasDuplicate(string s) {
		int pos = hash(s);
		return table[pos] == s;
	}

	void printHash() {
		for (int i = 1; i <= tableSize; i++) {
			cout << i << " " << table[i-1] << endl;
		}
	}

	string* getTable() {
		return table;
	}

};

class Graph {

	int numOfVert = 0;
	double** graph = 0;

public:
	Graph(int numOfvertices) {
		numOfVert = numOfvertices;
		graph = new double*[numOfVert]();
		for (int i = 0; i < numOfVert; i++) {
			graph[i] = new double[numOfVert]();
		}
	}

	void addEdge(int from, int to, int weight) {
		graph[to][from] += weight;
	}

	void addEdge(int from, int to) {
		graph[to][from]++;
	}

	void resizeEdge() {
		for (int from = 0; from < numOfVert; from++) {
			int numOfOuts = 0;
			for (int to = 0; to < numOfVert; to++) {
				if (graph[to][from] != 0) {
					numOfOuts++;
				}
			}
			for (int to = 0; to < numOfVert; to++) {
				if (graph[to][from] != 0) {
					graph[to][from] = 1.0 / numOfOuts;
				}
			}
		}
	}

	double** getGraph() {
		return graph;
	}

	void printGraph() {
		for (int from = 0; from < numOfVert; from++) {
			for (int to = 0; to < numOfVert; to++) {
				cout << graph[from][to] << "\t";
			}
			cout << endl;
		}
	}

};

class PageRank {

	HashTable* urlID = 0;
	Graph* urlLink = 0;
	int numOfLinks = 0;
	int numOfItes = 0;
	int uniqueURL = 0;
	double* curr = 0;


public:
	PageRank() {
		string storedInput = "";
		cin >> numOfLinks;
		cin >> numOfItes;
		urlID = new HashTable(2*numOfLinks);
		for (int i = 0; i < numOfLinks; i++) {
			string from = "";
			string to = "";
			cin >> from;
			cin >> to;
			storedInput = storedInput + from + " " + to + " ";
			if (!urlID->hasDuplicate(from)) {
				uniqueURL++;
			}
			if (!urlID->hasDuplicate(to)) {
				uniqueURL++;
			}
			urlID->add(from);
			urlID->add(to);
		}
		urlID = new HashTable(uniqueURL);
		urlLink = new Graph(uniqueURL);
		for (int i = 0; i < numOfLinks; i++) {
			string from = getNextWord(storedInput);
			string to = getNextWord(storedInput);
			urlID->add(from);
			urlID->add(to);
			int fromID = urlID->hash(from);
			int toID = urlID->hash(to);
			urlLink->addEdge(fromID, toID);
		}
		urlLink->resizeEdge();
	}

	void pwrIte() {
		curr = new double[uniqueURL]();
		double* iteRes = new double[uniqueURL]();
		double** matrix = urlLink->getGraph();
		for (int i = 0; i < uniqueURL; i++) {
			curr[i] = 1.0 / uniqueURL;
		}
		for (int ite = 0; ite < numOfItes-1; ite++) {
			for (int i = 0; i < uniqueURL; i++) {
				for (int j = 0; j < uniqueURL; j++) {
					iteRes[i] = iteRes[i] + matrix[i][j] * curr[j];
				}
			}
			curr = iteRes;
			iteRes = new double[uniqueURL]();
		}
	}

	void printResult() {
		vector<string> IDs;
		for (int i = 0; i < uniqueURL; i++) {
			IDs.push_back((urlID->getTable())[i]);
		}
		sort(IDs.begin(), IDs.end());
		for (int i = 0; i < uniqueURL; i++) {
			string currURL = IDs.at(i);
			int currIndex = urlID->hash(currURL);
			cout << currURL << " " << setprecision(2) << fixed << curr[currIndex] << endl;
		}
		return;
	}

	string getNextWord(string &s) {
		int finalPos = 0;
		while (s[finalPos] != ' ') {
			finalPos++;
		}
		string output = s.substr(0, finalPos);
		s = s.substr(finalPos+1);
		return output;
	}

};

int main() {
	PageRank* pr = new PageRank();
	pr->pwrIte();
	pr->printResult();
	cin.get();
	cin.get();
	return 0;
}