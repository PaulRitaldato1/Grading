/*
 * Mia Friedberg
 * Programming Assignment 2 - Implement Google's Page Rank
 * 30 Nov 18
 * Section 1087/12128
 */
#include <iostream>
#include <cstdlib>
#include <string>
#include "AdjacencyMatrix.h"
using namespace std;
#define MAX 999


AdjacencyMatrix::AdjacencyMatrix(int n) {
    this->n = n;
    visited = new bool [n];
    adj = new float * [n];
    for (int i = 0; i < n; i++) {
        adj[i] = new float [n];
        for (int j = 0; j < n; j++) {
            adj[i][j] = 0;
        }
    }
}

void AdjacencyMatrix::insertEdge(int from, int to) {
    if ( from > n || to > n || from < 0 || to < 0) {
//        cout << "Invalid edge!\n";
    }
    else {
        adj[to - 1][from - 1] = 1;
    }
}

void AdjacencyMatrix::insertWeightedEdge(int from, int to, float oneOverOutDegree) {
    if ( from > n || to > n || from < 0 || to < 0) {
//        cout << "Invalid edge!\n";
    }
    else {
        adj[to - 1][from - 1] = oneOverOutDegree;
    }
}

float * AdjacencyMatrix::multMatrix(float ** squareMatrix, float * colMatrix, int size) {

    float * multiplied = new float[size];
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            multiplied[i] += (squareMatrix[i][j] * colMatrix[j]);
        }
    }
    return multiplied;

}

int AdjacencyMatrix::getOutDegree(int from) {
    int count = 0;
    for(int i = 0; i < n; i++) {
        if(adj[i][from] == 1) {
            count++;
        }
    }
    return count;
}

float AdjacencyMatrix::getOneOverOutDegree(int outDegree) {
    if (outDegree == 0) {
        return 0.0;
    } else {
        float oneOver = 1.0 / outDegree;
        return oneOver;
    }
}

void AdjacencyMatrix::printMatrix() {
    int i, j;
    for (i = 0;i < n;i++) {
        for(j = 0; j < n; j++)
            cout << adj[i][j] << "\t";
        cout << endl;
    }
}

float ** AdjacencyMatrix::returnSquareMatrix() {
    return adj;
}
