#include <iostream>
#include <vector>
#include <unordered_map>
#include <algorithm>

typedef std::vector<double> Vector;
typedef std::vector<Vector> Matrix; // Each vector is a column

// Allocates a Vector with all 0s
Vector allocate_vector(unsigned long size) {
    Vector vec;
    vec.resize(size, 0);
    return vec;
}

// Allocates a vector with all initial value
Vector allocate_vector(unsigned long size, double initial) {
    Vector vec;
    vec.resize(size, initial);
    return vec;
}

// Allocates a square matrix with size
Matrix allocate_matrix(unsigned long size) {
    Matrix mat;
    mat.resize(size);

    for(auto i = 0; i < size; i++) {
        mat[i] = allocate_vector(size);
    }

    return mat;
}

// Extends a matrix with 0s
void extend_matrix(Matrix& mat, unsigned long new_size) {
    auto initial_size = mat.size();
    mat.resize(new_size);

    for(auto i = 0; i < initial_size; i++) {
        mat[i].resize(new_size, 0);
    }

    for(auto i = initial_size; i < new_size; i++) {
        mat[i] = allocate_vector(new_size);
    }
}

// Multiply matrix by vector
Vector operator*(const Matrix& mat, const Vector& vec) {
    auto row_width = vec.size();
    auto col_width = mat.size();

    Vector outVec = allocate_vector(row_width);

    for(auto row = 0; row < row_width; row++) {
        double mat_row_sum = 0;
        for(auto col = 0; col < col_width; col++) {
            mat_row_sum += mat[col][row] * vec[col];
        }

        outVec[row] = mat_row_sum;
    }

    return outVec;
}

// Prints a matrix
void print_matrix(const Matrix& mat) {
    for(int row = 0; row < mat.size(); row++) {
        for(int col = 0; col < mat.size(); col++) {
            //std::cout << mat[col][row] << "\t";
            printf("%2.3f ", mat[col][row]);
        }
        std::cout << std::endl;
    }
    std::cout << std::endl;
}

// Prints a vector
void print_vector(const Vector& vec) {
    for(int row = 0; row < vec.size(); row++) {
        printf(" %2.3f\n", vec[row]);
        std::cout << std::endl;
    }
    std::cout << std::endl;
}

// Sorts alphabetically
bool sort_alpha(const std::pair<std::string, double>& a, const std::pair<std::string, double>& b) {
    return a.first.compare(b.first) < 0;
}


class PageRank {
private:
    std::unordered_map<std::string, unsigned long> page_to_id;
    std::unordered_map<unsigned long, std::string> id_to_page;
    Matrix graph;
    Vector rankings;

    // Get the page id, adding to the lookups if necessary
    unsigned long get_page_id(const std::string& page) {
        if(!page_to_id.count(page)) {
            unsigned long id = id_to_page.size();
            id_to_page[id] = page;
            page_to_id[page] = id;
        }

        return page_to_id[page];
    }

public:
    PageRank() {
        graph = allocate_matrix(0);
        rankings = allocate_vector(0);
    }

    // Adds an edge to the graph
    void add_link(const std::string& from_page, const std::string& to_page) {
        // Get unique ids
        auto from_id = get_page_id(from_page);
        auto to_id = get_page_id(to_page);


        // If graph needs to be expanded
        auto graph_size = graph.size();
        auto new_graph_size = page_to_id.size();
        if(graph_size != new_graph_size) {
            extend_matrix(graph, new_graph_size);
            // Rankings initialized to the first power iteration
            rankings = allocate_vector(new_graph_size, 1.0 / new_graph_size);
            graph_size = new_graph_size;
        }


        // Add the edge as an occupancy
        graph[from_id][to_id] = 1;


        // Rebalance the column
        double col_sum = 0;
        for(auto i = 0; i < graph_size; i++) {
            if(graph[from_id][i] != 0) {
                col_sum++;
            }
        }
        for(auto i = 0; i < graph_size; i++) {
            if(graph[from_id][i] != 0) {
                graph[from_id][i] = 1 / col_sum;
            }
        }
    }

    // Prints the graph
    void print_graph() {
        std::cout << "Entries: \n";
        for(auto i = 0; i < id_to_page.size(); i++) {
            std::cout << "  " << i << "  " << id_to_page[i] << std::endl;
        }
        std::cout << "Graph: \n";
        print_matrix(graph);
    }

    // Runs a power iteration
    void power_iteration() {
        rankings = graph * rankings;
    }

    // Prints the rankings in order
    void print_rankings() {
        // Sort rankings
        std::vector<std::pair<std::string, double>> sorted_rankings;
        sorted_rankings.resize(graph.size());
        for(auto i = 0; i < graph.size(); i++) {
            sorted_rankings[i] = std::make_pair(id_to_page[i], rankings[i]);
        }
        std::sort(sorted_rankings.begin(), sorted_rankings.end(), sort_alpha);

        // Print each ranking
        for(auto rank_line : sorted_rankings) {
            printf("%s %1.2f\n", rank_line.first.c_str(), rank_line.second);
        }
    }
};




int main() {
    PageRank pageRank;

    // Read input numbers
    int numLines, numItr;
    scanf("%d %d\n", &numLines, &numItr);

    // Check bounds on numbers
    if(numLines < 1 || numItr < 1) {
        std::cout << "Invalid input. Try again." << std::endl;
        return 0;
    }

    for(int i = 0; i < numLines; i++) {
        // Read a line
        std::string lineRead;
        getline(std::cin, lineRead);

        // Make sure there's no extraneous spaces
        std::string cleaned;
        std::unique_copy(lineRead.begin(), lineRead.end(), std::back_insert_iterator<std::string>(cleaned),
                         [](char c1, char c2) {
                             return isspace(c1) && isspace(c2);
                         });

        // Verify that there's a space.
        if(cleaned.find(' ') == std::string::npos) {
            std::cout << "Invalid input. Try again." << std::endl;
            return 0;
        }

        // Split the string
        auto from_page = cleaned.substr(0, cleaned.find(' '));
        auto to_page = cleaned.substr(cleaned.find(' ') + 1, cleaned.size());

        // Add the link and rebalance the graph
        pageRank.add_link(from_page, to_page);
    }

    // Perform power iterations
    for(int i = 1; i < numItr; i++) {
        pageRank.power_iteration();
    }

    // Print page ranks
    pageRank.print_rankings();

    return 0;
}