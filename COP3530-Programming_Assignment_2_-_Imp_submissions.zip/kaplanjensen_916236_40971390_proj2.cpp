/*
Google Page Rank
Jensen Kaplan
*/

#include <iostream>
#include<string>
#include<string.h>
#include<list>
#include<iterator>
#include<vector>
#include <algorithm>
#include<iomanip>
using namespace std;

//Given a string (webpage) returns the unique key
int getInd(string p, vector<string> ind){
    for(int i = 0; i < ind.size(); i++){
        if(p == ind.at(i))
            return i;
    }
}

//Class representing adjacency matrix
class Matrix{
    private:
        int rowSize;
        int colSize;
        vector<vector<float>> mat;
    public:
        Matrix(int);
        float getEle(int,int);
        float getEle(string,string,vector<string>);
        void fill(string,string,vector<int>,vector<string>);
        void fill(vector<string>,vector<int>,vector<string>);
        void printMat();
        vector<float> power(vector<float>);
};

//Constructor for adjacency matrix. Initializes all elements to 0.
Matrix::Matrix(int d){
    vector<float> c(d,0);//column all 0s
    for(int i = 0; i < d; i++){
        mat.push_back(c);//create necessary rows all with the 0 column
    }
    rowSize = d;
    colSize = d;
}
//given two integer indices, returns element from adjacency matrix
float Matrix::getEle(int i, int j){
    return mat.at(i).at(j);
}
//given two strings, returns respective element from adjacency matrix
float Matrix::getEle(string i, string j, vector<string> ind){
    int r = getInd(i,ind);
    int c = getInd(j,ind);
    return mat[r][c];
}

//entirely fills in adjacency matrix
void Matrix::fill(vector<string> p,vector<int> out,vector<string> ind){
	//p is the vector of all webpages passed into program
	//while p is not empty, fill in the adjacency matrix element for the first and second element in the vector
    while(p.size() != 0){
        int i = getInd(p[0], ind);
        int j = getInd(p[1], ind);
        mat[j][i] = float(1)/out[i];
        p.erase(p.begin(),p.begin() + 2);//after filling in appropriate adjacency matrix element, delete the first two webpages from p
    }    
}
//print matrix in a formatted way, used for testing
void Matrix::printMat(){
    for(int i = 0; i < rowSize; i++){
        for(int j = 0; j < colSize; j++){
            cout<<getEle(i,j) << "\t";
        }
        cout << endl;
    }
}
//performs power iteration / matrix mult
vector<float> Matrix::power(vector<float> r){
    vector<float> newr;
    float x;
    for(int i = 0; i < rowSize; i++){
        x = 0;
        for(int j = 0; j <colSize; j++){
            //cout << mat[i][j] << "\t";
            x+= mat[i][j]*r[j];
        }
        //cout<<endl;
        newr.push_back(x);
    }
    return newr;
}
//helper function used to instantiate webpage list with no repeats. (Vector that represents V)
bool isIn(string p, vector<string> ind){
    bool in = false;
    if(ind.size() == 0)
        return in;
    for(int i = 0; i < ind.size(); i++){
        if(p == ind.at(i))
            in = true;
    }
    return in;
    
}
//formatted output/print function
void outP(vector<string> ind, vector<float> r){
    for(int i = 0; i < ind.size()-1; i++){//bubble sort the pages and powers in ascending alphabetical order
        for(int j = i+1; j<ind.size(); j++){
            if(ind[i].compare(ind[j]) > 0){
                ind[i].swap(ind[j]);
                swap(r[i],r[j]);
        }
        }
            
    }    
    for(int i = 0; i < ind.size(); i++){
        cout << ind[i] << " "<<fixed<<setprecision(2) << r[i] <<endl;//print with precision to 2 decimals
    }
}

int main()
{
    int x;//number of lines
    int y;//number of iterations
    vector<string> page;//the list of webpages passed to program
    vector<string> ind;//vector representing the webpages and their unique IDs
    cin >> x;
    cin >> y;
	//loop to instantiate page vector
    for(int i = 0; i < x; i++){
        string a;
        string b;
        cin >> a;
        cin >> b;
        page.push_back(a);
        page.push_back(b);
    }
	//fill in unique ID vector
    for(int i = 0; i < page.size(); i++){
        if(isIn(page.at(i), ind) == false)//ensures no repeats
            ind.push_back(page.at(i));
    }
    vector<int> out(ind.size(),0);//vector representing number of outgoing edges for each webpage
    int i = 0;
    while(i < page.size() - 1){//loop to fill in outgoing edge vector
        int inc = getInd(page.at(i), ind);
        out[inc] += 1;
        i+=2;
    }
    Matrix m(ind.size());//adjacency matrix nxn, n being number of unique webpages
    m.fill(page, out, ind);//fill in adjacency matrix
    vector<float> r(ind.size(), float(1)/ind.size());//initial power matrix, all elements 1/V
    for(int i = 0; i < y-1; i++){//perform power iteration desired number of times
            r = m.power(r);
    }
    outP(ind,r);//print final answers
    return 0;
}