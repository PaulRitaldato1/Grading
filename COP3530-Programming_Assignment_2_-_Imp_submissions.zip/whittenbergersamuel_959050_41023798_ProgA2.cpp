#include <iostream>
#include <unordered_map>
#include <string>
#include <vector>
#include <memory>
#include <string.h>
#include <stdio.h>

struct node {
    int id;
    int in_degree = 0;
    int out_degree = 0;
    double rank = 0;
    std::string data;
};

struct edge {
    std::string to;
    std::string from;
};

//insertion sort method used to sort nodes based on the lexicographical value of their string data
void sort_nodes(std::vector<std::shared_ptr<node>>& nodes) {
    std::vector<std::string> strings;
    for (auto i : nodes) {
        strings.push_back(i->data);
    }
    int i = 1;
    int j = 0;
    std::string temp;
    auto temp_node = nodes[i];

    while (i < strings.size()) {
        j = i-1;
        temp = strings[i];
        temp_node = nodes[i];
        while (j >= 0 && strings[j].compare(temp) > 0) {
            strings[j+1] = strings[j];
            nodes[j+1] = nodes[j];
            j--;
        }
        strings[j+1] = temp;
        nodes[j+1] = temp_node;
        i++;
    }
}

int main() {
    int N, pow_it;
    std::cin >> N >> pow_it;

    std::unordered_map<std::string, std::shared_ptr<node>> url_map;

    int url_index = 0;
    std::vector<std::shared_ptr<edge>> edges;
    std::vector<std::shared_ptr<node>> nodes;
    //processing url input
    while (N--) {
        std::string from_page;
        std::string to_page;
        std::cin >> from_page >> to_page;

        std::string a, b;
        //adding new pages to url_map and creating node for url
        if (url_map.find(from_page) == url_map.end()) {
            auto new_node = std::make_shared<node>();
            new_node->id = url_index;
            new_node->data = from_page;
            new_node->out_degree++;

            nodes.push_back(new_node);
            url_map[from_page] = new_node;

            a = from_page;
            url_index++;
        }
        //modifying out degree of existing pages
        else {
            url_map.find(from_page)->second->out_degree++;
            a = from_page;
        }
        //adding new pages to url_map and creating node for url
        if (url_map.find(to_page) == url_map.end()) {
            auto new_node = std::make_shared<node>();
            new_node->id = url_index;
            new_node->data = to_page;
            new_node->in_degree++;

            nodes.push_back(new_node);
            url_map[to_page] = new_node;

            b = to_page;
            url_index++;
        }
        //modifying in degree of existing pages
        else {
            url_map.find(to_page)->second->in_degree++;
            b = to_page;
        }

        //creating new edge and pushing it to edge vector
        auto new_edge = std::make_shared<edge>();
        new_edge->from = a;
        new_edge->to = b;
        edges.push_back(new_edge);
    }

    //creating adjacency matrix and setting all values to 0
    double adj_matrix[url_index][url_index];
    memset(adj_matrix, 0, sizeof(adj_matrix[0][0]) * url_index * url_index);

    //adding edges to adj_matrix
    for (auto i : edges) {
        auto a = url_map.find(i->to)->second->id;
        auto b = url_map.find(i->from)->second->id;
        double deg = 1 / double(url_map.find(i->from)->second->out_degree);
        adj_matrix[a][b] = deg;
    }

    //generating contents of rank vector
    std::vector<double> ranks;
    for (int i = 0; i < url_index; i++) {
        double temp;
        temp = 1 / double(url_index);
        ranks.push_back(temp);
    }

    //matrix multiplication between adjacency matrix and rank vector
    std::vector<double> result;
    pow_it -= 1;
    while (pow_it--) {
        for (int i = 0; i < url_index; i++) {
            double sum = 0;
            for (int j = 0; j < url_index; j++) {
                sum += double(ranks[j]) * double(adj_matrix[i][j]);
            }
            result.push_back(sum);
        }
        ranks = result;
        result.erase(result.begin(), result.end());
    }
    //setting node ranks to proper values
    for (int i = 0; i < url_index; i++) nodes[i]->rank = ranks[i];

    //sorting nodes alphabetically base on string data
    sort_nodes(nodes);

    //printing final results
    for (auto i : nodes) {
        std::cout << i->data << " ";
        printf("%2.2f\n", i->rank);
    }

    return 0;
}
