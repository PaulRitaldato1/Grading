#include <iostream>
#include <cstdlib>
#include <string>
#include <vector>
#include <set>
#include <algorithm>

using namespace std;


class TheMatrix{
private:
    int n;
    double **adj;
    double **multResult;
public:
    TheMatrix(int n){
        this->n = n;
        adj = new double *[n];
        for (int i = 0; i < n; i++){
            adj[i] = new double[n];
            for(int j = 0; j < n; j++){
                adj[i][j] = 0;
            }
        }
    }

    void addEdge(int source, int dest, int outdegree){
        if (source > n || dest > n || source < 0 || dest < 0){
            cout << "error" << endl;
        }
        else{
            adj[dest - 1][source - 1] = 1.0/outdegree;
        }
    }

    double** multMatrix(double **multiplicand){
        multResult = new double*[n];
        for(int i = 0; i < n; i++){
            multResult[i] = new double[1];
        }
        for(int i = 0; i < n; i++){
            for(int j = 0; j < 1; j++){
                for(int x = 0; x < n; x++){
                    multResult[i][j] += adj[i][x] * multiplicand[x][j];
                }
            }
        }
        return multResult;
    }
};

int main(){
    set<string> urlNames;
    vector<string> source;
    vector<string> destination;
    int numLines, powerIteration, urlNum, sourceIndex, destIndex;
    string url_source, url_dest;
    cin >> numLines >> powerIteration;


    for(int i = 1; i <= numLines; i++){ //organize input in alphabetical order
        cin >> url_source >> url_dest;
        urlNames.insert(url_source);
        urlNames.insert(url_dest);
        source.push_back(url_source);
        destination.push_back(url_dest);
    }

    //number of distinguished URLs equals the number of nodes in the graph
    int numNodes = urlNames.size();

    //put alphabetized URLs in a vector list
    vector<string> urlList(urlNames.begin(), urlNames.end());

    //create adjacency matrix
    TheMatrix pageRank(numNodes);

    vector<string>::iterator it;
    int outdegree[numNodes+1];
    for (int i = 0; i < numNodes + 1; i++){
        outdegree[i] = 0;
    }

    //counting the outdegree of vertex
    for(int i = 0; i < numLines; i++){
        it = find(urlList.begin(), urlList.end(), source[i]);
        sourceIndex = distance(urlList.begin(), it) + 1;
        outdegree[sourceIndex]++;
    }

    for(int i = 0; i < numLines; i++){
        //get index of source URL
        it = find(urlList.begin(), urlList.end(), source[i]);
        sourceIndex = distance(urlList.begin(), it) + 1;
        //get index of destination URL
        it = find(urlList.begin(), urlList.end(), destination[i]);
        destIndex = distance(urlList.begin(), it) + 1;
        //cout << "source: " << sourceIndex << " dest: " << destIndex << endl;
        //add to the matrix
        pageRank.addEdge(sourceIndex, destIndex, outdegree[sourceIndex]);
    }

    double **M;
    //rows of M matrix
    M = new double *[numNodes];
    for(int i = 0; i < numNodes; i++){
        M[i] = new double[1];
        M[i][0] = 1.0/numNodes;
    }

    if(powerIteration <= 1){
        for (int i = 0; i < urlList.size(); i++){
            cout << urlList[i];
            printf(" %.2f\n", M[i][0]);
        }
        return 0;
    }
    //multiply power iteration

    double** multiplied = pageRank.multMatrix(M);
    for(int i = 3; i <= powerIteration; i++) {
        M = multiplied;
        multiplied = pageRank.multMatrix(M);
    }

    for (int i = 0; i < urlList.size(); i++){
        cout << urlList[i];
        printf(" %.2f\n", multiplied[i][0]);
    }
    return 0;
}
