#include <iostream>
#include <cstring>
#include <vector>
#include <algorithm>
#include <cstdlib>
#include <iomanip>

class AdjMatrix {
    int numPairs;
    double **myGraph;
    std::vector<std::string> pages;
    double *m;
    public:
        AdjMatrix(int numPairs) {
            this->numPairs = numPairs;
            
            int i, j;
            myGraph = new double*[numPairs];
            for(i = 0; i < numPairs; i++){
                myGraph[i] = new double[numPairs];
                for(j = 0; j < numPairs; j++){
                    myGraph[i][j] = 0;
                }
            }
        }
    
        void addPage(std::string page){
            for(int i = 0; i < pages.size(); i++) {
                if(pages[i] == page)
                    return;
            }
            pages.push_back(page);
        }
    
        void insertEdge(std::string p1, std::string p2){
            int id1, id2, i;
            bool found1 = false, found2 = false;
            for(i = 0; i < pages.size(); i++) {
                if(pages[i] == p1 && found1 == false){
                    id1 = i;
                    found1 = true;
                }
                if(pages[i] == p2 && found2 == false){
                    id2 = i;
                    found2 = true;
                }
                if(found1 && found2)
                    break;
            }

            myGraph[id1][id2] = 1;
            float v = 0;
            // get out degree
            for(i = 0; i < pages.size(); i++) {
                if(myGraph[id1][i] != 0)
                    v++;
            }
            for(i = 0; i < pages.size(); i++) {
                if(myGraph[id1][i] != 0)
                    myGraph[id1][i] = 1/v;
            }
        }
    
        void powerIter(int powerIt) {
            int i, j, k, x, y;
            double temp[pages.size()];
            m = new double[pages.size()];
            for(i = 0; i < pages.size(); i++) {
                    m[i] = 1.0/pages.size();
            }
            
            for(x = 0; x < powerIt - 1; x++) {
                // sest elements in temp to 0
                for(i = 0; i < pages.size(); i++) {
                    temp[i] = 0;
                }
                // matrix multiplication
                for(j = 0; j < pages.size(); j++) {
                    for(k = 0; k < pages.size(); k++) {
                        temp[j] += myGraph[k][j]*m[k];
                    }
                }
                // set m = to temp
                for(y = 0; y < pages.size(); y++) {
                    m[y] = temp[y];
                }
            }
        }
    
        void printPages() {
            for(int i = 0; i < pages.size(); i++) {
                std::cout << i << " " << pages[i] << std::endl;
            }
        }
    
        void printGraph() {
            int x, y;
            for(x = 0; x < pages.size(); x++) {
                for(y = 0; y < pages.size(); y++) {
                   std::cout << std::left  << std::setw(5) << myGraph[y][x];
                }
                std::cout << std::endl;
            }
        }
    
        void printPageRank() {
            int i;
            std::vector<std::pair<std::string, double>> pageRank;
            for(i = 0; i < pages.size(); i++) {
                pageRank.push_back(make_pair(pages[i], m[i]));
            }
            std::sort(pageRank.begin(), pageRank.end());
            for(i = 0; i < pages.size(); i++) {
                std::cout << pageRank[i].first << " " << std::fixed << std::showpoint << std::setprecision(2) << pageRank[i].second << "\n";
            }
        }
};

int main()
{
    int count, powerIt;

    std::string p1, p2, input;
    
    std::cin.clear();
    std::cin >> input;
    count = std::stoi(input);
    AdjMatrix matrix(count);
    
    std::cin >> input;
    powerIt = std::stoi(input);
    
    for(int i = 0; i < count; i++) {
        std::cin >> input;
        p1 = input;
        
        std::cin >> input;
        p2 = input;
        
        matrix.addPage(p1);
        matrix.addPage(p2);
     
        matrix.insertEdge(p1, p2);
   }
    std::cin.clear();
    matrix.powerIter(powerIt);
    matrix.printPageRank();

    return 0;
}