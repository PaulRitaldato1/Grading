/*
 * Mia Friedberg
 * Programming Assignment 2 - Implement Google's Page Rank
 * 30 Nov 18
 * Section 1087/12128
 */
#include <iostream>
#include <cstdlib>
#include <string>
#include <vector>
#include "Hash.h"
#include "AdjacencyMatrix.h"
using namespace std;
#define MAX 999

int main() {
    int numLines, numPwrIt;
    cin >> numLines;
    cin >> numPwrIt;
    Hash Hashy;
    string contents [numLines][2];
    for (int i = 0; i < numLines; i++) {
        string fromWebsiteName;
        cin >> fromWebsiteName;
        Hashy.AddItem(fromWebsiteName);
        contents[i][0] = fromWebsiteName;
        string toWebsiteName;
        cin >> toWebsiteName;
        Hashy.AddItem(toWebsiteName);
        contents[i][1] = toWebsiteName;

    }
    Hashy.AssignNum();
    AdjacencyMatrix AM(Hashy.GetNumCount());

    for (int i = 0; i < numLines; i++) {
        AM.insertEdge(Hashy.IndexOfString(contents[i][0]), Hashy.IndexOfString(contents[i][1]));
    }

    AdjacencyMatrix WeightedAM(Hashy.GetNumCount());


    for (int i = 0; i < numLines; i++) {
        AM.getOneOverOutDegree(AM.getOutDegree(Hashy.IndexOfString(contents[i][0]) - 1));
        WeightedAM.insertEdge(Hashy.IndexOfString(contents[i][0]), Hashy.IndexOfString(contents[i][1]));
        WeightedAM.insertWeightedEdge(Hashy.IndexOfString(contents[i][0]), Hashy.IndexOfString(contents[i][1]), AM.getOneOverOutDegree(AM.getOutDegree(Hashy.IndexOfString(contents[i][0]) - 1)));
    }

    int size = Hashy.GetNumCount();
    float *colMatrix = new float[size];
    for (int m = 0; m < size; m++) {
        colMatrix[m] = 1.0 / size;
    }

    int w = 1;
    while (w < numPwrIt) {
        colMatrix = WeightedAM.multMatrix(WeightedAM.returnSquareMatrix(), colMatrix, size);
        w++;
    }

    for (int i = 0; i < size + 1;i++) {
        string siteName = Hashy.NameFromNum(i + 1);
        Hashy.AssignCalcVal(siteName, colMatrix[i]);
    }

    Hashy.FinalPrint(Hashy.AlphaOrder());

    return 0;

}