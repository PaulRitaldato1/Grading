#include "matrix.hpp"
#include <map>
#include <utility>
#include <vector>
#include <iostream>
#include <iomanip>
int main(){
    std::map<std::string, int> sites;
    std::vector<std::pair<std::string, std::string>> links;
    int numberofLinks;
    int powerseries;
    int numberOfSites = 0;
    std::cin >> numberofLinks;
    std::cin >> powerseries;
    {
        std::string from;
        std::string to;
        for(int i = 0; i < numberofLinks; i++){
            std::cin >> from;
            std::cin >> to;
            links.push_back(std::make_pair(from,to));
            if(sites.count(from)==0){
                sites[from] = numberOfSites;
                numberOfSites++;
            }
            if(sites.count(to)==0){
                sites[to] = numberOfSites;
                numberOfSites++;
            }

        }
    }
    Matrix<float> m(numberOfSites,numberOfSites);
    for(auto linkpair : links){
        int from = sites[linkpair.first];
        int to = sites[linkpair.second];
        m[to][from]++;
    }

    for(int i = 0; i < numberOfSites; i++){
        int total = 0;
        for(int j = 0; j < numberOfSites; j++){
            total += m[j][i];
        }
        if(total > 0){
            for(int j = 0; j < numberOfSites; j++){
                m[j][i] /= total;
            }
        }
    }
    Matrix<float> n(numberOfSites,1);
    for(int j = 0; j < numberOfSites; j++){
        n[j][0] = 1.0f/numberOfSites;
    }
    
    for(int i = 0; i < powerseries-1; i++){
        n = m*n;
    }
    std::cout.precision(2);
    for(const auto &site : sites){
        float temp = n[site.second][0];
        if(temp < 1.0e-22){
            temp = 0;
        }
        std::cout<<site.first<<" "<<std::fixed<<std::showpoint<<std::setw(3)<<temp<<std::endl;
    }
    
    return 0;
}