#include <iostream>
#include <sstream>
#include <set>
#include <map>
#include <iomanip>
#include <string>
#include <sstream>


int main() {

    std::string nums;
    std::getline(std::cin, nums); //get line for num of lines and pow iter
    std::stringstream ss(nums); //create stream

    int numLines;
    int numPowIter;
    ss >> numLines >> numPowIter; //get num lines and pow iter

    std::set<std::string> s; //set initial
    std::map<std::string, int> myMap; //map initial

    std::string connected[numLines][2];


    //input, adding to set, adding to map
    for (int i = 0; i < numLines; i++)
    {
        //get from and to
        //sort into list
        std::string fromTo;
        std::getline(std::cin, fromTo);
        std::stringstream ss2(fromTo);

        std::string from;
        std::string to;
        ss2 >> from >> to;

        //map URLs to set
        s.insert(from);
        s.insert(to);

        //get out degree of each node
        myMap.insert(std::make_pair(from, 0));
        myMap[from]++;

        connected[i][0] = from;
        connected[i][1] = to;
    }

    //create index arrary
    std::string index_arr[s.size()];
    std::set<std::string>::iterator indexIter;
    int index = 0;
    for (indexIter=s.begin(); indexIter!=s.end(); ++indexIter)
    {
        index_arr[index] = *indexIter;
        index++;
    }
    std::cout << '\n';



    double arr_rank[s.size()]; //create array for URL ranks
    double arr_M[s.size()][s.size()] ; //create matrix with initial values of 0

    //creates initial rank r(0)
    for (int i = 0; i < s.size(); i++)
    {
        arr_rank[i] = 1.0/s.size();
    }
    //create initial matrix
    for (int i = 0; i < s.size(); i++)
    {
        for (int j = 0; j < s.size(); j++)
        {
            //insert into matrix
            arr_M[i][j] = 0;
        }
    }


    //add ranks in matrix
    int toIndex;
    int fromIndex;
    int outDegree;
    for (int i = 0; i < numLines; i++)
    {
        for (int j = 0; j < 2; j++)
        {
            for (int k = 0; k < s.size(); k++)
            {
               if (index_arr[k] == connected[i][j])
               {
                   if (j == 0) //get from index and out degree
                   {
                       fromIndex = k;
                       outDegree = myMap.find(index_arr[k])->second;
                   }
                   else //get to index
                   {
                       toIndex = k;
                   }
               }
            }
        }
        arr_M[toIndex][fromIndex] = 1.0/outDegree; // make all connection 1
    }


    double newRank[s.size()];
    for (int i = 0; i < s.size(); i++)
    {
        newRank[i] = 0;
    }

    //power iteration
    if (numPowIter == 0 || numPowIter == 1) //if no power iteration
    {
        for (int i = 0; i < s.size(); i++) //save last rank
        {
            newRank[i] = arr_rank[i];
        }
    }
    else
    {
        for (int i = 1; i < numPowIter; i++) //go thru all power iterations
        {
            for (int row = 0; row < s.size(); row++) //rows
            {
                for (int col = 0; col < s.size(); col++) //columns
                {
                    newRank[row] += arr_M[row][col] * arr_rank[col]; //matrix multiplication
                }
            }
            //save new rank
            for (int l = 0; l < s.size(); l++)
            {
                arr_rank[l] = newRank[l];
                newRank[l] = 0;
            }
        }
    }

    //print out set with rank, use new Rank
    int q = 0;

    std::set<std::string>::iterator it;
     for (it=s.begin(); it!=s.end(); ++it)
     {
         std::cout << *it << " ";
         std::cout << std::setprecision(2) << std::fixed << arr_rank[q] << std::endl;
         ++q;
     }

    return 0;
}


