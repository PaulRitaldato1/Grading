#include <iostream>
#include <vector>
#include <set>
#include <iterator>
#include <map>
#include <iomanip>
using namespace std;
static int numbers[1000];
int a,b;

struct MyPair {
   string web;
   int number;
   int outDegree;
   int afterPower;
};
 int getRowKey(MyPair *websites,string vect,int size){
     for(int i =0; i< size;i++){
      if(websites[i].web == vect){
          return websites[i].number;

     }


 }
        return 1;
 }
 double* matrixMult(vector< vector<double> > matrix,double pageRank[],int powerIterAmount,int size,MyPair *info){
     double arrHold[size];

      if(powerIterAmount<=1){
           for(int i =0; i<size;i++){
                   cout <<fixed << std::setprecision(2)<<info[i].web<<" "<<pageRank[i]<<endl;
             }

          return pageRank;
          return 0;


 }else{
          while(powerIterAmount > 1){

          for(int i =0; i<size;i++){
                double total =0;
           for(int j =0;j<size;j++){
               total=total+(pageRank[j]*matrix[i][j]);
           }
              arrHold[i] = total;
          }
              for(int i =0; i<size;i++){
                    pageRank[i] =arrHold[i];
             }
              --powerIterAmount;
            }
             for(int i =0; i<size;i++){
                   cout <<fixed << std::setprecision(2)<<info[i].web<<" "<<pageRank[i]<<endl;
             }
          return pageRank;
  }
 }


int main()
{

    set<string>::iterator iter;
    set<string> websites;
    vector<string> fromVals;
    vector<string> toVals;
    int numLines=0;
    int val=0;
    int powerIterAmount=0;
    string fromPage;
    string toPage;

    cin>>numLines;
    cin>>powerIterAmount;
if((numLines <0)||(powerIterAmount<0)){
 return 0;
}
    int decre = numLines;
int j;
for(j=0; j<(sizeof(numbers)/sizeof(*numbers));j++){
    numbers[j]=0;
}

    vector<pair<string, int> > adj[numLines];
    while(decre > 0){
      cin >> fromPage;
      cin >> toPage;
    //Insert into set by alpha order
      websites.insert(fromPage);
      websites.insert(toPage);
      //Puts fromPAge values into Vector
      fromVals.push_back(fromPage);
        toVals.push_back(toPage);

            decre--;

    }

    //Adds values to struct from set
   MyPair theWebsitesInfo[1000];
   MyPair myPair;
    for(iter=websites.begin(); iter!=websites.end();++iter) {
    int sizeFrom = fromVals.size()-1;
    int count =0;
    myPair.web = *iter;
    myPair.number = val;

    //Calulcates out Degree
    while(sizeFrom>=0){
    if(*iter==fromVals[sizeFrom]){
    count++;

    }
        --sizeFrom;

    }
    numbers[val]=count;
 myPair.outDegree =  numbers[myPair.number];
     theWebsitesInfo[val] = myPair;

    ++val;

}
//Where adjaceny matrix is created
int test= fromVals.size()-1;
int G =0;
int H =0;
int rowKey=0;
int columnKey;
int columnValue;
double arr[fromVals.size()-1][fromVals.size()-1];

//Initialize with zeros
for(int row =0;row<fromVals.size()-1;row++){
         for(int column =0;column<fromVals.size()-1;column++){
                arr[row][column]=0;
         }
         }


for(int t =0; t<test;++t){
    int h=0;
    // Page rank initialized
 while(h<=test){
  if( theWebsitesInfo[t].web == fromVals[h]){
      columnKey =  theWebsitesInfo[t].number;
      columnValue =  theWebsitesInfo[t].outDegree;
      rowKey = getRowKey(theWebsitesInfo,toVals[h],test);
      arr[rowKey][columnKey] = (1/(double)columnValue);


 }
     ++h;
}
}

    double arrMult[test];
    //Makes original PageRank
        for (int j = 0; j < websites.size(); ++j)
        {
          arrMult[j]=1/(double)websites.size();
        }
        for (int j = 0; j < websites.size(); ++j)
        {

        }

    //Put array into 2d vector
    int hold = websites.size();
   vector< vector<double> > matrix(hold, vector<double>(hold));
            for(int i=0;i<websites.size();i++){
                for(int j=0;j<websites.size();j++){
           matrix[i][j]=arr[i][j];
}
}
    //amount is sum of rows
    //arrMult is 1/size
    //powerIterAmount


   matrixMult(matrix,arrMult,powerIterAmount,websites.size(),theWebsitesInfo);


    return 0;

}
