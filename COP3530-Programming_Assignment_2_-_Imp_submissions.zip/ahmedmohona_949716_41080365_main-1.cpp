#include <iostream>
#include<cstring>
#include <list>
#include <string>
#include <math.h>
#include <unordered_map>

using namespace std;

int _edges = 0;

void setNumberOfEdges(int edges){
    _edges = edges;
}
int getNumEdges() {
    return _edges;
}
int getID(string * HashTable, string URL){
    for(int j = 0; j<_edges; j++){
        if(HashTable[j] == URL){
            return j;
        }
    }
    return 0;
}


class Graph {
public:
    const static int MAXNUMVERTICES = 100;
    float theGraph[MAXNUMVERTICES][MAXNUMVERTICES];

    void fill() {
        for (int i = 0; i < MAXNUMVERTICES; i++) {
            for (int j = 0; j < MAXNUMVERTICES; j++) {
                theGraph[i][j] = 0;
            }
        }
    }

    void insertEdge(int from, int to) {
        theGraph[to][from] = 1.0;
    }

    float getvalue(int i, int j){
        return theGraph[i][j];
    }

    void print(){
        //i print starting at 1 since hashes start at 1
        for(int i = 1; i<= getNumEdges(); i++){
            for(int j = 1; j<= getNumEdges(); j++){
                cout<<theGraph[i][j];
                cout<<" ";
            }
            cout<<"\n";
        }
    }

    int calculateoutdegree(int column){
        int count = 0;
        for (int i = 0; i< MAXNUMVERTICES; i++){
            if  (theGraph[i][column] == 1){
                count++;
            }
        }
        return count;
    }

    void incorportateoutdegree(){
        int outdegree = 0;
        for (int j = 0; j< MAXNUMVERTICES; j++){ //column
            outdegree = calculateoutdegree(j);
            for (int i = 0; i<MAXNUMVERTICES;i++){
                theGraph[i][j] = theGraph[i][j] / outdegree;
            }
        }
    }
};

string extensions(string * HashedUrls, string URL, int uniquevertices){
    //note that the URL may not be hashed yet
    //This method checks for if there is more than one extension to a website and if there is, look through the already hashed URLS and use a previous URL

    string newstr = URL;
    string temp = "";
    string extensions [4] = {".com", ".edu",".uk", ".org"};


    bool containsoneextension = false;
    for (int i = 0; i< 4; i++){
        if (newstr.find(extensions[i]) != string::npos){
            //if it already had an extension
            if(containsoneextension){
                //take the first part of the URL and check the HashedURLS and hash the URL to the most similar URL
                temp = newstr.substr(0, temp.length() - extensions[i].length());
                for(int j = 0; j< uniquevertices; j++ ){
                    //go through Hashed URLS
                    if (HashedUrls[j].find(temp) != string::npos){
                        return HashedUrls[j];
                    }
                }
            }
            //contains an extension
            containsoneextension = true;
            temp = newstr.substr(0, newstr.find(extensions[i])) +
                   newstr.substr(newstr.find(extensions[i]) + extensions[i].length(),newstr.length() - (newstr.length() + extensions[i].length()) );
            newstr = temp;
            i = -1;
        }
        else if(i == 3){
            //doesnt contain extension
            return URL;


        }
    }
}



void userInput() {
    int i = 0;
    string line;
    int numberoflines = 0;
    int poweriterationstoperform = 0;
    list<string> vertices;
    Graph *adjMatrix;
    string *HashedUrls;
    int uniquevertices = 0;
    int linesread = 0;
    bool returnr0 = false;
    bool return0 = false;
    unordered_map<string, float> URLsandKeys;

    getline(cin, line);
    //The first line contains information for initialization, so we are handling this differently.
    int index = line.find(' ');
    //finds first integer
    while (index == 0){
        line = line.substr(1, line.length() - 1);
        index = line.find(' ');
    }

    numberoflines =  stoi(line.substr(0, index - 0 ));
    HashedUrls = new string[numberoflines * 2];
    adjMatrix = new Graph();
    adjMatrix->fill();

    //removes beginning characters of number of lines
    line = line.substr(index + 1, line.length() - index);
    index = line.find(' ');
    //finds next integer
    while (index == 0){
        line = line.substr(1, line.length() - 1);
        index = line.find(' ');
    }
    poweriterationstoperform = stoi(line.substr(0, index));
    //If power iterattions to perform exceeds 10, the output will be 0.
    if (poweriterationstoperform>=10){
        poweriterationstoperform = 10;
    }


    if (numberoflines <= 0 || poweriterationstoperform <= 0) {
        return;
    }

    while (linesread < numberoflines) {
        getline(cin, line);
        linesread++;

        string first = "";
        string second = "";

        //Deliminating by space
        //end is the index where the space is
        int end = line.find(' ');

        //handles case for if the first character in the string is a space and the string is not empty or is just a space
        while(end == 0 && line.length()!=0){
            line = line.substr(1, line.length() - 1);
            end = line.find(' ');
        }

        first = line.substr(0, end);

        //handles case for if there is more than one space in between URLS
        while(end == 0 && line.length()!=0){
            line = line.substr(1, line.length() - 1);
            end = line.find(' ');
        }

        second = line.substr(end + 1, line.length() - end);

        //handles multiple website extensions
        //first = extensions(HashedUrls,first,uniquevertices);
        //second = extensions(HashedUrls,second,uniquevertices);

        //hash if needed
        bool hashed = false;
        int j;

        //Search through array of hashes to see if the first URL has been hashed yet
        for (j = 0; j < numberoflines; j++) {
            if (HashedUrls[j] == first) {
                hashed = true;
                break;
            }
        }

        //hash first URL if needed
        if (!hashed) {
            HashedUrls[uniquevertices+1] = first;
            URLsandKeys[first] = uniquevertices+1;
            uniquevertices++;

        }
        hashed = false;

        //Search through array of hashes to see if the second URL has been hashed yet

        for (j = 0; j < numberoflines; ++j) {
            if (HashedUrls[j] == second) {
                hashed = true;
                break;
            }
        }

        //hash second URL if needed
        if (!hashed) {
            HashedUrls[uniquevertices+1] = second;
            URLsandKeys[second] = uniquevertices+1;
            uniquevertices++;

        }

        //adding edge
        //insert edge(to from) from is adjacent to to
        adjMatrix->insertEdge(URLsandKeys.at(first), URLsandKeys.at(second));


    }

    if (linesread == numberoflines) {
        setNumberOfEdges(uniquevertices);
        //adjMatrix->print();
        adjMatrix->incorportateoutdegree();

        //Returning matrix
        float val = 0.0;
        float **adjacencyMatrix = new float *[uniquevertices];
        for (int i = 0; i < uniquevertices; i++) {
            adjacencyMatrix[i] = new float[uniquevertices];
        }
        for (int i = 1; i <= uniquevertices; i++) {
            for (int j = 1; j <= uniquevertices; j++) {
                val = adjMatrix->getvalue(i, j);
                if (isnan(val)){
                    val = 0.0;
                }
                adjacencyMatrix[i - 1][j - 1] = val;
                val = 0.00;
            }

        }

        //Power Iteration
        float sum = 0.0;
        string theURL = "";
        string thefloat = "";


        //Creating temp matrix and resultant matrix for matrix multiplication
        float **temp = new float *[uniquevertices];
        for (int i = 0; i < uniquevertices; i++) {
            temp[i] = new float[uniquevertices];
        }
        for (int i = 0; i < uniquevertices; i++) {
            for (int j = 0; j < uniquevertices; j++) {
                temp[i][j] = adjacencyMatrix[i][j];
            }
        }

        float **result = new float *[uniquevertices];
        for (int i = 0; i < uniquevertices; i++) {
            result[i] = new float[uniquevertices];
        }
        for (int i = 0; i < uniquevertices; i++) {
            for (int j = 0; j < uniquevertices; j++) {
                result[i][j] = 0;
            }
        }

        int r1 = 0, c2 = 0 , k = 0;

        poweriterationstoperform--;


        //checking if a URL does not point to any other URL. if so, return 0.0
        for(int x = 0; x<uniquevertices;x++){
            if(adjMatrix->calculateoutdegree(getID(HashedUrls, HashedUrls[x]))==0){
                return0 = true;
            }
        }

        //Base Cases
        //Mr(0)
        if (poweriterationstoperform == 0) {
            returnr0 = true;
        } else if (poweriterationstoperform > 1){
            int powerperformed = 1;
            while (powerperformed < poweriterationstoperform) {

                //Matrix Multiplication
                for (r1 = 0; r1 < uniquevertices; r1++) {
                    for (c2 = 0; c2 < uniquevertices; c2++) {
                        //dot product
                        for (k = 0; k < uniquevertices; k++) {
                            result[r1][c2] += temp[r1][k] * adjacencyMatrix[k][c2];
                        }
                    }
                }
                //the power function is performed again with the resultant matrix and the original adjacency matrix
                for (int i = 0; i < uniquevertices; i++) {
                    for (int j = 0; j < uniquevertices; j++) {
                        temp[i][j] = result[i][j] ;
                    }
                }

                for (int i = 0; i < uniquevertices; i++) {
                    for (int j = 0; j < uniquevertices; j++) {
                        result[i][j] = 0 ;
                    }
                }
                powerperformed++;
            }
        }

        //Multuplying A ^ n times r(0)
        for (int i = 0; i < uniquevertices; i++) {
            sum = 0.0;
            for (int j = 0; j < uniquevertices; j++) {
                if(poweriterationstoperform == 0){
                    sum = float(1.00 / uniquevertices);
                    break;
                }
                else {
                    //dot product of resulting matrix with r(0)
                    sum += temp[i][j] * float(1.00 / uniquevertices);
                }
                if (isnan(sum)){
                    sum = 0.0;
                }
            }
            theURL = HashedUrls[i + 1];
            thefloat = to_string(round(sum*100)/100).substr(0,4);
            //if the power iterations to perform is 1, r(0) will be printed
            if(!returnr0){
                HashedUrls[i + 1] = theURL + " " + thefloat;
            }
            else if(returnr0){
                HashedUrls[i + 1] = theURL + " " + to_string(round((1.0/uniquevertices)*100)/100).substr(0,4);
            }
                //if a URL does not point to anything, print ranks of 0
            else if(return0){
                HashedUrls[i + 1] = theURL + " " + to_string(round((0.00)*100)/100).substr(0,4);
            }

        }

        //Alphabetizing using bubble sort

        bool swapped;

        do {
            swapped = false;
            for (int j = 1; j <= uniquevertices; j++) {
                if (HashedUrls[j - 1] > HashedUrls[j]) {
                    std::swap(HashedUrls[j - 1], HashedUrls[j]);
                    swapped = true;
                }
            }
        } while (swapped);

        for (int i = 0; i < uniquevertices; i++) {
            cout << HashedUrls[i + 1] << endl;
        }

        return;

    }
}




int main() {
    //Call function that turns user input into usable data.
    userInput();



}
