//
//  pa2.cpp
//  COP3530_PA2
//
//  Created by Ben Goldstein on 11/12/18.
//  Copyright © 2018 B Goldstein. All rights reserved.
//

#include <iostream>
#include <iomanip>
#include <string>
#include <sstream>
#include <vector>
#include <map>

using namespace std;
//Imports needed for program functionality plus namespace std to ease programming


int matchURLtoIndex(map<string, vector<string>> map, string key) {
    //Maps a matrix index to each entry in the adjacency list - O(n)
    int counter  = 0;
    for(auto& entry : map) {
        if(entry.first == key) {
            return counter;
        }
        counter++;
    }
    return -1;
    //In the event no match is found
}

vector<float> * matrixMultiply(vector<vector<float>> matrix, vector<float> * powers) {
    //Multiplies the power iterations matrix with the out-degree matrix, returns new vector of powers - O(n^2)
    vector<float> * answer = new vector<float>();
        for(int j = 0; j < powers->size(); j++) {
            float value = 0;
            for(int i = 0; i < matrix.size(); i++) {
                value += (float) matrix.at(i).at(j) * powers->at(i);
                //Sum result of each row
            }
            answer->push_back(value);
        }
    return answer;
}

int main(int argc, const char * argv[]) {
    
    cout <<  setprecision(2) <<  fixed;
    //Limit decimal places to 2
    
    int entries;
    int powerIterations;
    cin >> entries;
    cin >> powerIterations;
    cin.ignore();
    //Takes in number of entries and power iterations
    
    if(powerIterations < 1 || entries < 1) {
        return 1;
        //Exit program if unusable number of entries or power iterations provided
    }
    
    powerIterations--;
    //Accounts for auto-generation of first iteration
    int counter = entries;

    map<string, vector<string>> * UrlMap = new map<string, vector<string>>();
    //Map to store adjacency list
    
     string input;
     vector< string> urls;
    
    while(counter > 0) {
        getline( cin, input);
        stringstream stream(input);
         string temp;
        
        while(stream >> temp) {
            urls.push_back(temp);
        }
        //Tokenizes input by whitespaces
        counter--;
    }
    
    int size = 0;
    for(int i = 0; i < urls.size(); i++) {
        if(!UrlMap->count(urls[i])) {
            vector< string> * vec = new vector< string>;
            //Add new entry to map
            UrlMap->insert(pair< string, vector< string>> (urls.at(i), *vec));
            size++;
        }
        
    }
    
    for(int i = 0; i < urls.size(); i += 2) {
            UrlMap->at(urls[i]).push_back(urls[i+1]);
            //Add values to adjacency list after initializing the vector previously
    }
    
    vector<vector<float>> * matrix = new vector<vector<float>>(size, vector<float>(size, 0));
    vector<float> * powers = new vector<float> (size, ((float) 1 / size) );
    //Initialize a 2D vector and a 1D vector for the matrix and list of powers
    
    //Initialize out-degree values in matrix
    for(auto& entry : *UrlMap) {
        int from = matchURLtoIndex(*UrlMap, entry.first);
        for( string string : entry.second) {
            int to = matchURLtoIndex(*UrlMap, string);
            float value = (float) 1 / entry.second.size();
            matrix->at(from).at(to) = value;
        }
    }
    
    while(powerIterations > 0) {
        //Loop through each power iteration
        powers = matrixMultiply(*matrix, powers);
        powerIterations--;
    }
    
    for(auto& entry : *UrlMap) {
        //Print each entry
        cout << entry.first << " " << powers->at(matchURLtoIndex(*UrlMap, entry.first)) << "\n";
    }
    
}
