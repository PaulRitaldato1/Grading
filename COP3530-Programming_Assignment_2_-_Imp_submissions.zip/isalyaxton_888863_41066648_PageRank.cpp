#include <iostream>
#include <sstream>
#include <string>
#include <list>
#include <map>
#include <fstream>


using namespace std;


int main() {
	list<pair<string,string>> from_to_list;
	// store websites in an unordered map with its value representing position in the graph matrix
	// position 1 is index 0 in graph
	map<string, int> websites;
	int num_inserted = 0;
	int num_lines;
	int num_iterations;

	fstream infile;
	infile.open("input.txt");

	if (!infile) {
	    cerr << "Unable to open file";
	    exit(1);
	}

	string data;
	string from, to;
	getline(infile, data);
	stringstream ss(data);
	
	// parse first line
	ss >> num_lines;
	ss >> num_iterations;
	data.clear();

	// Map websites to a unique position
	for(int i = 0; i < num_lines; i++) {
		ss.str(string());
		
		getline(infile, data);
		
		ss.str(data);
		ss >> from;
		ss >> to;

		// store parsed graph links for later placing in graph,
		// since we must count and map them before creating graph
		pair<string, string> temp; 
		temp.first = from;
		temp.second = to;
		from_to_list.push_back(temp);

		// create map entry for each website with unique value (0,1,2,...,n)
		if(websites[from] == 0) {
			num_inserted ++;
			websites[from] = num_inserted;
		}
		if(websites[to] == 0) {
			num_inserted++;
			websites[to] = num_inserted;
		}

		from.clear();
		to.clear();
		data.clear();
	}

	// build graph
	float theMatrix[num_inserted][num_inserted];
	for(int r = 0; r < num_inserted; r++) {
		for(int c = 0; c < num_inserted; c++) {
			theMatrix[r][c] = 0;
		}
	}

	for(list<pair<string,string>>::iterator it = from_to_list.begin(); it!=from_to_list.end(); it++) {
		
		pair<string, string> temp = *it;
		from = temp.first;
		to = temp.second;

		//get positions
		int c = websites[from] - 1;
		int r = websites[to] - 1;

		theMatrix[r][c] = 1;

		from.clear();
		to.clear();
	}

	int outdegree;
	//reinitialize matrix based on outdegree
	for(int c = 0; c < num_inserted; c++) {
		outdegree = 0;
		// store values to prevent redundant traversal
		list<int> has_val;
		for(int r = 0; r < num_inserted; r++) {
			if(theMatrix[r][c] != 0) {
				outdegree += 1;
				has_val.push_back(r);
			}
		}
		// keep a list of out-vertices to reduce redundant searching
		for(list<int>::iterator it = has_val.begin(); it!=has_val.end();it++) {
			theMatrix[*it][c] = (float) 1/outdegree;
		}
	}

	// iteration step
	float r_t[num_inserted];
	fill_n(r_t,num_inserted, (float)1/num_inserted);

	for(int i = 1; i < num_iterations; i++) {
		// create r(t+1)
		float temp[num_inserted];
		for(int r = 0; r < num_inserted; r ++) {
			float val = 0.0f;
			for(int j = 0; j < num_inserted; j ++) {
				val += theMatrix[r][j] * r_t[j];
			}
			temp[r] = val;
		}
		// set r(t) = r(t+1) for next step
		for(int j = 0; j < num_inserted; j++){
			r_t[j] = temp[j];
		}
	}
	
	// output results
	for(map<string,int>::iterator it = websites.begin(); it != websites.end(); it++) {
		int index = it->second - 1;
		cout << it->first << ' ';
		printf("%.2f", r_t[index]);
		cout << endl;
	}

}