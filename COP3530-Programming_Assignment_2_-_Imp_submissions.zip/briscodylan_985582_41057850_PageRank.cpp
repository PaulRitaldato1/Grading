#include <iostream>
#include <map>
using namespace std;

//Returns the sum of a row, used for calculating colMatrix values
double getRowSum(int** matrix, int n, int row) {
  double sum = 0.0;
  for(int i = 0; i < n; i++) {
    sum += matrix[row][i];
  }
  return sum;
}

//Page Rank algorithm using matrix multiplication, returns column vector
double* pageRank(double** multMatrix, double colMatrix[], int size) {
  double* tempMatrix = new double[size];
  for(int i = 0; i < size; i++) {
    tempMatrix[i] = 0;
  }

  for(int i = 0; i < size; i++) {
    for(int j = 0; j < size; j++) {
      tempMatrix[i] += multMatrix[i][j] * colMatrix[j]; // matrix multiplication
    }
  }
  return tempMatrix; // column vector
}

int main() {
  int numURLs;
  int numIterations;
  cin >> numURLs;
  cin >> numIterations;

  int i = 0;
  int j = 0;
  int** adjacencyMatrix = new int*[numURLs]; // matrix of 1 and 0s to determine how sites are linked
  for(int i = 0; i < numURLs; i++) {
    adjacencyMatrix[i] = new int[numURLs];
    for(int j = 0; j < numURLs; j++) {
      adjacencyMatrix[i][j] = 0; // initializes 2d int array with values of 0
    }
  }

  map<string, int> URLMap; //data structure that assigns sites to unique integer id
  while(i < numURLs) {
    string URLMain;
    string URLRef;
    cin >> URLMain;
    cin >> URLRef;

    if(URLMap.find(URLMain) == URLMap.end()) { // if site is not in map
      URLMap[URLMain] = j++; //assigns the site key a unique value
    }
    if(URLMap.find(URLRef) == URLMap.end()) { // if referenced site is not in map...
      URLMap[URLRef] = j++;
    }
    //sets adjacency matrix location of urlmain id and urlref id to 1
    adjacencyMatrix[URLMap[URLMain]][URLMap[URLRef]] = 1;
    i++;
  }

  int numNodes = URLMap.size(); //number of unique sites

  double** multMatrix = new double*[numNodes]; // matrix to be filled with out degree values
  for(int i = 0; i < numNodes; i++) {
    multMatrix[i] = new double[numNodes];
    for(int j = 0; j < numNodes; j++) {
      multMatrix[i][j] = 0.0; //init everything to 0
    }
  }

  for(int i = 0; i < numNodes; i++) {
    for(int j = 0; j < numNodes; j++) {
      if(adjacencyMatrix[i][j] != 0) {
        multMatrix[j][i] = 1.0 / getRowSum(adjacencyMatrix, numNodes, i); // calculates out degree values for matrix
      }
    }
  }

  double *colMatrix = new double[numNodes]; // column matrix, initially with values of 1/unique sites
  for(int i = 0; i < numNodes; i++) {
    colMatrix[i] = 1.0 / numNodes;
  }

  int currentIteration = 1; // page rank iterations begin
  while(currentIteration < numIterations) {
    colMatrix = pageRank(multMatrix, colMatrix, numNodes); // replaces col matrix with calculated pagerank values.
    currentIteration++;
  }
  map<string,int>::iterator itr = URLMap.begin(); //iterator to print alphabetized sites and rounded ranks
  while(itr != URLMap.end()) {
    printf("%s %.2f\n", itr->first.c_str(), colMatrix[itr->second]); // first part rounds. Maps are ordered so already alphabetical. Last part prints rank.
    itr++;
  }
}
