/*
 * Mia Friedberg
 * Programming Assignment 2 - Implement Google's Page Rank
 * 30 Nov 18
 * Section 1087/12128
 */
#include <iostream>
#include <cstdlib>
#include <string>
using namespace std;
#define MAX 999


#ifndef PAGERANK_HASH_H
#define PAGERANK_HASH_H

class Hash {
public:
    Hash();
    int HashFunction(string key);
    void AddItem(string name);
    void AssignNum();
    int GetNumCount();
    int IndexOfString(string name);
    string NameFromNum(int num);
    void PrintTable();
    void AssignCalcVal(string name, float calc);
    string * AlphaOrder();
    void FinalPrint(string * arr);

private:
    static const int tableSize = 20;
    int numCount = 0;

    struct item {
        string name;
        int num;
        float calc;
        item * next;
    };

    item * HashTable[tableSize];
};

#endif //PAGERANK_HASH_H
