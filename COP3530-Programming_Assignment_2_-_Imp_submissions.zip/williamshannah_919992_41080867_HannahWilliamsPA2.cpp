//Programming Assignment 2
//Hannah Williams
//COP3530

#include <iostream>
#include <string>
#include <algorithm>
#include <iomanip>

using namespace std;

//Global Variables
int currIndex = 0;

//O(n)
int getIndex(string stringNameArray[], string urlName)
{
	for(int i = 0; i < currIndex; i++)
	{
		if (stringNameArray[i] == urlName)
		{
			//if urlName found
			return i;
		}
	}
	//if urlName not found
	return -1;
}

//O(1)
int addURL(string stringURLNameArray[], string urlName)
{
	//save url in array
	stringURLNameArray[currIndex] = urlName;
	currIndex++;
	
	return currIndex-1;
}


//O(n^3)
int main()	{ 
	int arg1;
	int arg2;
	string url1 = "";
	string url2 = "";
	int url1Index;
	int url2Index;
	
	string input = "";
	string delimiter = " ";
	
	//get arguments
	getline(cin, input);
	
	//parse input arguments
	arg1 = stoi(input.substr(0, input.find(delimiter)));
	input.erase(0, input.find(delimiter) + 1);						//delete arg1
	arg2 = stoi(input.substr(0, input.find(delimiter)));			
	input.erase(0, input.find(delimiter) + 1);						//delete arg2
	
	
	//defined arrays by maximum possible number of links with number of lines given
	string myURLNameArr[arg1*2];								//1-D array to hold names to prevent adding repeating names	
	double myURLWeightArr[arg1*2][arg1*2];				        //2-D array to hold weight values 												
	
	//fill name array with initial empty values
	for (int i = 0; i < arg1*2; i++)
		myURLNameArr[i] = "";
		
	//fill 2-D array with initial 0 values
	for (int i = 0; i < arg1*2; i++)
		for (int j = 0; j < arg1*2; j++)
			myURLWeightArr[i][j] = 0;
	
	
	//grab URL verticies
	for (int i = 0; i < arg1; i++)
	{
		//get user input (as string)
		getline(cin, input);
		input = input + " ";
	
		//parse input
		url1 = input.substr(0, input.find(delimiter));
		input.erase(0, input.find(delimiter) + 1);				
		url2 = input.substr(0, input.find(delimiter));
		input.erase(0, input.find(delimiter) + 1);	
		
		
		//find indexes of urls, if they exist
		url1Index = getIndex(myURLNameArr, url1);
		url2Index = getIndex(myURLNameArr, url2);
		
		//if indexes do not exist, add them
		if (url1Index == -1)
			url1Index = addURL(myURLNameArr, url1);
		if (url2Index == -1)
			url2Index = addURL(myURLNameArr, url2);
	
		//populate adjacency matrix with current association
						 //fromIndex  //toIndex
		++myURLWeightArr[url1Index][url2Index];
	}
	
	/*
	//debug
	//print name array
	for (int i = 0; i < arg1*2; i++)
	{
		cout<<myURLNameArr[i]<<"\n";
	}
	
	//print weight array
	for (int i = 0; i < arg1*2; i++)
	{
		for (int j = 0; j < arg1*2; j++)
		{
			//prints rows across
			cout<<myURLWeightArr[j][i];
		}
		cout<<"\n";
	}
	
	cout<<"currIndex is: "<<currIndex<<endl;
	*/

	
	//initialize array to hold outdegree
	int arrOutDegree[arg1*2];
	
	//find all outdegrees
	for (int i = 0; i < arg1*2; i++)
	{
		arrOutDegree[i] = 0;

		for (int j = 0; j < arg1*2; j++)
		{
			//sum total numbers of hits in columns
			arrOutDegree[i] = arrOutDegree[i] + int(myURLWeightArr[i][j]);
		}
		
	}
	
	
	//adjust weight array with outdegrees
	for (int i = 0; i < arg1*2; i++)
	{
		for (int j = 0; j < arg1*2; j++)
		{		
			if (arrOutDegree[i] != 0)				//to prevent nan
				myURLWeightArr[i][j] = myURLWeightArr[i][j]/double(arrOutDegree[i]);
		}
	}

	
	//copy weight array to perform operations necessary for power iterations
	double myCopyURLWeightArr[arg1*2][arg1*2];
	
	for (int i = 0; i < arg1*2; i++)
	{
		for (int j = 0; j < arg1*2; j++)
		{
			myCopyURLWeightArr[j][i] = myURLWeightArr[j][i];
		}
	}


	//create array to hold weight sums
	double rankValue[arg1*2];	
	
	//initialize array to initial weight = 1/size
	for (int i = 0; i < arg1*2; i++)
	{
		rankValue[i] = 1;
		rankValue[i] = rankValue[i]/currIndex;
	}
	
	
	
	//perform power iterations
	for (int i = 1; i<arg2; i++)
	{
		
			//perform multiplication
			for (int i = 0; i < arg1*2; i++)
			{
				for (int j = 0; j < arg1*2; j++)
				{
					//multiply all non-zero elements by 1/size == divide by size
					if (myURLWeightArr[j][i] != 0)
						myCopyURLWeightArr[j][i] = myURLWeightArr[j][i] * rankValue[j];
				}
			}
			
			//clear rank array to prepare to hold result
			for (int i = 0; i < arg1*2; i++)
			{	
				rankValue[i] = 0;
			}	
			
			//sum all rows and store result in rank array
			for (int i = 0; i < arg1*2; i++)
			{
				for (int j = 0; j < arg1*2; j++)
				{
					//sum across rows
					rankValue[i] = rankValue[i] + myCopyURLWeightArr[j][i];
				}

			}
			
	}
	
	
	//copy name array
	string myCopyURLNameArr[arg1*2];		
	for (int i = 0; i < arg1*2; i++)
	{	
		myCopyURLNameArr[i] = myURLNameArr[i];
	}
	
	//sort array alphabetically
	sort(myCopyURLNameArr, myCopyURLNameArr + currIndex); 
	
	
	//print results alphabetically
	for (int i = 0; i < arg1*2; i++)
	{
		if (myCopyURLNameArr[i] != "")
		{
			cout<<myCopyURLNameArr[i]<<" ";
			printf("%.*f\n", 2, rankValue[getIndex(myURLNameArr,myCopyURLNameArr[i])]);
		}
	}	
		

	return 0;
}

