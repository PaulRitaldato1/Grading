#include <map>
#include <iomanip>
#include <string>
#include <iostream>
#include <vector>
using namespace std;

class My_Graph {

        vector<vector<double>> theGraph;
        int count;
        multimap<string, int> urls;
        vector<double> outDegree;
        vector<double> ranks;
        
    public:  
    
        My_Graph() {
            count = 0;
            outDegree.push_back(0);
            ranks.push_back(0);
            theGraph.resize(50);
            for(int i = 0; i< theGraph.size(); i++)
                theGraph[i].resize(50);
        }
        
        void insertEdge(string from, string to) {
            if(!isVertex(from)) insertVertex(from);
            if(!isVertex(to)) insertVertex(to);
            int start = urls.find(from)->second;
            int end = urls.find(to)->second;
            if(count > theGraph.size() - 1) {
                theGraph.resize(theGraph.size() * 2);
                for(int i = 0; i<theGraph.size(); i++) {
                    theGraph[i].resize(theGraph.size());
                }
            }
            theGraph[start][end] = 1;
            outDegree[start]++;
        }
        
        void updateMatrix() {
            for(int i = 1; i<count+1; i++) {
                ranks.push_back(1.0 / count);
                for(int j = 1; j <count+1; j++) {
                    if(outDegree[i] >= 1)
                    theGraph[i][j] = theGraph[i][j] / outDegree[i];
                }
            }
            
        }
        
        
        void powerIter() {
            vector<double> beginRanks;
            for(int i = 1; i<count+1; i++) {
                beginRanks.push_back(ranks[i]);
            }
        
            for(int i = 1; i<count+1; i++) {
                double sum = 0;
                for(int j = 1; j<count+1; j++) {
                    sum += theGraph[j][i] * beginRanks[j-1];
                }
                ranks[i] = sum;
            }
            
        }
        
        
        
        void printRanks() {
            multimap<string, int>::iterator it = urls.begin();
            for(; it != urls.end(); it++) {
                cout << fixed;
                cout << setprecision(2);
                    cout << it->first << " " << ranks[it->second] << endl;
            }
        }
        
        
        void insertVertex(string input) {
            urls.emplace(input, ++count);
            outDegree.push_back(0);
        }
        
        bool isVertex(string s) {
            if(urls.find(s) == urls.end())
                return false;
            else return true;
        }
        
};
        
int main() {
    My_Graph pageRanks;
    int lines;
    int numPowIter;
    cin >> lines;
    cin >> numPowIter;
    for(int i = 0; i<lines; i++) {
        string url1, url2;
        cin >> url1;
        cin >> url2;
        pageRanks.insertEdge(url1, url2);
    }
    pageRanks.updateMatrix();
    while(numPowIter > 1) {
        pageRanks.powerIter();
        numPowIter--;
    }
    pageRanks.printRanks();
    
}