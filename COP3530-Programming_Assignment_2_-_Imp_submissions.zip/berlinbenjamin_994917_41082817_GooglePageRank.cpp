#include <iostream>
#include<cstring>
#include<vector>
#include<algorithm>
#include<string>
#include <sstream>
#include <iomanip>
using namespace std;     

class Graph {
    public:
        Graph(int vertices); //constructor
        double** matrix; //matrix before manipulation
        double** temp; //assists in matrix multiplication
        double** finalMatrix; //matrix to be printed
        void insertEdge(int from, int to); //marks a connection between websites
        void divide(int from, int to, int divisor); //divides each point in graph by edges
        void matrixMultiplication(int vertices, bool multiply, bool multiple); //multiplies matrices
        void print(int row, int vertices); //prints data
};
Graph::Graph(int vertices) { //initializes three matrices
        matrix = new double*[vertices];
        for (int i = 0; i < vertices; i++) {
             matrix[i] = new double[vertices];   
        }
        for (int i = 0; i < vertices; i++) {
             for (int j = 0; j < vertices; j++) {
                  matrix[i][j] = 0;   
             }
        }
        temp = new double*[vertices];
        for (int i = 0; i < vertices; i++) {
             temp[i] = new double[vertices];   
        }
        for (int i = 0; i < vertices; i++) {
             for (int j = 0; j < vertices; j++) {
                  temp[i][j] = 0;   
             }
        }
        finalMatrix = new double*[vertices];
        for (int i = 0; i < vertices; i++) {
             finalMatrix[i] = new double[vertices];   
        }
        for (int i = 0; i < vertices; i++) {
             for (int j = 0; j < vertices; j++) {
                  finalMatrix[i][j] = 0;   
             }
        }
}
void Graph::insertEdge(int from, int to) {
     matrix[from][to]++; //adds edge to graph
}
void Graph::divide(int from, int to, int divisor) {
        if (divisor >= 0 && matrix[from][to] != 0) {
             matrix[from][to] = matrix[from][to] / (divisor); //divides by connections had by website
        }
}
void Graph::matrixMultiplication(int vertices, bool multiply, bool multiple) {
    if (multiple) { //if multiple matrix multiplications are being done
        for (int i = 0; i < vertices; i++) {
             for (int j = 0; j < vertices; j++) {
                  temp[i][j] = finalMatrix[i][j]; //temp matrix equals final matrix
                  finalMatrix[i][j] = 0; //initialize final matrix
             }
        }
    }
    if (multiply) { //if matrix multiplication should occur
        for (int i = 0; i < vertices; i++) {
             for (int j = 0; j < vertices; j++) {
                 for (int k = 0; k < vertices; k++) {
                     if (!multiple) {
                         finalMatrix[i][j] += matrix[i][k] * matrix[k][j];
                     }
                     else {
                          finalMatrix[i][j] += temp[i][k] * matrix[k][j];   
                     }
                 }
             }
        }
    }
    else { //no matrix multiplication
         for (int i = 0; i < vertices; i++) {
              for (int j = 0; j < vertices; j++) {
                   finalMatrix[i][j] = matrix[i][j]; //move results from initial matrix to final matrix
              }
         }
    }
}
void Graph::print(int row, int vertices) {
    double pageRank = 0;
    for (int i = 0; i < vertices; i++) { //sum of entire row
         pageRank += finalMatrix[row][i]; 
    }
    pageRank = pageRank / vertices; //divides page rank by vertices in graph
    cout << fixed << setprecision(2) << pageRank << endl;
}
class Node {
    public:
        Node(string websiteName); //constructor
        string site; //website name
        Node* next; //edges
};
Node::Node(string websiteName) {
        site = websiteName;
        next = NULL;
}
bool alphabetSort(Node* node1, Node* node2) { //checks alphabetical order of websites
     return (node1->site < node2->site);
}

int main() {   
    int numberOfLines, powerIterations; 
    string website; //from_page
    string websiteNext; //to_page
    string pages; //contains website and websiteNext
    vector <Node*> websites; //data structure holding websites
    bool websiteInVector = false; //checks if website is already in vector
    int vertices = 0; //total amount of websites
    int totalOutVertices = 0; //checks out vertices of a given website
    int tempIterator = 0; //correlates with iteration over vector
    int tempIterator2 = 0; //also correlates with iteration overe vector
    cin >> numberOfLines;
    cin >> powerIterations;
    if (numberOfLines < 1 || powerIterations < 1) { //error handling
         if (numberOfLines < 1) {
             cout << "ERROR: Invalid number of lines" << endl;   
         }
         else {
             cout << "ERROR: Invalid number of power iterations" << endl;
         }
         return 0;
    }
    vector<Node*>:: iterator i; //initializes first iterator
    vector<Node*>:: iterator it; //initializes second iterator
    getline(cin, website); //moves to next line
    while (numberOfLines > 0) {
        numberOfLines--;
        getline(cin, pages);
        istringstream convert(pages);
        convert >> website;
        convert >> websiteNext;
        for (i = websites.begin(); i != websites.end(); i++) { //checks if website is already in vector
            if ((*i)->site == website) { //website is in vector, now adds edge to it
                 websiteInVector = true;
                 Node * temp = *i;
                 while (temp->next != NULL) {
                     temp = temp->next;
                 }
                 if (websiteNext.length() > 0) {
                     temp->next = new Node(websiteNext);
                 }
                 break;
            }
        }
        if (!websiteInVector) { //adds website to vector
            Node * newNode = new Node(website);
            if (websiteNext.length() > 0) {
                newNode->next = new Node(websiteNext);
            }
            websites.push_back(newNode);  
            vertices++;
        }   
        websiteInVector = false;
        for (i = websites.begin(); i != websites.end(); i++) { //adds website to vector if not already in it
            if ((*i)->site == websiteNext) {
                 websiteInVector = true;   
                 break;
            }
        }
        if (!websiteInVector && (websiteNext.length() > 0)) { //website isn't already in vector
            Node * nodeNew = new Node(websiteNext);
             websites.push_back(nodeNew);  
             vertices++;
        }   
        websiteInVector = false;
    }
    sort(websites.begin(), websites.end(), alphabetSort); //alphabetical sort
    Graph * matrix = new Graph(vertices); //creates adjencency matrix
    Node * temp; //temp node
    if (powerIterations >= 2) { //more than 1 power iteration
        for (i = websites.begin(); i != websites.end(); i++) {
             temp = (*i)->next;   
             while (temp != NULL) {
                 totalOutVertices++; //out vertices counter
                 for (it = websites.begin(); it != websites.end(); it++) {
                     if ((*it)->site == temp->site) { //edge exits
                         matrix->insertEdge(tempIterator2, tempIterator); //adds edge
                         break;
                     }
                     tempIterator2++; //keeps track of current row
                 }
                 tempIterator2 = 0;
                 temp = temp->next;
             }
             for (int j = 0; j < vertices; j++) {
                 matrix->divide(j, tempIterator, totalOutVertices);  //division  
             }
            totalOutVertices = 0;
            tempIterator++; //keeps track of current column
        }
    }
    else { //only 1 power iteration
        for (int j = 0; j < vertices; j++) {
                 matrix->insertEdge(j, 0);
        }
    }
    tempIterator = 0;
    if (powerIterations <= 2) { //no need for matrix multiplication
            matrix->matrixMultiplication(vertices, false, false);
    }
    else { //first matrix multiplication
         matrix->matrixMultiplication(vertices, true, false);   
    }
    for (int j = 3; j < powerIterations; j++) { //if multiple matrix multiplications needed
        matrix->matrixMultiplication(vertices, true, true);
    }
    for (int j = 0; j < vertices; j++) { //print
        cout << websites.at(j)->site << " ";
        matrix->print(j, vertices);
    }
    return 0;
}
