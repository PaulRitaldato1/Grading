/*
 * Mia Friedberg
 * Programming Assignment 2 - Implement Google's Page Rank
 * 30 Nov 18
 * Section 1087/12128
 */
 #include <iostream>
#include <cstdlib>
#include <string>
#include "Hash.h"
using namespace std;
#define MAX 999


Hash::Hash() {
    for (int i = 0; i < tableSize; i++) {
        HashTable[i] = new item;
        HashTable[i]->name = "empty";
        HashTable[i]->next = NULL;
    }
}

int Hash::HashFunction(string key) {
    int hash = 0;
    int index;
    for (int i = 0; i < key.length(); i++) {
        hash = hash + (int)key[i];
    }
    index = hash % tableSize;

    return index;
}

void Hash::AddItem(string name) {
    int index = HashFunction(name);
    if (HashTable[index]->name == "empty") {
        HashTable[index]->name = name;
    } else {
        while (HashTable[index]->name != "empty" && HashTable[index]->name != name) {
            index++;
            if (index >= tableSize) {
                index = 0;
            }
        }
        HashTable[index]->name = name;
    }
}

void Hash::AssignNum() {
    int index = 1;
    for (int i = 0; i < tableSize; i++) {
        if(HashTable[i]->name != "empty") {
            HashTable[i]->num = index;
            index++;
        }
    }
    numCount = index - 1;
}

int Hash::GetNumCount() {
    return numCount;
}


int Hash::IndexOfString(string name) {
    int num = -999;

    for (int i = 0; i < tableSize; i++) {
        if(HashTable[i]->name == name) {
            //cout << HashTable[i]->num << ". ";
            num = HashTable[i]->num;
        }
    }
    return num;
}

string Hash::NameFromNum(int num) {
    string name = "";
    for (int i = 0; i < tableSize; i++) {
        if(HashTable[i]->num == num) {
            name = HashTable[i]->name;
        }
    }
    return name;
}

void Hash::PrintTable() {
    for (int i = 0; i < tableSize; i++) {
        if(HashTable[i]->name != "empty") {
        }
    }
}

void Hash::AssignCalcVal(string name, float calc) {
    for (int i = 0; i < tableSize; i++) {
        if(HashTable[i]->name == name) {
            HashTable[i]->calc = calc;
        }
    }
}

string * Hash::AlphaOrder() {
    string * websiteArr = new string[tableSize];
    int count = 0;
    for (int i = 0; i < tableSize; i++) {
        websiteArr[count] = HashTable[i]->name;
        count++;
    }

    string temp = "";
    for(int i = 0; i < tableSize; i++) {
        for (int j = i + 1; j < tableSize; j++) {
            if (websiteArr[i] > websiteArr[j]) {
                temp = websiteArr[i];
                websiteArr[i] = websiteArr[j];
                websiteArr[j] = temp;
            }
        }
    }
    return websiteArr;
}

void Hash::FinalPrint(string * arr) {
    for (int h = 0; h < tableSize; h++) {
        if (arr[h] != "empty") {
            cout << arr[h] << " ";
            for (int g = 0; g < tableSize; g++) {
                if (HashTable[g]->name == arr[h]) {
                    printf("%.2f\n", HashTable[g]->calc);
                }
            }
        }
    }
}