#pragma once
#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <unordered_map>
#include <iomanip>

class directed_graph
{
    struct node
    {
        std::string name = "";
        float weight = 0.0f;
        float rank = 0.0f;
        unsigned int outdegree = 0;
        std::vector<node *> pointers;  
    };

    unsigned int MAX_VERTICES;
    unsigned int size;

    float **matrix;
    std::vector<node *> websites;

    

public:
    /////// constructors / initialization ///////
    void initialize_matrix()
    {
        matrix = new float*[MAX_VERTICES];

        for (unsigned int i = 0; i < MAX_VERTICES; i++)
            matrix[i] = new float[MAX_VERTICES];
    }

    directed_graph()
    {
        MAX_VERTICES = 100;
        size = 0;

        matrix = nullptr;
    }

    directed_graph(unsigned int capacity)
    {
        MAX_VERTICES = capacity;
        size = 0;
        matrix = nullptr;
    }

	void set_max(unsigned int capacity)
	{
		this->MAX_VERTICES = capacity;
	}

    /////// accessors / helper ///////
	bool static compare_url(const node* left, const node* right)
	{
		return (left->name < right->name);
	}

	void sort_urls()
	{
		std::sort(websites.begin(), websites.end(), compare_url);
	}

    bool exists(std::string website) // maybe change to have vector parameter for more usage !!
    {
        for (unsigned int i = 0; i < websites.size(); i++)
        {
            if (websites[i]->name == website)
                return true;
        }

        return false;
    }

    node *get(std::string website)
    {
        for (unsigned int i = 0; i < websites.size(); i++)
        {
            if (websites[i]->name == website)
                return websites[i];
        }

        return nullptr;
    }

    void clear_matrix()
    {
        if (matrix == nullptr)
            return;

        for (unsigned int i = 0; i < MAX_VERTICES; i++)
        {
            if (matrix[i] != nullptr)
                delete[] matrix[i];
        }

        if (matrix != nullptr)
            delete[] matrix;

        matrix = nullptr;
    }

    void build_matrix()
    {
        // clear current matrix
        clear_matrix();
        // sort vector
		sort_urls();

        // build new matrix based on sorted vector
        initialize_matrix();

        for (unsigned int i = 0; i < websites.size(); i++)
        {
            node *curr = websites[i];

            for (unsigned int j = 0; j < websites.size(); j++)
            {
                // we want to loop through the nodes that point to curr and put the weight in its proper spot
                if (std::find(curr->pointers.begin(), curr->pointers.end(), websites[j]) != curr->pointers.end())
                    matrix[i][j] = 1.0f / float(websites[j]->outdegree);
                
                else matrix[i][j] = 0;
            }
        }
    }

    void update_weight()
    {
        for (unsigned int i = 0; i < websites.size(); i++)
        {
            if (websites[i]->outdegree != 0)
                websites[i]->weight = (1.0f / (websites[i]->outdegree));
        }
    }

    void update_ranks(unsigned int iterations)
    {
        build_matrix();

        std::vector<float> matrix;
        std::vector<float> new_matrix;

        // initial multiplying matrix is just 1/size of graph in each slot
        for (unsigned int i = 0; i < websites.size(); i++)
            matrix.push_back(1.0f / float(websites.size()));

        for (unsigned int i = 0; i < iterations - 1; i++)
        {
            for (unsigned int j = 0; j < websites.size(); j++)
            {
                node *curr = websites[j];
                float temp = 0.0f;

                for (unsigned int k = 0; k < websites.size(); k++)
                {
                    if (std::find(curr->pointers.begin(), curr->pointers.end(), websites[k]) != curr->pointers.end())
                    {
                        temp += matrix[k] * float(websites[k]->weight);
                    }
                }

                new_matrix.push_back(temp);
            }
            
            matrix = new_matrix;
            new_matrix.clear();
        }

		for (unsigned int i = 0; i < websites.size(); i++)
			websites[i]->rank = matrix[i];

    }

    void print_weights()
    {
		//selection_sort();
		sort_urls();

        for (unsigned int i = 0; i < websites.size(); i++)
            std::cout << std::setprecision(2) << websites[i]->name << " " << websites[i]->weight << std::endl;
    }

    void print_ranks(unsigned int iterations) // MUST SORT FOR OUTPUT!
    {
        update_ranks(iterations);

		std::cout.precision(2);

        for (unsigned int i = 0; i < websites.size(); i++)
            std::cout << std::fixed << std::setprecision(2) << websites[i]->name << " " << websites[i]->rank << std::endl;

    }

    /////// insertion ///////
    void insert_edge(std::string &to, std::string &from)
    {
        // add out of bounds check? ie, adding to 'filled' graph (MAX_VERT check)

        if (!exists(from) && !exists(to)) // neither exist in the graph
        {
            node *website_to = new node();
            node *website_from = new node();

            website_to->name = to;
            website_from->name = from;

            website_from->outdegree++;

            website_to->pointers.push_back(website_from);

            websites.push_back(website_to);
            websites.push_back(website_from);

            size += 2; // two NEW nodes created           
        }

        else if (!exists(from) && exists(to)) // from website does not exist, one pointed at does
        {
            node *website_to = get(to);

            node *website_from = new node();
            website_from->name = from;

            website_from->outdegree++;

            website_to->pointers.push_back(website_from);

			websites.push_back(website_from);

            size++; // one new node
        }

        else if (exists(from) && !exists(to)) // from website exists, one pointed at does not
        {
            node *website_from = get(from);

            node *website_to = new node();
            website_to->name = to;

            website_from->outdegree++;

            website_to->pointers.push_back(website_from);

			websites.push_back(website_to);

            size++; // one new node
        }

        else // both exist
        {
            node *website_to = get(to);
            node *website_from = get(from);

            website_from->outdegree++;

            website_to->pointers.push_back(website_from);
        }

        update_weight();
    }

    /////// removal / destructor ///////
    ~directed_graph()
    {
        clear_matrix();
    }
    
};