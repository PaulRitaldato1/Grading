#include <iostream>
#include <cstring>
#include <set>
#include <unordered_map>
using namespace std;

int main()
{
	int edge_amount;
	cin >> edge_amount;
	int power_iterations;
	cin >> power_iterations;
	string edges[edge_amount][2];
	// we use a set in order to not have duplicates
	set<string> page_set;
	for (int i = 0; i < edge_amount; i++) {
		cin >> edges[i][0];
		cin >> edges[i][1];
		page_set.insert(edges[i][0]);
		page_set.insert(edges[i][1]);
	}
	// now we can get the number vertices from the set
	int vertex_amount = page_set.size();
	string vertices[vertex_amount];
	copy(page_set.begin(), page_set.end(), vertices);
	// locations of indices in the above array to translate the edges to graph
	unordered_map<string,int> locations;
	for (int i = 0; i < vertex_amount; i++)
		locations[vertices[i]] = i;
	// create graph using locations
	double graph[vertex_amount][vertex_amount] = {};
	// initialize graph with 1s
	for (int i = 0; i < edge_amount; i++)
		graph[locations[edges[i][0]]][locations[edges[i][1]]] = 1;
	// divide each edge by out degree
	for (int i = 0; i < vertex_amount; i++) {
		int out_degree = 0;
		for (int j = 0; j < vertex_amount; j++)
			out_degree += graph[i][j];
		for (int j = 0; j < vertex_amount; j++)
			if (graph[i][j] != 0)
				graph[i][j] /= out_degree;
	}
	double rank[vertex_amount];
	// initialize rank to 1/V
	for (int i = 0; i < vertex_amount; i++)
		rank[i] = 1.0 / vertex_amount;
	// perform power iterations
	for (int p = 2; p <= power_iterations; p++) {
		double next_rank[vertex_amount] = {};
		for (int i = 0; i < vertex_amount; i++)
			for (int j = 0; j < vertex_amount; j++)
				next_rank[i] += rank[j] * graph[j][i];
		memcpy(rank, next_rank, sizeof(rank));
	}
	// print output
	for (int i = 0; i < vertex_amount; i++) {
		cout << vertices[i] << " ";
		printf("%.2f", rank[i]);
		cout << endl;
	}
	return 0;
}