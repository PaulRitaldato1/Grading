//
//  main.cpp
//  Project 2
//
//  Created by Justin Lawrence on 11/26/18.
//  Copyright © 2018 Justin Lawrence. All rights reserved.
//

#include <iostream>
#include <vector>
#include <algorithm>
class sites{
public:
    std::string name;
    int id;
    std::string goTo;
    int goToID;
    int numDegree;
    float powerIteration;
};

bool ValueCmp(sites const & a, sites const & b) {
    return a.name < b.name;
}


int main(int argc, const char * argv[]) {
    int numLines = 0;
    int numPowerIt = 0;
    std::string firstSite = "";
    std::string secondSite = "";
    bool addFirstSite = true;
    bool addSecondSite = true;
    
    sites newWebsite;
    sites addingToMap;
    
    std::vector<sites> usedSites;
    std::vector<sites> mapCreator;

    std::cin>>numLines;
    std::cin>>numPowerIt;
    int counter = 1;
    for(int i = 0; i<numLines; i++){
        std::cin>>firstSite;
        std::cin>>secondSite;
        
        addingToMap.name = firstSite; //saves what are the out-going sites
        addingToMap.goTo = secondSite;
        mapCreator.push_back(addingToMap);
        
        addFirstSite = true;
        addSecondSite = true;
        if (usedSites.empty()){ //for the first time, add the first site to the array
            newWebsite.name = firstSite;
            newWebsite.id = counter++;
            usedSites.push_back(newWebsite);
            
            newWebsite.name = secondSite;
            newWebsite.id = counter++;
            usedSites.push_back(newWebsite);
            
        }
        else {
            for(int i = 0; i<usedSites.size(); i++){
                if(firstSite == usedSites[i].name){ //if check to see if the website was ever added
                    addFirstSite = false; //the first site is already added
                    // std::cout<<"Ducplicate with"<<firstSite;
                }
                if (secondSite == usedSites[i].name){
                    addSecondSite = false; // the second site is already added
                    //std::cout<<"Ducplicate with"<<secondSite;
                }
            }
            if (addFirstSite) {
                newWebsite.name = firstSite;
                newWebsite.id = counter++;
                usedSites.push_back(newWebsite);
                //std::cout<<"adding new site"<<newWebsite.name<<"\n";
            }
            if (addSecondSite){
                newWebsite.name = secondSite;
                newWebsite.id = counter++;
                usedSites.push_back(newWebsite);
                //std::cout<<"adding new site"<<newWebsite.name<<"\n";
            }
        }
    }

    for (int i =0; i<usedSites.size(); i++){ //finds the out degree of each site
        int outDegree = 0;
        for (int j=0; j<mapCreator.size(); j++){
            
            if (mapCreator[j].name == usedSites[i].name){ //adds the id number to to site
                mapCreator[j].id = usedSites[i].id;
            }
            if (mapCreator[j].goTo == usedSites[i].name){ //adds id number to outgoing site
                mapCreator[j].goToID = usedSites[i].id;
            }
            
            if (usedSites[i].name == mapCreator[j].name){ //finds the number of out-degrees
                outDegree++;
            }
        }
        for (int k=0; k<mapCreator.size(); k++){
            if (usedSites[i].name == mapCreator[k].name){
                mapCreator[k].numDegree = outDegree; //saves the number of out-degrees
            }
        }
    }

//    std::cout<<"Data Structure 1: \n";
//    for (int k=0; k<usedSites.size(); k++){ //prints out webites with id numbers
//        std::cout<<usedSites[k].id<<" "<<usedSites[k].name<<"\n";
//    }
//
//    std::cout<<"Data Structure 2: \n";
//    for (int m=0; m<mapCreator.size(); m++){ //this puts the id number with each site
//        std::cout<<mapCreator[m].id<<" "<<mapCreator[m].name<<"->"<<mapCreator[m].goToID<<" "<<mapCreator[m].goTo<<"\n"; //print what connects with what
//    }
//
//    std::cout<<"printing out degree:\n";
//    for (int i=0; i<mapCreator.size(); i++){
//        std::cout<<mapCreator[i].name<<": "<<mapCreator[i].numDegree<<"\n";
//    }
    
    counter -= 1; //this will be the size of the matrix
    
    float graph[counter][counter]; //create an empty 2D array
    for (int i=0; i<counter; i++){
        for (int j=0; j<counter; j++){ (graph[i][j] = 0);} }
    
    for (int i = 0; i<mapCreator.size(); i++){ //add eveything to the matrix
        graph[mapCreator[i].goToID-1][mapCreator[i].id-1] = 1.0*1/(mapCreator[i].numDegree);
    }
    
//    std::cout<<"print matrix:\n";
//    for (int i = 0; i < counter; ++i) {
//        for (int j = 0; j < counter; ++j) {
//            std::cout << graph[i][j] << "\t";
//        }
//        std::cout<<"\n";
//    }
    
    
    float multMatrix[counter][1];
    float finished[counter][1];
    
    for (int i=0; i<counter; i++) { //set up finished matrix and mulitplied matrix
        (multMatrix[0][i] = 1.0*1/counter);
        finished[0][i] = 0;
    }
    
//    std::cout<<"print matrix:\n";
//    for (int i = 0; i < counter; ++i) {
//        for (int j = 0; j < 1; ++j) {
//            std::cout << multMatrix[i][j] << "\t";
//        }
//        std::cout<<"\n";
//    }
    
    for (int i = 0; i<numPowerIt-1; i++) { //repeat the matrix multiplication the number of times given
        
//        for(int i = 0; i < counter; i++) {
//            for(int j = 0; j < 1; j++) {
//                for(int k=0; k<counter; k++) {
//                    finished[i][j] += graph[i][k] * multMatrix[k][j];
//                }
//            }
//        }
        for (int i = 0; i < counter; i++) {
            for (int j = 0; j < 1; j++) {
                finished[i][j] = 0;
                for (int x = 0; x < counter; x++) {
                    finished[i][j]=finished[i][j]+(graph[i][x]*multMatrix[x][j]);
                }
            }
        }
        for (int j = 0; j<counter; j++){ //reset by saving the new matrix to be what you mult. by
            multMatrix[0][j] = finished[0][j];
           // std::cout<<multMatrix[0][j]<<"\n";
        }
       // std::cout<<"\n";
    }
    
//    std::cout<<"print final matrix:\n";
//    for (int i = 0; i < counter; ++i) {
//        std::cout << finished[0][i] << "\t";
//        std::cout<<"\n";
//    }
//

    for (int i = 0; i<usedSites.size(); i++){ //add the power iteration to each site
        usedSites[i].powerIteration = multMatrix[0][i];
    }
    std::sort(usedSites.begin(), usedSites.end(), ValueCmp); //sorts alpabetically
    for (int i = 0; i<usedSites.size(); i++){ //add the power iteration to each site
        std::cout.precision(2);

        std::cout<<usedSites[i].name<<" "<<std::fixed<<usedSites[i].powerIteration<<"\n";
    }
    
    return 0;
}
