#include "Webpage.h"
/*=========================================WEBPAGE CLASS=========================================*/
/*===============================================================================================*/


Webpage::Webpage(std::string name){
  this->url = name;
  this->ptsTo->reserve(10);
}
Webpage::Webpage(){
  this->url = nullptr;
  this->ptsTo->reserve(10);
}

Webpage::Webpage(std::string name, bool in, Webpage *outTo, int inx){
  url = name;
  pageRank = 0;
  this->index = inx;
  ptsTo= new std::vector<Webpage*>();
  if(in) {
    inDeg=1;
    outDeg =0;
  }
  else{
      this->ptsTo->push_back(outTo);
    inDeg = 0;
    outDeg =1;
  }
}


//out degree
unsigned int Webpage::getOut(){return this->outDeg;}
void Webpage::incrementOut(){this->outDeg++;}

//in degree
unsigned int Webpage::getIn(){return this->inDeg;}
void Webpage::incrementIn(){this->inDeg++;}

//url
void Webpage::editURL(std::string name){this->url = name;}
std::string Webpage::getURL(){return this->url;}

//page pageRank
double Webpage::getPageRank(){return this->pageRank;}
void Webpage::setPageRank(double rank){this->pageRank = rank;}

//ptsTo
std::vector<Webpage* >*  Webpage::getPtsTo(){return this->ptsTo;}


/*-------------------------------prints points to-------------------------------
 * prints the webpage urls that the origin points to
 */
void Webpage::printPtsTo()
{
  std::cout<< " pts to:\t";
  for(std::vector<Webpage*>::iterator it = this->getPtsTo()->begin(); it < this->getPtsTo()->end(); it++){
    printf("%-7s, ", (*it)->getURL().c_str());
  }
}

/*------------------------------link-------------------------------
 * links the this to the website parameter
 * (this points to the website parameter)
 */
void Webpage::link(Webpage *ptsTo){
  this->ptsTo->push_back(ptsTo);
}


//index
int Webpage::getIndex(){
  return this->index;
}
