#include <iostream> 
#include <sstream>
#include <set> 
#include <string> 
#include <list>
#include <utility> 
#include <vector>
#include <iomanip>
#include <cstdlib>
#include <cctype>
#include <algorithm> 

using namespace std;

int main()
{
	//calculate the rank of each node
	string inputLine = "";
	string url1 = "";
	string url2 = "";
	list<string> urls;
	vector<pair<int, int>> links;
	int numEdges = 7;
	int powerItter = 100;
	//take in number of edges and n power iterations
	getline(cin, inputLine);
	stringstream ss(inputLine);
	ss >> numEdges >> powerItter;
	//add each url to map each url to a unique id
	//for each edge
	for (int i = 0; i < numEdges; i++) {
		//parse the urls from input links
		getline(cin, inputLine);
		stringstream ss(inputLine);
		//parse the first and second url in the link
		ss >> url1 >> url2;
		//add to the end of urls
		urls.push_back(url1);
		urls.push_back(url2);
		//check for repeat values
		//find the id of to and from 
		int j = 0;
		list<string>::iterator it;
		int to = -1;
		bool eraseTo = false;
		int from = -1;
		bool eraseFrom = false;
		for (it = urls.begin(); it != urls.end(); ++it) {
			//to = -1;
			//from = -1;
			if (*it == url1 && from == -1) {
				from = j;
			}
			else if (*it == url1 && from != -1) {
				eraseFrom = true;
			}
			if (*it == url2 && to == -1) {
				to = j;
			}
			else if (*it == url2 && to != -1) {
				eraseTo = true;
			}
			if (eraseFrom || eraseTo) {
				it = urls.erase(it);
				it--;
				eraseTo = false;
				eraseFrom = false;
			}
			else {
				j++;
			}

		}
		//debug print urls 
		//cout << url1 << " is at " << from<<endl;
		//cout << url2 << " is at " << to<<endl;
		//save that to the first part of the links list pair
		pair<int, int> link(from, to);
		links.push_back(link);
	}
	//create graph matrix
	//initialize 2d array M[url.size()][url.size()]
	const int numUrls = urls.size();
	vector<vector<double>> M;
	//for each initialize to 0
	M.resize(urls.size(), vector<double>(urls.size(), (double)0));
	//for each link
	for (int i = 0; i < links.size(); i++) {
		//place a 1 in M[links[i].first()][links[i].second()]
		M[links[i].second][links[i].first] = 1;
	}
	double dj = 0;
	set<int> nonzero;
	//for each row
	//calculate the outdegree by iterating through M[i][j]
	for (int i = 0; i < urls.size(); i++) {
		for (int j = 0; j < urls.size(); j++) {
			if (M[j][i] != 0) {
				//increament dj for every non zero value
				dj++;
				nonzero.insert(j);
			}
		}
		for (int j = 0; j < urls.size(); j++) {
			if (nonzero.find(j) != nonzero.end()) {
				M[j][i] = 1 / dj;
			}
		}
		nonzero = {};
		dj = 0;
	}
	//print graph
	//std::cout << std::setprecision(2) << std::fixed;
	//for (int i = 0; i < urls.size(); i++) {
	//	for (int j = 0; j < urls.size(); j++) {
	//		cout << M[i][j] << " ";
	//	}
	//	cout << endl;
	//}
	//create initial r(0) with a vector of size number of vertices initialized to 1/number of vertices
	vector<double> r0;
	r0.resize(urls.size(), 1 / (double)urls.size());
	//initialize rn
	vector<double> rn;
	rn.resize(urls.size(), 0);
	if (powerItter > 1) {
		//multiply M*r0 onto rn
		//for each row in rn
		for (int i = 0; i < urls.size(); i++) {
			for (int j = 0; j < urls.size(); j++) {
				rn[i] += M[i][j] * r0[j];
			}
		}
		//print r1
		/*cout << "n = " << 1 << endl;
		cout << "Rn is" << endl;
		for (int j = 0; j < urls.size(); j++) {
			cout << rn[j] << endl;
		}
		cout << endl;*/
		//for each power iteration after 2,  M*rn onto a temp
		vector<double> temp;
		temp.resize(urls.size(), 0);
		for (int pow = 0; pow < powerItter - 2; pow++) {
			for (int i = 0; i < urls.size(); i++) {
				for (int j = 0; j < urls.size(); j++) {
					temp[i] += M[i][j] * rn[j];
				}
			}
			//set rn to the temp
			rn = temp;
			//debug print rn
			/*cout << "n = " << pow + 2 << endl;
			cout << "Rn is" << endl;
			for (int j = 0; j < urls.size(); j++) {
				cout << rn[j] << endl;
			}
			cout << endl;
			*/
			temp.clear();
			temp.resize(urls.size(), 0);
		}
	}
	else {
		rn = r0;
	}
	std::cout << std::setprecision(2) << std::fixed;
	//pair power rankings with the urls
	list<string>::iterator it;
	vector<pair<string, double>> powerRankings;
	int i = 0;
	for (it = urls.begin(); it != urls.end(); ++it) {
		powerRankings.push_back(make_pair(*it, rn[i]));
		i++;
	}
	sort(powerRankings.begin(), powerRankings.end());
	//print power rankings for the win
	for (int i = 0; i < powerRankings.size(); i++) {
		cout << powerRankings[i].first << " " << powerRankings[i].second << endl;
	}
	return 0;
}