//Rahul Dani - PageRank Project - COP 3530
#include<iostream> //Import Libraries
#include<cstring>
#include<algorithm>
#include<map>
#include<vector>
#include<string>
#include<iomanip>
#include <sstream>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
using namespace std; //Namespace std.

void removeUrl(string sortedLinks[], int idx, int &size) //Function to remove extra urls.
{
    int i;
    for(i = idx; i < size - 1; i++)
        sortedLinks[i] = sortedLinks[i + 1]; //Adjusts the array for duplicates.
    size--; //Update size value.
}

void removeDuplicate(string sortedLinks[], int &size) //Checks for duplicates.
{
    int i, j; //Initiaze ints.
    string url; //Initialize url string.
    for(i = 0; i < size; i++)
    {
        url = sortedLinks[i];
        for(j = i + 1; j < size; j++)
        {
            if(url == sortedLinks[j])
            {
              removeUrl(sortedLinks, j, size); j--; //Runs the duplicate function
            }
        }
    }
}

int main(){ //Main method.
    multimap<int,string> IdNameMap; //Initializes Map with Unique Id and Name
    multimap<string, string> inOutMap; //Map for checking in and out degree of strings.
    vector <double> outDegreeArray; //Initialize vector to keep track of outDegree.
    vector <double> answer; //Initialize vector that is 1/|V|, to be multiplied.

    int num[2]; //Initialize the array with the 2 input values.
    for(int i = 0; i<2; i++){
        cin >> num[i]; //Load the array with the integer inputs.
        if(!cin){
            return 0;
        }
    }
    int size = num[0]*2; //Get initial size to 2 times first integer input.
    string links[num[0]*2]; //Initialize links size.

    for(int i=0; i<num[0]*2; i++){
        cin >> links[i]; //Input all the links.
        istringstream s(links[i]);
        int c;
        if (s >> c) {
          return 0;
        }
    }

    for (int i=0; i<size; i=i+2){
      inOutMap.emplace(links[i],links[i+1]); //Add links in and out into map.
    }

    string sortedLinks[1000]; //Intializing a size for sortedLinks.
    for(int i =0; i<num[0]*2; i++){
        sortedLinks[i] = links[i]; //Put links in sortedlinks.
    }

    sort(sortedLinks, sortedLinks+(num[0]*2)); //Method to sort the links alphabetically.

    removeDuplicate(sortedLinks, size); //Remove duplicate links.

    for (int i=0; i<size; i++){
      IdNameMap.emplace(i+1,sortedLinks[i]); //Put unique ID and link into a map.
    }

    for(auto x = IdNameMap.begin(); x!= IdNameMap.end(); x++){ //Iterate through IdNameMap.
      double temp = 0.0; //Temp variable.
      for(auto y = inOutMap.begin(); y!= inOutMap.end(); y++){ //Iterate though inOutMap.
        if(x->second == y->first){ //If the second column IdNameMap is equal to the first of the inOutMap.
          temp++; //Increment temp.
        }
      }
      outDegreeArray.push_back(1.00/temp); //The vector of unique link outRanks.
    }

    double result[size][size]; //Initialize adjacency matrix array.
    for(int i=0; i<size; i++){
      for(int j=0; j<size; j++){
        result[i][j] = 0.0; //Set all elements to 0.0.
      }
    }

    for(int i = 0; i<size; i++){
      for(int j = 0; j<size; j++){
        string nameIn = " "; //Initalize nameOut.
        string nameOut = " "; //Initialize nameOut.
        for(auto x = IdNameMap.begin(); x!=IdNameMap.end(); x++){
          int a = i+1;
          if(x->first == a){ //Check if the the value of a is that of the first column of IdNameMap.
            nameIn = x->second;  //Then nameIn becomes the link.
          }
        }
        for(auto x = IdNameMap.begin(); x!=IdNameMap.end(); x++){
          int b = j+1;
          if(x->first == b){ //check if the value of b is that of the first column of IdNameMap.
            nameOut = x->second; //Then nameOut becomes that link. Now we have kept track of in and out links.
          }
        }
        for(auto x = inOutMap.begin(); x!=inOutMap.end(); x++){
          if(x->first == nameOut && x->second == nameIn){ //If the nameOut and nameIn match to the inOutMap; match found.
            result[i][j] = outDegreeArray[j]; //Place those element values into the adjacency matrix.
          }
        }
      }
    }

    for(int i=0; i<size; i++){
      answer.push_back((1.0)/(double)size); //Put 1/|V| into all the element of the answer vector.
    }

    double finRank[size]; //Initialize finRank array that displays the page rank.
    for(int i =0; i<num[1]-1; i++){
      for(int j=0; j<answer.size(); j++){
        double temp = 0.0;
        for(int k = 0; k < answer.size(); k++){
        temp+=result[j][k] * answer[k]; //Matrix Multiplication
      }
      finRank[j] = temp; //Store the answer into the finRank array.
    }
    for(int i=0; i<answer.size(); i++){
      answer[i] = finRank[i]; //Power iterations performed.
    }
  }

  cout << fixed << setprecision(2); //Rounds to 2 decimal places.
  for(int i=0; i<size; i++){
      if(num[1] == 1){ //Checks if number of iterations is 1.
          cout << sortedLinks[i] << " " << answer[i]; //Print out sorted links with 1/size as page rank.
          cout << endl;
      }
      else{ //If number of iterations is not 1, continue.
      cout << sortedLinks[i] << " " << finRank[i]; //Print out the link alphabetically with its page rank.
      cout << endl;
      }
    }
}
