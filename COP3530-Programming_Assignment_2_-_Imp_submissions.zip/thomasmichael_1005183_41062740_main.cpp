#include <map>
#include <string>
#include <vector>
#include <sstream>
#include <iostream>
#include <set>
#include <utility>
#include <algorithm>

using namespace std;

struct Graph
{
    struct UserInput
    {
        istringstream numbers;
        istringstream urls;

        string numInput = "";
        string urlInput = "";
        string urlFrom = "";
        string urlTo = "";

        int powerIter = 0;
        int lines = 0;
    };

    UserInput user;
    int uniqueID = 0;
    double** matrix;

    vector<double> rankings;
    vector<double> finalResult;
    map<string, int> uniqueIDs;

    // creates 2d matrix
    void adjacencyMatrix()
    {
        matrix = new double*[user.lines];

        for (int i = 0; i < user.lines; i++)
        {
            matrix[i] = new double[user.lines];

            for (int j = 0; j < user.lines; j++)
            {
                matrix[i][j] = 0;
            }
        }
    }

    // adds to uniqueID map, and checks to see if IDs gets incremented
    void createUniqueID()
    {
        // only used to loop through rather than having 2 if statements
        vector<string> urls {user.urlFrom, user.urlTo};

        // checks to make sure the "from" gets added to the map
        for (string temp : urls)
        {
            auto result = uniqueIDs.emplace(temp, uniqueID);

            // increments if emplace was successful
            if (result.second)
            {
                uniqueID++;
            }
        }
    }

    void add_edge(int& from, int& to)
    {
        matrix[from][to] = 1;
    }

    // inititally sets the power_iteration ranking matrix
    void setInitialRank()
    {
        for (int i = 0; i < uniqueIDs.size(); i++)
        {
            rankings.push_back(1.0 / uniqueIDs.size());
        }
    }

    // does dot product, or returns base case
    void calculateRank()
    {
        int iterations = user.powerIter - 1;

        if (iterations > 0)
        {
            while (iterations)
            {
                for (int j = 0; j < uniqueIDs.size(); j++)
                {
                    double scalarRowTotal = 0.0;

                    for (int i = 0; i < uniqueIDs.size(); i++)
                    {
                        scalarRowTotal += matrix[i][j] * rankings[i];
                    }

                    finalResult.push_back(scalarRowTotal);
                }

                rankings = finalResult;
                finalResult.clear();
                iterations--;
            }
        }

        else
        {
            finalResult = rankings;
        }
    }

    void printGraph()
    {
        auto it = uniqueIDs.begin();

        for (; it != uniqueIDs.end(); it++)
        {
            cout << it->first << " ";
            printf("%.2f", finalResult[uniqueIDs[it->first]]);
            cout << endl;
        }
    }

    // sets out degree for each row
    int count(int i)
    {
        int count = 0;

        for (int j = 0; j < uniqueIDs.size(); j++)
        {
            if (matrix[i][j] == 1)
            {
                count++;
            }
        }

        return count;
    }

    // sets matrix index to 1 / outdegree
    void setDegree(int i, int rowTotal)
    {
        for (int j = 0; j < uniqueIDs.size(); j++)
        {
            if (matrix[i][j] == 1)
            {
                matrix[i][j] = 1.0 / rowTotal;
            }
        }
    }

    // sets the 2d matrix with outDegree
    void setOutDegree()
    {
        for (int i = 0; i < uniqueIDs.size(); i++)
        {
            setDegree(i, count(i));
        }
    }

    // user input from first line
    void getNums()
    {
        getline(cin, user.numInput);
        user.numbers.str(user.numInput);
        user.numbers >> user.lines >> user.powerIter;
    }

    // user input from 2 to n lines
    void getURLs()
    {
        for (int i = user.lines; i > 0; i--)
        {
            getline(cin, user.urlInput);
            user.urls.str(user.urlInput);

            // push from ss to variables
            user.urls >> user.urlFrom >> user.urlTo;

            // add into map and add edge in matrix
            createUniqueID();
            add_edge(uniqueIDs[user.urlFrom], uniqueIDs[user.urlTo]);
            clearInput();
        }
    }

    // clears the objects
    void clearInput()
    {
        user.urlInput.clear();
        user.urls.clear();
        user.urlFrom.clear();
        user.urlTo.clear();
    }

    void createMatrix()
    {
        adjacencyMatrix();
    }

    void start()
    {
        getNums();
        createMatrix();
        getURLs();
        calculations();
    }

    void calculations()
    {
        setOutDegree();
        setInitialRank();
        calculateRank();
        printGraph();
    }
};

int main()
{
    Graph graph;
    graph.start();

    return 0;
}
