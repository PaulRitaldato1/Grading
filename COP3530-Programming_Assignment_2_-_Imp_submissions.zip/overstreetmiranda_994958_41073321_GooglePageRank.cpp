#include <cstdlib>
#include <iostream>
#include <string>
#include <vector>
#include <cstdio>

class url{
    public:
    std::string name;
    int outdegree;
    int indegree;
    url(){
        outdegree = 0;
        indegree = 0;

    }
};

class link{
    public:
    std::string outUrl;
    std::string inUrl;
    void print(){
        std::cout << outUrl << " " << inUrl << std::endl;
    }

};

int main(){
    
    //number of links that will be input
    int numLinks;
    //number of power iterations to be performed
    int numPow;
    
    
    
    //Get the necassary inputs
    std::cin >> numLinks;
    std::cin >> numPow;
    
    link links[numLinks];
    
    for(int i = 0; i < numLinks; i++){
        std::cin >> links[i].outUrl;
        std::cin >> links[i].inUrl;    
    }
    
    std::vector<url> urls;
    
    //Create vector of urls with unique id numbers
    int num = 0;
    for(int i = 0; i < numLinks; i++){
        std::string out = links[i].outUrl;
        std::string in = links[i].inUrl;
        bool outfound = false;
        bool infound = false;
        
        //Check through the vector so far to see if url is already in vector. If so update in/out degree of that url appropriately
        for(std::vector<url>::iterator it = urls.begin(); it != urls.end(); ++it){
            if(out.compare(it->name) == 0){
                it->outdegree = it->outdegree + 1;
                outfound = true;
            }
            if(in.compare(it->name) == 0){
                it->indegree = it->indegree + 1;
                infound = true;
            }
        }
        //If the first url is not found add it the vector with an out degree of 1
        if(!outfound){
            url* newurl = new url();
            newurl->name = out;
            newurl->outdegree = 1;
            urls.push_back(*newurl);
            num++;
        }

        //If the second url is not found add it the vector with an in degree of 1
        if(!infound){
            url* newurl = new url();
            newurl->name = in;
            newurl->indegree = 1;
            urls.push_back(*newurl);
            num++;
        }
    }

    //Alphabetize the urls
    for(int i = 0; i < num; i++){
        url smallest = urls[i];
        int exchange = i;
        for(int j = i; j < num; j++){
            if(urls[j].name.compare(smallest.name) < 0){
                smallest = urls[j];
                exchange = j;
            }
        }
        url temp = urls[i];
        urls[i] = smallest;
        urls[exchange] = temp;
    }

    //Create the adjacency matrix and intitialize all of its values to 0
    float adjMat[num][num];
    for(int i = 0; i < num; i++){
        for(int j = 0; j < num; j++){
            adjMat[i][j] = 0;
        }
    }
    
    //Create a new array to store the current rank or each url and initualize it to 1/V (V = number of urls)
    float curr[num];
    for(int i = 0; i < num; i++){
        curr[i] = 1/float(num);
    }
   
    //Put 1/outdegree of each url in the appropriate spot in adjacency matrix
    for(int i = 0; i < num; i++){ 
        std::string currUrl = urls[i].name; 
        float out = float(urls[i].outdegree);
        for(int j = 0; j < numLinks; j++){ 
            if(links[j].outUrl.compare(currUrl)==0){
                for(int k = 0; k < num; k++){
                    if(urls[k].name.compare(links[j].inUrl) == 0){
                        if(out > 0){
                            adjMat[k][i] = 1/out;
                        }
                    }
                }
            }
        }
    }

    //Initialize the answer array with the values of the current rank array
    float ans[num];
    for(int k = 0; k < num; k++){
        ans[k] = curr[k];
    }

    //Perform the necessary number of power iterations
    for(int n = 1; n < numPow; n++){
        for(int i = 0; i < num; i++){
            float answer = 0;
            for(int j = 0; j < num; j++){
                answer += adjMat[i][j] * curr[j];
            }
            ans[i] = answer;
        }
        for(int k = 0; k < num; k++){
            curr[k] = ans[k];
        }
    }
    
    //Print out the name of the url and its corresponding rank
    for(int i = 0; i < num; i++){
        std::cout << urls[i].name << " ";
        printf("%.2f", ans[i]);
        std::cout << std::endl;
    }
    return 0;
}

