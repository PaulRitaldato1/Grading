#include <iostream>
#include <vector>
#include <stdio.h>
#include <string.h>
#include <algorithm>
#include <iomanip>
using namespace std;

//int numUrls;
//double matrixMult(double row[numUrls], double power);

int main()
{
    string line;
    string input;
    vector <string> inUrls;
    vector <string> outUrls;
    vector <string> allUrls;

    //Get all input from the user
    while(getline(cin, line) && !line.empty())
    {
        input += line + "\n";
    }
    cout << input;

    //Find the number of inputs and the number of iterations
    int numInput = stoi(input.substr(0, input.find(" ")));
    input = input.substr(input.find(" "), input.size()-1);
    int numIterations = stoi(input.substr(0, input.find("\n")));
    input = input.substr(input.find("\n")+1, input.size()-1);

    //Make sure the user entered positive numbers
    if (numInput <= 0 || numIterations <= 0)
    {
        cout << "Error, cannot enter a number less than or equal to zero!" << endl;
        return 0;
    }

    //Separate the from and the to urls
    int pos;
    string toAndFrom;
    while(input.compare(""))
    {
        pos = input.find("\n");
        toAndFrom = input.substr(0, pos);

        inUrls.push_back(toAndFrom.substr(0,toAndFrom.find(" ")));
        outUrls.push_back(toAndFrom.substr(toAndFrom.find(" ") + 1, toAndFrom.size()-1));

        input = input.substr(pos + 1, input.size()-1);
    }

    //Debugging purposes
    /*cout << "In Urls" << endl;
    for (const auto &inUrl : inUrls)
    {
        cout << inUrl << " ";
    }
    cout << endl << endl;
    cout << "Out Urls" << endl;
    for (const auto &outUrl : outUrls)
    {
        cout << outUrl << " ";
    }
    cout << endl << endl;*/

    //Make a list of all the urls that were input
    for (int i = 0; i < numInput; i++)
    {
        if((find(allUrls.begin(), allUrls.end(), inUrls[i])) == allUrls.end())
        {
            allUrls.push_back(inUrls[i]);
        }
        if((find(allUrls.begin(), allUrls.end(), outUrls[i])) == allUrls.end())
        {
            allUrls.push_back(outUrls[i]);
        }
    }

    int numUrls = allUrls.size();

    //Debugging purposes
    /*cout << "All Urls" << endl;
    for (const auto &allUrl : allUrls)
    {
        cout << allUrl << " ";
    }
    cout << endl << endl;*/

    //Sort the urls in alphabetical order to obtain a unique ID
    sort(allUrls.begin(), allUrls.end());

    //Debugging purposes
    /*cout << "All Alphabetized Urls" << endl;
    for (const auto &allUrl : allUrls)
    {
        cout << allUrl << " ";
    }
    cout << endl << endl;*/

    //Find the outdegrees
    int outdegrees[numUrls];
    /*for (int i = 0; i < numUrls; i++)
    {
        outdegrees[i] = 0;
    }*/
    for (int i = 0; i < numUrls; ++i)
    {
        outdegrees[i] = count(inUrls.begin(), inUrls.end(), allUrls[i]);
    }

    //Debugging purposes
    /*cout << "Outdegrees" << endl;
    for (int i = 0; i < numUrls; i++)
    {
        cout << outdegrees[i] << " ";
    }
    cout << endl << endl;*/

    //Create the adjacency matrix
    double graph[numUrls][numUrls];
    //Initialize them all to zero
    for (int i = 0; i < numUrls; i++)
    {
        for (int j = 0; j < numUrls; j++)
        {
            graph[i][j] = 0;
        }
    }

    //Fill in the appropriate outdegrees
    int inID;
    int outID;
    int degree;
    for (int i = 0; i < numInput; i++)
    {
        inID = find(allUrls.begin(), allUrls.end(), inUrls[i]) - allUrls.begin();
        outID = find(allUrls.begin(), allUrls.end(), outUrls[i]) - allUrls.begin();
        degree = outdegrees[inID];
        graph[outID][inID] = 1.0 / degree;
    }

    //Debugging purposes
    /*cout << "Graph" << endl;
    for (int i = 0; i < numUrls; i++)
    {
        for (int j = 0; j < numUrls; j++)
        {
             cout << graph[i][j] << " ";
        }
        cout << endl;
    }
    cout << endl;*/

    //Compute one power iteration (aka 2)
    //Initialize the power matrix and the answer matrix
    float powerMatrix[numUrls];
    float answ[numUrls];

    for(int i = 0; i < numUrls; i++)
    {
        powerMatrix[i] = 1.0 / numUrls;
        answ[i] = 0;
    }

    float temp[numUrls];
    float product;
    //If the number of iterations are more than 1
    if (numIterations > 1)
    {
        for (int num = 0; num < numIterations-1; num++)
        {
            for (int i = 0; i < numUrls; i++)
            {
                product = 0;
                //Find the graph row we want to multiply by
                for (int j = 0; j < numUrls; j++)
                {
                    temp[j] = graph[i][j];
                }
                //Compute the matrix multiplication
                for (int j = 0; j < numUrls; j++)
                {
                    product += powerMatrix[j] * temp[j];
                }
                answ[i] = product;
            }
            //Store the result in the power matrix so we are able to compute more iterations if neccessary
            for (int i = 0; i < numUrls; i++)
            {
                powerMatrix[i] = answ[i];
            }
        }
    }
    //If the power iterations is 1
    else
    {
        for (int i = 0; i < numUrls; i++)
        {
            answ[i] = powerMatrix[i];
        }
    }

    //Debugging purposes
    /*cout << "Power Iteration" << endl;
    for (int i = 0; i < numUrls; i++)
    {
        cout << setprecision(2) << answ[i] << endl;
    }
    cout << endl;

    cout << "Final output" << endl;*/

    for (int i = 0; i < numUrls; i++)
    {
        //Print the url and its respective page rank
        cout << allUrls[i] << " " << fixed << setprecision(2) << answ[i] << endl;
    }
    return 0;
}
