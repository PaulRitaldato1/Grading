#include <iostream>
#include<string>
#include <math.h>
#include <vector>
#include <algorithm>
#include <iomanip>
using namespace std;        

class Page
{
	public:
		
		int count;
		string m[500];	
		vector<string> web;
		double map[500][500];
		double mult[500];
		double multE[500];
		void mapping(int repeat)
		{
			string first;
			string f;
			string s;
			string second;
			bool pres1;
			bool pres2;
			int space;
			int index1;
			int index2;
		    for(int i =0; i<repeat; i++)
			{
				cin>>first;
				cin>>second;
				pres1=false;
				pres2 = false;
				m[i]=first+" "+second;
				for(int s=0;s<web.size();s++)
				{
					if(web[s]==first)
						pres1=true;
					if(web[s]==second)
						pres2=true;
				}
				if(!pres1)
					web.push_back(first);
				
				if(!pres2)
					web.push_back(second);
			} 
			sort(web.begin(),web.end());
			
			for (int k=0;k<repeat;k++)
       		{
       			space = m[k].find(' ');
       			f=m[k].substr(0,space);
       			s=m[k].substr(space+1,m[k].size()-space);
       			for(int j = 0;j<web.size();j++)
       			{
       				if(web[j]==f)
						index1=j;
					if(web[j]==s)
						index2=j;
       			}
       			map[index2][index1]++;
       		}
       		
			for (int c=0;c<web.size();c++)
			{
				double out=0;
				for(int r=0;r<web.size();r++)
				{
					if(map[r][c]>0)
						out++;
				}
				for(int r=0;r<web.size();r++)
				{
					if(out>0)
						map[r][c]=map[r][c]/out;
				}
			}  
			
		}
		void power(int p)
		{	
			
			for(int k=0;k<web.size();k++)
			{
				mult[k]=1.0/(web.size()); 
			}
			for(int l=1;l<p;l++)
			{
				for(int k=0;k<web.size();k++)
                    multE[k]=mult[k];
				for(int r =0;r<web.size();r++)
				{
					mult[r]=0;
					for(int c=0;c<web.size();c++)
						mult[r]=mult[r]+(map[r][c]*multE[c]);
				}
					
			}
			 

		} 
		void print()
		{
			 cout.precision(2);
			 cout.setf(ios::fixed);
			for(int s=0;s<web.size();s++)
				cout<<web[s]<<" "<<mult[s]<<endl;
		} 

};
int main()
{
	int repeat;
	int degree;
	Page* trial = new Page;
	cin>>repeat;
	cin>>degree; 	
	trial->mapping(repeat);
	trial->power(degree);
	trial->print();
    return 0;
}