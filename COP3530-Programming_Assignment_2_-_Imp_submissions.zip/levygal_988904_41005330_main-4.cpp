#include <iostream>
#include <queue>
#include <math.h>
#include <iomanip>
using namespace std;
//method that iterates through the identity array to get the ID for the given URL, if not in it then returns -1
int getID(string* identity,string address,int size){
    int count=0;
    while(count!=size){
        if(identity[count]==address)
            return count;
        count++;
    }
    return -1;
}
//method that does matrix multiplication for n by n times n by 1 and returns the resulting answer
double* matrixMultiply(double **matrix,double *matrixIter,int size){
    double *matrixAnswer=new double[size];
    for(int i=0;i<size;i++){
        double sum=0;
        for(int j=0;j<size;j++){
            sum+=(matrix[i][j]*matrixIter[j]);
        }
        matrixAnswer[i]=sum;
    }
    return matrixAnswer;
}
//prints the URLs and their pageRank in alphabetical order using a bubble sort
void printRankAlpha(string* identity,double *matrixIter,int size){
    for(int i=0;i<size-1;i++){
        for(int j=0;j<size-1;j++){
            if(identity[j]>identity[j+1]){
                string temp=identity[j];
                identity[j]=identity[j+1];
                identity[j+1]=temp;
                double temp2=matrixIter[j];
                matrixIter[j]=matrixIter[j+1];
                matrixIter[j+1]=temp2;
            }
        }
    }
    cout<<setprecision(2)<<fixed;
    for(int i=0;i<size;i++){
        cout<<identity[i]<<" "<<matrixIter[i]<<endl;
    }
}
int main() {
    int numLines;
    int numIter;
    cin>>numLines;
    cin>>numIter;
    //makes sure that input for number of lines is a positive number
    if(numLines<0){
        return 0;
    }
    //I defined the arrays to numLines*2 since that is the greatest number of unique URLs that can be input in numLines
    string *identity=new string[numLines*2];
    double** matrix=new double*[numLines*2];
    for(int i=0;i<(numLines*2);i++){
        matrix[i]=new double[numLines*2];
        for(int j=0;j<numLines*2;j++){
            matrix[i][j]=0;
        }
    }
    string from;
    string to;
    //size keeps track of how many unique URLs there are
    int size=0;
    //for loop takes in input and adjusts the adjacency matrix accordingly
    for(int i=0;i<numLines;i++){
        cin>>from;
        cin>>to;
        if(getID(identity,from,size)==-1){
            identity[size]=from;
            size++;
        }
        if(getID(identity,to,size)==-1){
            identity[size]=to;
            size++;
        }
        int out=getID(identity,from,size);
        int in=getID(identity, to,size);
        matrix[in][out]=1;
    }
    //for loop divides column entries by total number of vertices so that the weights add up to 1
    for(int j=0;j<size;j++){
        int count=0;
        for(int i=0;i<size;i++){
            if(matrix[i][j]==1)
                count++;
        }
        if(count>1){
            for (int i = 0; i < size; i++) {
                matrix[i][j] /= count;
            }
        }
    }
    double *matrixIter=new double[size];
    //first matrix has all entries equally divided
    for(int i=0;i<size;i++){
        matrixIter[i]=1.0/size;
    }
    //multiplies for every additional iteration
    for(int i=1;i<numIter;i++){
        matrixIter=matrixMultiply(matrix,matrixIter,size);
    }
    //rounds and sets the decimal places to 2 for each entry
    for(int i=0;i<size;i++){
        matrixIter[i]=roundf(matrixIter[i]*100)/100;
    }
    //prints the final URLs and pageRanks in alphabetical order
    printRankAlpha(identity,matrixIter,size);
    return 0;
}