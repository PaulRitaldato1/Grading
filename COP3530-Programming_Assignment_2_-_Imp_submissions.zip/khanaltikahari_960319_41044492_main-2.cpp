//main.cpp
#include <string>
#include <iostream>
#include <vector>

class Node{
public:
    std::string name;
    int in_degree;
    int out_degree;
    int mapped_position;
    Node(){
        name="";
        in_degree=0;
        out_degree=0;
        mapped_position=-1;
    }
    Node(std::string name, int mapped_position, Node* next){
        this->name= name;
        this->mapped_position=mapped_position;
        in_degree=0;
        out_degree=0;
    }
    Node(std::string name, int mapped_position, int in_degree, int out_degree){
        this->name= name;
        this->mapped_position=mapped_position;
        this->in_degree=in_degree;
        this->out_degree=out_degree;
    }
};

int findURL(std::vector<std::vector<Node>> urls, std::string name){
    for(int i =0;i < urls.size(); i++){
        if(urls[i][0].name == name)
            return i;
    }
    return -1;
}

void print(double* fin, double pos, std::vector<std::vector<Node>> urls){
    //bubble sort urls into ascending alphabetical order
    for(int i =0; i < pos -1; i++){
        for(int j = 0; j < pos-1-i; j++){
            //2 arrays swapped
            if(urls[j][0].name > urls[j+1][0].name){
                double temp = fin[j];
                fin[j]=fin[j+1];
                fin[j+1]=temp;
                std::vector<Node> tmp = urls[j];
                urls[j] = urls[j+1];
                urls[j+1]= tmp;
            }
        }
    }
    for(int i = 0; i < pos; i++){
        printf("%s %.2f\n", urls[i][0].name.c_str(), fin[i]);
    }
}

double* multiply(double** adj, double pos, int iterations){
    double* mult= new double[(int)pos];
    double* fin = new double[(int)pos];
    for( int i =0; i < pos; i++){
        mult[i]=(double)(1/pos);
    }
    if(iterations == 1)
        return mult;
    for(int k = 0; k < iterations-1; k ++){
        fin = new double[(int)pos];
        //initialize answer vector
        for(int a=0; a< pos; a++){
            fin[a]=0;
        }
        for(int i = 0; i< pos; i++){
            for(int j = 0; j < pos; j++){
                fin[i]+=(double)(adj[i][j]*mult[j]);
            }
        }
        mult = fin;
        
    }
    return fin;
}

int main(int argc, const char * argv[]) {
    //2d vector stores urls in "table"
    //holds in_degree, out_degree, value mapped to, and names of vertices (and whether they are pointing to or from the url)
    std::vector<std::vector<Node>> urls = *new std::vector<std::vector<Node>>;
    std::string input;
    std::string lines;
    std::string iterations;
    Node* temp;
    std::cin>>lines;
    std::cin>>iterations;
    int num_lines = atoi(lines.c_str());
    int num_iterations = atoi(iterations.c_str());
    //input verification
    if(lines == "" || iterations == "" || num_lines<=0||num_iterations<=0)
        exit(0);
    double pos = 0;
    int prev = 0;
    //take inputs and add urls to 2d vector accordingly
    for(int i = 0;i< num_lines*2; i++){
        std::cin>>input;
        //node to be added to vector
        int index = findURL(urls, input);
        //url did not exist
        if(index == -1){
            //modulate in_degree/out_degree accordingly
            if(i%2==0){
                temp = new Node(input, pos, 0,1);
            }
            else{
                temp = new Node(input, pos, 1,0);
            }
            urls.push_back(*new std::vector<Node>);
            urls[pos].push_back(*temp);
            pos++;
            if(temp->in_degree == 1){
                urls[prev].push_back(*temp);
            }
        }
        //if url has already been added to data structure, increment in_degree/out_degree if necessary
        else if(index != -1){
            if(i% 2 !=0){
                urls[index][0].in_degree = urls[index][0].in_degree+1;
                urls[prev].push_back(*new Node(input, index,-2,-2));
            }
            else{
                urls[index][0].out_degree= urls[index][0].out_degree+1;
            }
        }
        //to add element to second dimension of vector
        prev = findURL(urls, input);
    }
    //initialize adjacency matrix
    double** adj = new double*[(int)pos];
    for(int i = 0;i< pos; i++){
        adj[i]= new double[(int)pos];
        //initialize matrix to 0
        for(int k =0; k < pos; k++){
            adj[i][k]=0;
        }
    }
    for(int i = 0; i< pos; i++){
        double out=urls[i][0].out_degree;
        out=1/out;
        for(int j =0; j < pos; j++){
            if(j<= urls[i].size()-1 && urls[i][j].name != "" &&  j!= 0){
                adj[urls[i][j].mapped_position][i]=out;
            }
        }
    }
    double* output = multiply(adj, pos, num_iterations);
    print(output, pos, urls);
    return 0;
}
