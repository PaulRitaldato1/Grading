#ifndef WEBPAGE_HEADER_H
#define WEBPAGE_HEADER_H
#include <iostream>
#include <vector>


class Webpage
{
  private:
    unsigned int outDeg;
    unsigned int inDeg;
    std::string url;
    std::vector<Webpage* >* ptsTo;
    int index;
    double pageRank;

  public:
    //constructors
    Webpage();
    Webpage(std::string name);
    Webpage(std::string name, bool in, Webpage *outTo, int inx);

    //out degree
    void incrementOut();
    unsigned int getOut();

    //in degree
    void incrementIn();
    unsigned int getIn();

    //url
    void editURL(std::string name);
    std::string getURL();

    //pageRank
    double getPageRank();
    void setPageRank(double rank);

    //ptsTo
    std::vector<Webpage* >* getPtsTo();
    void printPtsTo();
    void link(Webpage* ptsTo);

    //index
    int getIndex();


};
#endif
