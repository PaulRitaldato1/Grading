#include <iostream>
#include <cstring>
#include <map>
#include <iomanip>
using namespace std;

class MatrixGraph
{
private:
    const static int MAXNUMVERTICES = 100;
    double theGraph[MAXNUMVERTICES][MAXNUMVERTICES];
    int numVertices;
    map<string,int> vertexConverter;
public:
    MatrixGraph()
    {
        numVertices = 0;
    };
    
    bool is_vertex(string name)
    {
        auto it = vertexConverter.find(name);
        return (it != vertexConverter.end() ? true : false);
    };
    
    bool insert_vertex(string name)
    {
        auto it = vertexConverter.insert(pair<string,int>(name,numVertices++));
        return it.second;
    };
    
    int find_vertex(string name)
    {
        auto it = vertexConverter.find(name);
        return it->second;
    };
    
    bool is_edge(string from, string to)
    {
        if (!is_vertex(from)) return false;
        if (!is_vertex(to)) return false;
        int iFrom = find_vertex(from);
        int iTo = find_vertex(to);
        if (theGraph[iFrom][iTo] == 0)
        {
            return false;
        }
        else
        {
            return true;
        };
    };
    
    bool insert_edge(string from, string to)
    {
        if (!is_vertex(from)) insert_vertex(from);
        if (!is_vertex(to)) insert_vertex(to);
        int iFrom = find_vertex(from);
        int iTo = find_vertex(to);
        theGraph[iTo][iFrom] = 1;
        return true;
    };
    
    void weight_graph()
    {
        for (int i = 0; i < numVertices; i++)
        {
            int outDegree = 0;
            for (int j = 0; j < numVertices; j++)
            {
                if (theGraph[j][i] != 0) outDegree++;
            };
            if (outDegree > 0)
            {
                for (int j = 0; j < numVertices; j++)
                {
                    theGraph[j][i] /= outDegree;
                };            
            };
        };
    };
    
    void print_graph()
    {
        for (int i = 0; i < numVertices; i++)
        {
            for (int j = 0; j < numVertices; j++)
            {
                cout << theGraph[i][j] << ' ';
            };
            cout << '\n';
        };
    };
    
    double* power_iterations(int n)
    {
        double *rOld = (double *) malloc(numVertices * sizeof(double));
        for (int i = 0; i < numVertices; i++)
        {
            rOld[i] = 1.00/numVertices;
        };
        
        double rNew[numVertices];
        for (n -= 1; n > 0; n--)
        {
            for (int i = 0; i < numVertices; i++)
            {
                double result = 0;
                for (int j = 0; j < numVertices; j++)
                {
                    result += (theGraph[i][j] * rOld[j]);
                };
                rNew[i] = result;
            };

            for (int i = 0; i < numVertices; i++)
            {
                rOld[i] = rNew[i];
            };
        };
        return rOld;
    };
    
    void print_weights(double* weights)
    {
        for (auto it = vertexConverter.begin(); it != vertexConverter.end(); it++)
        {
            cout << it->first;
            int i = find_vertex(it->first);
            cout << ' ' << fixed << setprecision(2) << weights[i] << '\n';
        };
    };
};

int main()
{
    MatrixGraph myGraph;
    int numEdges;
    int numPower;
    string from, to;
    cin >> numEdges;
    cin >> numPower;
    for (; numEdges > 0; numEdges--)
    {
        cin >> from;
        cin >> to;
        myGraph.insert_edge(from,to);
    };
    myGraph.weight_graph();
    double* result = myGraph.power_iterations(numPower);
    myGraph.print_weights(result);   
    
    return 0;
}