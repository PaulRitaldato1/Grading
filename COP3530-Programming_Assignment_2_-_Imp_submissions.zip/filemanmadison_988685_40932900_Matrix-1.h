#ifndef MATRIX_HEADER_H
#define MATRIX_HEADER_H
#include "Webpage.h"
#include <vector>
#include <map>


template<typename K, typename V> class Matrix;
template<>
class Matrix<std::string,std::string>: public std::multimap<std::string,std::string> {


  private:
    double** adjMatrix;
    std::vector<Webpage*> directory;
   public:
     Matrix(int maxSz);
     void insertPair(std::string ptr, std::string ptsTo);

    //matrix
     void sMatrix();
     void printMatrix();

     //rows/cols
     double* mult(int numTimes);

     //DIRECTORY
     std::vector<Webpage*> getDirectory();
     void printDirectory(); //goes thru array and prints each website url
     Webpage* addToDirectory(Webpage *insert);
     void printPageRanks();
     void sortDirByName();

};


#endif
