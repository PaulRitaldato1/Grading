/*
 * Mia Friedberg
 * Programming Assignment 2 - Implement Google's Page Rank
 * 30 Nov 18
 * Section 1087/12128
 */
#include <iostream>
#include <cstdlib>
#include <string>
using namespace std;
#define MAX 999

#ifndef PAGERANK_ADJACENCYMATRIX_H
#define PAGERANK_ADJACENCYMATRIX_H

class AdjacencyMatrix {
private:
    int n;
    float **adj;
    bool *visited;
    int outDegree = 0;
public:
    AdjacencyMatrix(int n);
    void insertEdge(int from, int to);
    void insertWeightedEdge(int from, int to, float oneOverOutDegree);
    float * multMatrix(float ** squareMatrix, float * colMatrix, int size);
    int getOutDegree(int from);
    float getOneOverOutDegree(int outDegree);
    void printMatrix();
    float ** returnSquareMatrix();
};

#endif //PAGERANK_ADJACENCYMATRIX_H
