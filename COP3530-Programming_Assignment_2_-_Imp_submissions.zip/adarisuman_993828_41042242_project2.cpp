#include <iostream>
#include <cstring>
#include <vector>
#include <cstdlib>
#include <algorithm>
#include <iomanip>

using namespace std;

//List of vertices (unique) in alphabetical order. Their index is their number. DONE ////////////////////////////////////////////////////////////
//A list of outdegrees, index corresponds to each vertex. (This can be done by summing columns of adjacency matrix) DONE ////////////////////////
//Adjacency matrix is made DONE /////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Pagerank matrix is calculated from adjacency matrix. DONE /////////////////////////////////////////////////////////////////////////////////////

//Now do the power iteration DONE ///////////////////////////////////////////////////////////////////////////////////////////////////////////////


//Splits the input string by the delimiter that is passed.
std::vector<std::string> splitBy(std::string a, std::string delimiter)
{

    //Splits everything according to the delimiter " " and adds it to the vector
    std::vector<std::string> words;
    unsigned int j = 0;
    for(unsigned int i = 0; i < a.size(); i++)
    {
        //If there is a delimiter it adds the substring up until but not including the " "
        if(a.substr(i, 1) == delimiter)
        {
            std::string word = a.substr(j, i-j);
            j = i+1;
            words.push_back(word);

        }

        //If i is at the end of the string then it just adds the rest of the word
        if(i == a.size()-1)
        {
            std::string word = a.substr(j, i-j+1);
            words.push_back(word);

        }

    }

    return words;

}

//Generates a string vector of the unique vertices, sorted alphabetically.
std::vector<std::string> uniqueVertices(std::vector<std::string> list)
{


    std::vector<std::string> vertices;

    //Goes through the user entries, splits them by " ", and adds it to the list of vertices if not already present.
    for(int i = 0; i < list.size(); i++)
    {
        std::vector<std::string> sites = splitBy(list.at(i), " ");
        std::string site1 = sites.at(0);
        std::string site2 = sites.at(1);

        bool found = false;
        for(int i = 0; i < vertices.size(); i++)
        {
            if(vertices.at(i) == site1)
                found = true;
            if(found)
                break;

        }
        if(!found)
            vertices.push_back(site1);

        found = false;
        for(int i = 0; i < vertices.size(); i++)
        {
            if(vertices.at(i) == site2)
                found = true;
            if(found)
                break;

        }
        if(!found)
            vertices.push_back(site2);


    }

    //Does bubble sort to sort out the vertex names alphabetically
    for (int i = 0; i < vertices.size()-1; i++)
    {
        for (int j = 0; j < vertices.size() - i - 1; j++)
        {
            if (vertices.at(j) > vertices.at(j+1))
            {
                std::string temp = vertices.at(j);
                vertices.at(j) = vertices.at(j+1);
                vertices.at(j+1) = temp;
            }

        }
    }

    return vertices;

}


//Finds the out degrees of each vertex alphabetically, given the adjacency matrix and the number of vertices.
std::vector<int> vertexOutdegrees(int ** adjMat, int numVer)
{

    int sum = 0;

    std::vector<int> outDegrees;

    //Sums the columns so to get the outdegree number.
    for(int i = 0; i < numVer; i++)
    {
        sum = 0;
        for(int j =0; j < numVer; j++)
            sum += adjMat[j][i];


        outDegrees.push_back(sum);
    }

    return outDegrees;

}



//Finds and returns the index, if not found returns -1.
int findIndex(std::vector<std::string> vertices, std::string whatToFind)
{

    for(int i = 0; i < vertices.size(); i++)
        if(vertices.at(i) == whatToFind)
            return i;

    return -1;

}

//Creates the adjacency matrix given list of unique vertices and the list of user entries.
int ** createAdjMat(std::vector<std::string> vertices, std::vector<std::string> entrees)
{

    int numVer = vertices.size();

    //Initialize the empty adj matrix (2d int array).
    int** adjMat = new int*[numVer];
    for(int i = 0; i < numVer; ++i)
        adjMat[i] = new int[numVer];

    for(int i = 0; i < numVer; i++)
        for(int j = 0; j < numVer; j++)
            adjMat[i][j] = 0;


    //Finds the websites, splits them and adds them to the adj matrix.
    for(int i = 0; i < entrees.size(); i++)
    {
        std::vector<std::string> sites = splitBy(entrees.at(i), " ");
        std::string site1 = sites.at(0);
        std::string site2 = sites.at(1);

        int indSite1 = findIndex(vertices, site1);
        int indSite2 = findIndex(vertices, site2);

        adjMat[indSite2][indSite1] = 1;

    }

    return adjMat;
}

//Creates the page rank from the adjacency matrix, given the out degrees.
double ** createPageRank(int ** adjMat, std::vector<int> outDegrees)
{

    int numVer = outDegrees.size();

    //Initialize a 2d double array.
    double** pageRank = new double*[numVer];
    for(int i = 0; i < numVer; ++i)
        pageRank[i] = new double[numVer];

    for(int i = 0; i < numVer; i++)
        for(int j = 0; j < numVer; j++)
            pageRank[i][j] = 0;


    //Where it calculates the pagerank.
    for(int i = 0; i < numVer; i++)
        for(int j = 0; j < numVer; j++)
        {
            //If there's outdegrees it does this
            if (outDegrees.at(i) != 0)
                pageRank[j][i] = adjMat[j][i] * (1 / ((double) (outDegrees.at(i))));
            //otherwise it should just be a 0.
            else
                pageRank[j][i] = 0;
        }

    return pageRank;

}

//This is where it does the power iterations. It does it recursively because I first thought of it that way and it seemed interesting.
std::vector<double> doPowerIteration(double ** pageRank, std::vector<double> multiplier, int numVer, int numIter)
{

    //Recursive break condition.
    if(numIter == 1)
        return multiplier;

    std::vector<double> newMultiplier;

    double sum = 0;

    //Matrix vector multiplication algorithm. Cycles through the row entries of pagerank, multiplies with col entries of the multiplier vector and the sum is the entry of the new multiplier (page rank vector).
    for(int i = 0; i < numVer; i++)
    {
        sum = 0;
        for(int j = 0; j < numVer; j++)
        {
            sum += pageRank[i][j] * multiplier.at(j);
            //std::cout<<pageRank[i][j]<<" ";
        }
        //std::cout<<std::endl;
        newMultiplier.push_back(sum);

    }
    //std::cout<<std::endl;
    numIter -= 1;

    //Recursively calls itself if there's multiple power iterations.
    return doPowerIteration(pageRank, newMultiplier, numVer, numIter);

}

//The main function. It's VERYYYYYYYYYYYYY important.
int main()
{
    //firstTwo is supposed to be the string that gets the number of entries and the number of power iterations.
    std::string firstTwo = "";

    std::getline(std::cin, firstTwo);

    //Splits them by space.
    std::vector<std::string> values = splitBy(firstTwo, " ");

    int numEntries = std::stoi(values.at(0));

    int numMul = std::stoi(values.at(1));

    //std::cout<<"success "<<numEntries<<" "<<numMul<<std::endl;

    //Supposed to be the string vector of our graph entries.
    std::vector<std::string> entrees;

    std::string entry = "";
    for(int i = 0; i < numEntries; i++)
    {
        entry = "";
        std::getline(std::cin, entry);
        entrees.push_back(entry);

    }

    //This is a string vector of the unique vertices, sorted alphabetically.
    std::vector<std::string> vertices = uniqueVertices(entrees);

    /*
    for(int i = 0; i < vertices.size(); i++)
        std::cout<<" "<<vertices.at(i)<<std::endl;
    */

    //This is the adjacency matrix.
    int**adjMat = createAdjMat(vertices, entrees);

    /*
    std::cout<<std::endl;
    for(int i = 0; i < vertices.size(); i++)
    {
        for (int j = 0; j < vertices.size(); j++)
            std::cout << adjMat[i][j] << " ";
        std::cout<<std::endl;
    }
    */

    //This is the integer vector of the outdegrees of each vertex. Index in the vector corresponds directly to the alphabetically sorted vertex vector.
    std::vector<int> outDegrees = vertexOutdegrees(adjMat, vertices.size());

    /*
    std::cout<<"Vertex Out degrees"<<std::endl;
    for(int i = 0; i<vertices.size(); i++)
        std::cout<<vertices.at(i)<< ": "<<outDegrees.at(i)<<std::endl;
    */

    //This is the pagerank matrix
    double**pageRank = createPageRank(adjMat, outDegrees);

    /*
    std::cout<<std::endl;
    for(int i = 0; i < vertices.size(); i++)
    {
        for (int j = 0; j < vertices.size(); j++)
            std::cout << pageRank[i][j] << " ";
        std::cout<<std::endl;
    }
    */


    std::vector<double> multiplier;

    for(int i = 0; i < vertices.size(); i++)
        multiplier.push_back(1 / ( (double)vertices.size()));

    //pageRankIter is supposed to be the vector of page ranks after the power iterations.
    std::vector<double> pageRankIter = doPowerIteration(pageRank, multiplier, vertices.size(), numMul);


   // std::cout<<"Page ranks: "<<std::endl;

    //This is how it outputs the pageranks.
    for(int i = 0; i < pageRankIter.size(); i++)
        std::cout<<vertices.at(i)<<" "<<std::fixed<<std::setprecision(2)<<pageRankIter.at(i)<<std::endl;


    return 0;

}

/*

 7 2
 google.com gmail.com
 google.com maps.com
 facebook.com ufl.edu
 ufl.edu google.com
 ufl.edu gmail.com
 maps.com facebook.com
 gmail.com maps.com


 */

/*
 *
 *
 *
 *
 * std::fixed and std::setprecision
 * std::cout<<std::fixed<<setd::setprecision(2)<<
 */