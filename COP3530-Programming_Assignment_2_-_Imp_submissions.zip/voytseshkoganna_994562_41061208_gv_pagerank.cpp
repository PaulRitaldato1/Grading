#include <iostream>
#include <vector>
#include <map>
#include <list>
#include <algorithm>
#include <sstream>
#include <iomanip>
#include <utility> //for pair

class PageRank
{
private:
    std::vector<std::vector<int>> adjList;
    std::vector<int> adjSizes;
    std::vector<int> powers;
    std::map<std::string, int> names; //used to map strings to indices
    std::vector<std::string> sortedNames; //used for printing

public:
    PageRank();
    std::pair<std::string, std::string> getEdge(); //gets input from user and returns a pair of vertices (from, to)
    void insert(std::string vertex); //inserts given vertex (if not already there) into names and sortedNames
    void setAdjList(int size); //inserts vertices into adjList and adjSizes
    void iterate(int powerIterations); //iterates for the given number of powerIterations
    void printPowers(std::vector<double> powerList); //prints final result
};

PageRank::PageRank()
{
}

std::pair<std::string, std::string> PageRank::getEdge()
{
    int spaceLoc = 0;
    std::string line = "";
    std::pair<std::string, std::string> edge;

    std::getline(std::cin, line);

    spaceLoc = line.find(" ");

    edge.first = line.substr(0, spaceLoc);
    edge.second = line.substr(spaceLoc + 1);

    return edge;
}

void PageRank::insert(std::string vertex)
{
    if (names.find(vertex) == names.end())
    {
        names.insert(std::pair<std::string, int> (vertex, names.size()));
        sortedNames.push_back(vertex);
    }
}

void PageRank::setAdjList(int size)
{
    std::pair<std::string, std::string> edge;

    adjList.resize(size);
    std::vector<int> init (0,0);
    for (int i = 0; i < size; i++)
    {
        adjList[i] = init;
    }
    adjSizes.resize(size);

    for (int i = 0; i < size; i++)
    {
        edge = getEdge();

        insert(edge.first);
        insert(edge.second);

        adjList.at(names.at(edge.second)).push_back(names.at(edge.first));
        adjSizes.at(names.at(edge.first))++;
    }
}

void PageRank::iterate(int powerIterations)
{
    std::vector<double> powerList (adjList.size(), 1.0 / names.size());
    std::vector<double> powerTemp (adjList.size(), 0.0);

    double temp = 0.0;

    for (int k = 1; k < powerIterations; k++)
    {
        for (int i = 0; i < adjList.size(); i++)
        {
            for (int j = 0; j < adjList[i].size(); j++)
            {
                temp += (powerList[adjList[i][j]] / adjSizes[adjList[i][j]]);
            }
            powerTemp[i] = temp;
            temp = 0.0;
        }
        powerList = powerTemp;
    }
    printPowers(powerList);
}

void PageRank::printPowers(std::vector<double> powerList)
{
    std::sort (sortedNames.begin(), sortedNames.end());
    std::cout << std::fixed;
    std::cout << std::setprecision(2);
    for (int i = 0; i < sortedNames.size(); i++)
    {
        std::cout << sortedNames[i] << " " << powerList[names.at(sortedNames[i])] << std::endl;
    }
}

int main()
{
    PageRank p;
    int size = 0;
    int powerIterations = 0;
    std::string line = "";

    std::getline (std::cin, line);
    std::stringstream(line.substr(0, line.find(" "))) >> size;
    std::stringstream(line.substr(line.find(" ") + 1)) >> powerIterations;

    p.setAdjList(size);
    p.iterate(powerIterations);
    return 0;
}
