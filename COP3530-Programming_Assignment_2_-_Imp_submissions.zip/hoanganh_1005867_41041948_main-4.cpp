#include <iostream>
#include<string>
#include <vector>
//#include <multimap>
#include <map>
#include <iomanip>
using namespace std;


struct Vertex
{
    int ID;
    double rankScore;
    vector<int> fromList;
    double powerTo;
};

void SortList(vector<string> & vertexList)
{
    for (int i = 0; i < vertexList.size(); i++)
    {
        for (int j = 0; j < vertexList.size() - i - 1; j ++)
        {
            if (vertexList[j] > vertexList[j+1])
            {
                string temp = vertexList[j];
                vertexList[j] = vertexList[j+ 1];
                vertexList[j + 1] = temp;
            }
        }
    }
}

bool find(int num, vector<int> input)
{
    for (unsigned int i = 0; i < input.size(); i++)
    {
        if (num == input[i]) return true;
    }
    return false;
}

vector<double> multiplyMatrix(vector<vector<double>> A, vector<double> B)
{
    vector<double> result;

    for (int i =0; i < A.size(); i++)
    {
        double temp = 0;
        for (int j = 0; j < B.size(); j++)
        {
            temp += A[i][j] * B[j];
        }
        result.push_back(temp);
    }
    return result;
}

class Graph
{
public:

    void insertVertex(Vertex &v)
    {
        vertexList.push_back(v);
    }

    void setMatrix()
    {
        int num = vertexList.size();
        const int n = num;
        double matrix[n][n];
//        cout<<"Matrix that we have:"<<endl;
        for (int i =0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                matrix[i][j] = 0;
                if (find(j + 1, vertexList[i].fromList))
                {
                    matrix[i][j] = vertexList[j].powerTo;
                }
//                cout<< matrix[i][j]<<" ";
            }
//            cout<<endl;
        }

        for (int i =0; i < vertexList.size(); i++)
        {
            vector<double> temp;
            for (int j = 0 ; j < vertexList.size(); j++)
            {
                temp.push_back(matrix[i][j]);
            }
            vertexMatrix.push_back(temp);
        }
    }

    void RunPowerIteration(int pow)
    {
        vector<double> answer;
        for (int i = 0; i < vertexMatrix.size(); i++)
        {
            answer.push_back(vertexList[i].rankScore);
        }
        //run loop finding the rankscore
        for (int i = 0; i < pow; i++)
        {
            answer = multiplyMatrix(vertexMatrix, answer);
        }
        for (int i = 0; i < vertexMatrix.size(); i++)
        {
            vertexList[i].rankScore = answer[i];
        }
    }

    vector<Vertex> getVertexList()
    {
        return this->vertexList;
    }

private:
    vector<Vertex> vertexList;
    vector<vector<double>> vertexMatrix;
};


void AddArray(string input, vector<string> & array)
{
    for (unsigned int i = 0; i < array.size();i ++)
    {
        if (array[i] == input) return;
    }
    array.push_back(input);
}

int main()
{

    Graph myGraph;
    string line;
    int powIter;
    getline(cin, line);
    int numEle = stoi(line.substr(0, line.find_first_of(" ")));
    powIter = stoi(line.substr(line.find_first_of(" ") + 1));
    vector<string> vertexList;
    multimap<string, string> mapFromTo;
    int count = 0;
    while (count < numEle)
    {
        count++;
        getline(cin, line);
        string from = line.substr(0, line.find_first_of(" "));
        line = line.substr(line.find_first_of(" ") + 1);
        string to = line;
        mapFromTo.emplace(from, to);
        AddArray(from, vertexList);
        AddArray(to, vertexList);
    }

    SortList(vertexList);

    multimap<string, int> mapNameID;
    //each vertex have an ID, don't need to care about the vertex name;
    for (int i = 0; i < vertexList.size(); i++)
    {
        mapNameID.emplace(vertexList[i], i+1);
    }

    for (int i = 0; i < vertexList.size(); i++)
    {
        vector<string> fromList;
        for (auto j = mapFromTo.begin(); j != mapFromTo.end(); j++)
        {
            if (j->second == vertexList[i])
            {
                for (unsigned int k = 0; k < fromList.size(); k++) //make sure that the from has not been in vector yet
                {
                    if (j->first == fromList[k])
                        continue;
                }
                fromList.push_back(j->first);
            }
        }
        int toNum = 0;
        for (auto j = mapFromTo.begin(); j != mapFromTo.end(); j++)
        {
            if (j->first == vertexList[i])
            {
                toNum++;
            }
        }

        Vertex temp;
        double initPow = 1.00/ vertexList.size();
        temp.ID = i+1;
        temp.rankScore = initPow;
        temp.powerTo = 1.00/ toNum;
        for (unsigned int q = 0 ; q < fromList.size();q++)
        {
            for (auto l = mapNameID.begin(); l != mapNameID.end(); l++)
            {
                if (l->first == fromList[q])
                {
                    temp.fromList.push_back(l->second);
                }
            }
        }
        myGraph.insertVertex(temp);
    }

    myGraph.setMatrix();
    myGraph.RunPowerIteration(powIter - 1);

    //print result;

    for (int i = 0; i < myGraph.getVertexList().size(); i++)
    {
        for (auto j = mapNameID.begin(); j != mapNameID.end(); j++)
        {
            if (j->second == myGraph.getVertexList()[i].ID)
            {
                cout<<vertexList[i]<< " "<<fixed<<setprecision(2)<<myGraph.getVertexList()[i].rankScore<<endl;
            }
        }
    }

    return 0;
}