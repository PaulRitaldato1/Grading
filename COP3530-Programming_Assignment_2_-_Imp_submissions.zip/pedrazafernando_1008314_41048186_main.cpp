#include <iostream>
using  namespace std;
#include <string.h>
#include <set>
#include <map>
#include <stdio.h>
#include <iomanip>
#include <sstream>
#include <algorithm>

//Global varibles
string fromGlob[13500];
string toGlob[13500];
int indexGlob=0;
int repsGlob[13500];
string noRepArr[13500];
int indivTosInde[13500];
int globReps=0;
double matrixGlob[13500][13500];
int extraInd=0;
int exInd;
string extra[13500];
double mult[13500][1];
double multo[13500][1];

//------------------------------------------------------------------------------------------------------------------------------
//Determines how many times each website repeats

int Repeat(string page , int lines){
    int count=0;
    for (int i = 0; i < lines; ++i) {
        if(page==fromGlob[i]){
            count++;
            fromGlob[i]="";
        }
    }
    return count;
}
//------------------------------------------------------------------------------------------------------------------------------
//Checks if something points no nothing
int che(int lines){
    int count=0;
    int ret=0;
    for (int j = 0; j < lines; ++j) {
        if(toGlob[extraInd]==fromGlob[j]){
            count++;
        }
    }

    if (count==0){
        for (int i = 0; i <exInd ; ++i) {
            if(toGlob[extraInd]==extra[i])
                count++;
        }
    }

    if(count==0){
        extra[exInd]=toGlob[extraInd];
        exInd++;
        ret++;
    }

    extraInd++;
    return ret;
}
//------------------------------------------------------------------------------------------------------------------------------
//Assambles the matrix
void getInfMat(int reps, int total){
    int count=0;
    int ai=globReps;
    for (int i = ai; i < ai+(reps); ++i) {
        for (int j = 0; j < total; ++j) {
            if(toGlob[i]==noRepArr[j]){
                indivTosInde[count]=j;
                count++;
            }
        }
    }
    globReps+=reps;
}
//------------------------------------------------------------------------------------------------------------------------------
//Fills matrix
void fillMatrix(int jIndex, int tos[], int reps ) {

    for (int i = 0; i < reps; ++i) {
        matrixGlob[tos[i]][jIndex]=(1.f/reps);
        indivTosInde[i]=0;
    }
};

//------------------------------------------------------------------------------------------------------------------------------
//Matrix multiplicator
void multi2(int total){

    for(int i = 0; i < total; ++i)
    {
        for(int j = 0; j < 1; ++j)
        {
            for(int k=0; k <total; ++k)
            {
                mult[i][j] += matrixGlob[i][k] * multo[k][j];
            }
        }
    }
}

//------------------------------------------------------------------------------------------------------------------------------
//Main takes inputs into arrays, implements functions to create matrix and arrange data, and creates the final list with the values
int main() {
    int lines, pSecs ;
    bool check=false;
    int checkCount=0;
    int noRepInd=0;
    int totalItems=0;
    bool extr=false;
    cin>>lines;
    cin>>pSecs;

    string from[13500];
    string to[13500];

    for (int i= 0; i < lines; i++) {
        cin>>from[i];
        fromGlob[i]= from[i];
        cin>>to[i];
        toGlob[i]=to[i];
    }
    int lin=lines;

    for (int i = 0; i < lines ; ++i) {
        lin=lin+ che(lin);
    }

    if(exInd>0)
        extr=true;

    while(check==false){
        for (int i = 0; i < lines ; ++i) {
            if(fromGlob[indexGlob]==""){
                indexGlob++;
            }
        }
        noRepArr[noRepInd]=fromGlob[indexGlob];
        int rep=Repeat(noRepArr[noRepInd] , lines);
        repsGlob[noRepInd]=rep;
        noRepInd++;

        for (int i = 0; i < lines; ++i) {
            if(fromGlob[i]!="")
                checkCount++;
        }

        if(checkCount==0)
            check=true;

        checkCount=0;
    }

    for (int i= 0; i < lines; i++) {
        fromGlob[i]= from[i];
        toGlob[i]=to[i];
    }



    for (int i = 0; i < lines; ++i) {
        if(noRepArr[i]!="")
            totalItems++;

    }

    if(extr==true){
        for (int i = 0; i < exInd; ++i) {
            noRepArr[totalItems]=extra[i];
            lines++;
            totalItems++;
        }
    }

    totalItems=0;

    for (int i = 0; i < lines; ++i) {
        if(noRepArr[i]!="")
            totalItems++;

    }

    for (int i = 0; i < totalItems; ++i) {
        getInfMat(repsGlob[i],totalItems);
        fillMatrix(i,indivTosInde,repsGlob[i]);
    }

    for (int i = 0; i < totalItems; ++i) {
        multo[i][0]=(1.f/totalItems);
    }

    if(pSecs>1){

        for (int i = 0; i < pSecs - 1; ++i) {
            multi2(totalItems);

            for (int i = 0; i < totalItems; ++i) {
                multo[i][0] = mult[i][0];
                mult[i][0]=0;
            }
        }
    }

    string noReps[totalItems];

    for (int i = 0; i < totalItems; ++i) {
        stringstream stream;
        stream<<fixed<<setprecision(2)<< multo[i][0];
        string s= stream.str();
        noReps[i]=noRepArr[i]+" "+s;
    }

    int N = sizeof(noReps)/sizeof(noReps[0]);
    sort(noReps, noReps+N);

    for (int i = 0; i < totalItems ; ++i) {
        cout<<noReps[i]<<endl;
    }

    return 0;}