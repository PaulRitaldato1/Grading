#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Graph{
  private:
    vector< vector<double> > graph;
  public:
    void addRowAndColumn();
    void insertEdge(int from, int to);
    void printGraph();
    double outDegree(int pageIndex);
    void changeWeights();
    void addUnique(string fromPage, string toPage, vector<string> &pageNames);
    vector<double> powerIteration(vector<double> r_t);
};

//Adds an additional row and column when a unique page is taken in from input
void Graph::addRowAndColumn(){
  vector<double> newColumn(graph.size());
  graph.push_back(newColumn);
  for(int i = 0; i < graph.size(); i++){
    graph[i].push_back(0.0);
  }
}

//Inserts an edge onto the adjacency matrix
void Graph::insertEdge(int from, int to){
  graph[to][from] = 1.0;
}

//Prints out graph (for debugging)
void Graph::printGraph(){
  for(int i = 0; i < graph.size(); i++){
    for(int j = 0; j < graph.size(); j++){
      cout << graph[i][j] << " ";
    }
    cout << "\n";
  }
  cout << "\n";
}

//Returns the out degree of a page
double Graph::outDegree(int pageIndex){
  double outDeg = 0.0;
  for(int i = 0; i < graph.size(); i++){
    if(graph[i][pageIndex] > 0.0){
      outDeg++;
    }
  }
  return outDeg;
}

//Changes the weights based on the page's out degree
void Graph::changeWeights(){
  for(int i = 0; i < graph.size(); i++){
    for(int j = 0; j < graph.size(); j++){
      if(graph[i][j] == 1.0){
        double newWeight = 1.0/outDegree(j);
        graph[i][j] = newWeight;
      }
    }
  }
}

//Performs a power iteration
vector<double> Graph::powerIteration(vector<double> r_t){
  vector<double> result;
  result.reserve(r_t.size());
  for(int i = 0; i < r_t.size(); i++){
    double product = 0.0;
    for(int j = 0; j < r_t.size(); j++){
      product += (graph[i][j] * r_t[j]);
    }
    result.push_back(product);
  }
  return result;
}

//Determines if inputs are unique pages or not and will add unique pages onto vector
void Graph::addUnique(string fromPage, string toPage, vector<string> &pageNames){
  bool notUnique1 = false;
  bool notUnique2 = false;
  int fromIndex, toIndex;
  for(int i = 0; i < pageNames.size(); i++){
    if(notUnique1 == true && notUnique2 == true){
      break;
    }
    else{
      if(!notUnique1 && fromPage == pageNames[i]){
        notUnique1 = true;
        fromIndex = i;
      }

      if(!notUnique2 && toPage == pageNames[i]){
        notUnique2 = true;
        toIndex = i;
      }
    }
  }
  if(notUnique1 == false){
    fromIndex = pageNames.size();
    pageNames.push_back(fromPage);
    addRowAndColumn();
  }
  if(notUnique2 == false){
    toIndex = pageNames.size();
    pageNames.push_back(toPage);
    addRowAndColumn();
  }

  insertEdge(fromIndex, toIndex);
}

//Sorts the unique pages into alphabetical order along with their rankings
void insertionSort(vector<string> &pageNames, vector<double> &rankings){
  for(int i = 1; i < pageNames.size(); i++){
      int j = 0;
      while(j < i){
        if(pageNames[i] < pageNames[j]){
          string temp = pageNames[j];
          pageNames[j] = pageNames[i];
          pageNames[i] = temp;

          double r_temp = rankings[j];
          rankings[j] = rankings[i];
          rankings[i] = r_temp;
        }
        j++;
      }
    }
  }

int main(){
  Graph aGraph;
  int numEdges, powerIt;
  vector<string> pageNames;
  vector<double> rankings;
  string from, to;

  cin >> numEdges;
  cin >> powerIt;

  //Exits program if the number of lines and/or the number of power iterations are less than 1
  if(numEdges <= 0 || powerIt <= 0){
    return -1;
  }

  //Adds the from page and to page to a vector that contains all the unique pages
  //Also adds an edge between the from and to page onto the graph
  for(int i = 0; i < numEdges; i++){
    cin >> from;
    cin >> to;
    aGraph.addUnique(from, to, pageNames);
  }

  //The first power iteration uses the rankings vector, which at first will hold
  // 1 over the the total number of pages (r(t))
  for(int i = 0; i < pageNames.size(); i++){
    double size;
    size = 1.0/pageNames.size();
    rankings.push_back(size);
  }

  //Changes the weights based on their out degree
  aGraph.changeWeights();

  //Loop that performs the number of inputted power iterations
  for(int i = 1; i < powerIt; i++){
    rankings = aGraph.powerIteration(rankings);
  }

  //Sorts the pages by alphabetical order with their rankings
  insertionSort(pageNames, rankings);

  //Prints out the pages and their rankings
  for(int i = 0; i < rankings.size(); i++){
    cout << pageNames[i] << " ";
    printf("%.2f\n",rankings[i]);
  }

  return 0;
}
