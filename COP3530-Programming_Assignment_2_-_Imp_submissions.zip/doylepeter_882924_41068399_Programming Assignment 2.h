#include <iostream>
#include <cstring>
#include <iomanip>
#include <cmath>
using namespace std;        


int main()
{
    int loop;
    int pi;
    int count =0;
	cin>>loop>>pi;
    string data[loop][2];
    string inpt;
    string duplicate[loop] = {""};
 
    //This will take the input, store it, and create an array without any duplicates
    
    for(int i =0; i< loop; i++){
        cin>>inpt;
        data[i][0] = inpt;
        
		for(int i=0; i< loop;i++){
            if(inpt == duplicate[i])
                break;
            if(duplicate[i] == ""){
                duplicate[i] = inpt;
                count++;
                break;
            }
        }    
        
        cin>>inpt;
        data[i][1] = inpt;
        
		for(int i=0; i< loop;i++){
            if(inpt == duplicate[i])
                break;
            if(duplicate[i] == ""){
                duplicate[i] = inpt;
                count++;
                break;
            }
        } 
    }
	
	//This will transfer the data holding the non-duplicate data into an array of the correct size
	string noDup[count];
	
    for(int i=0; i< count; i++){
        noDup[i] = duplicate[i];
    }
    
	//This will put the websites in the correct alphabetical order
    bool swap = true;
    int pos =0;
	int location;
    string temp, sr1, sr2;
    
    while(swap){
        swap = false;
        pos++;
        for(int i=0; i < count - pos; i++){
            sr1 = noDup[i];
            sr2 = noDup[i+1];
            if(sr1[0] > sr2[0]){
                temp = noDup[i];
                noDup[i] = noDup[i+1];
                noDup[i+1] = temp;
                swap = true;                
            }
			location =0;
			while(sr1[location] == sr2[location] && sr1.length()!= location && sr2.length() !=location){
				location++;
				if(sr1[location]>sr2[location]){
					temp = noDup[i];
					noDup[i] = noDup[i+1];
					noDup[i+1] = temp;
					swap = true;  
				}
			}
        }   
    }
      
    
    
	
    double matrix[count][count];
    
    for(int i=0; i<count; i++){
        for(int r=0; r<count;r++)
            matrix[i][r] = 0;
    }
    
    double ofactor[count] = {0};
    
	//This will determine the out-factor of all the elements
    for(int i=0; i<count; i++){
        for(int r=0; r< loop; r++){
            if(noDup[i] == data[r][0]){
                ofactor[i] +=1;
            }
        }
    }
    
	//This will load the data into the matrix determine what elements connet
    int to=0;
    int from=0;
    double in;
    string tempt, tempf;
    for(int i=0; i< loop; i++){
        tempt = data[i][1];
        tempf = data[i][0];
        
        for(int r = 0; r< count; r++){
            if(noDup[r] == tempt)
                to = r;
            if(noDup[r] == tempf)
                from = r;
        }
        
        in = double(1)/ofactor[from];
        matrix[to][from] = in;   
    }
    
    
	//This will convert the array to being 1/#number of elements
    for(int i=0; i< count; i++)
        ofactor[i] = (double(1)/count);
    
	//This is the final array
	double finaldat[count];
	
	//This will be the matrix multiplication
	double compNum;
    if(pi ==1)
        for(int i=0; i< count; i++)
            finaldat[i] = ofactor[i];
    
    //This does the matrix multiplication for when it occurs once
    else if(pi == 2){
		for(int i=0; i<count;i++){
			compNum =0;
			for(int r=0;r<count;r++){
				compNum += matrix[i][r] * ofactor[r];
			}
			finaldat[i] = compNum;
		}
    }
    
	//This will loop mutiplying the matrix together as many times as is required
    else if(pi > 2){
        double finalmatrix[count][count];
		for(int i=0; i<count; i++){
			for(int r=0; r<count;r++)
				finalmatrix[i][r] = 0;
		}
		
		
		for(int i=0; i<count;i++){
			for(int r=0;r<count;r++){
				compNum=0;
				for(int t=0;t<count;t++)
					compNum += matrix[i][t] * matrix[t][r];
				
				finalmatrix[i][r] = compNum;
			}
		}
		
		pi -= 3;
		double matrixWork[count][count];
		for(int i=0; i<count; i++){
			for(int r=0; r<count;r++)
				matrixWork[i][r] = finalmatrix[i][r];
			
		//This will loop the until all the matrix multiplication has been complete
		}
		while(pi > 0){
			
			for(int i=0; i<count;i++){
				for(int r=0;r<count;r++){
					compNum =0;
					for(int t=0; t< count; t++)
						compNum += matrixWork[i][t] * matrix[t][r];
					
					finalmatrix[i][r] = compNum;
				}
			}

			for(int i=0; i<count; i++){
				for(int r=0; r<count;r++)
					matrixWork[i][r] = finalmatrix[i][r];
			}
			pi--;
		}
		
		
        for(int i=0; i<count;i++){
			compNum =0;
			for(int r=0;r<count;r++){
				compNum += finalmatrix[i][r] * ofactor[r];
			}
			finaldat[i] = compNum;
		}
    }
	
	//Printing the result
	for(int i=0; i<count; i++){
        cout<<noDup[i]<< " ";
		cout<<setprecision(2)<<fixed<<finaldat[i] << "\n";
    }
	
}