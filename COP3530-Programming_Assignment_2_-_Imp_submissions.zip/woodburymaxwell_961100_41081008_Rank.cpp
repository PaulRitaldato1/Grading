#include <iostream>
#include <cstring>
#include <cmath>
#include <iomanip>
using namespace std;

int main()
{
    int size;
    cin >> size;

    if(!cin)
        return 0;

    const int s = size;
    int numIter;
    cin >> numIter;

    if(numIter < 1)
        return 0;

    //create array of websites and array representing the connections
    string * sites = new string[s*2];
    string * map = new string[s*2];
    bool added = false;
    string temp;
    int pos = 0;
    int count = 0;
    for(int i = 0; i < size*2; i++) {
        cin >> temp;
        map[i] = temp;
        count++;
        for(int j = 0; j < size*2; j++){
            if(temp == sites[j]){
                added = true;
            }
        }
        if(!added){
            sites[pos] = temp;
            pos++;
        }
        added = false;
        //if size is too large
        if(!cin)
            return 0;
    }

    string temp1;
    cin >> temp1;
    //if size is too small
    if(!temp1.empty())
        return 0;

    //take away repeats from map
    for(int i = 0; i < size*2-1; i+=2) {
        for(int j = i; j < size*2-3; j+=2) {
            if(map[i] == map[j+2] && map[i+1] == map[j+3]) {
                map[j+2] = "";
                map[j+3] = "";
            }
        }
    }

    int num = 0;
    for(int i = 0; i < size*2; i++) {
        if(sites[i] != "")
            num++;
    }

    //find outdegree for each element in the sites array
    int outDegrees[s*2] = {};
    for(int i = 0; i < size*2; i+=2) {
        for(int j = 0; j < num; j++) {
            if(map[i] == sites[j]){
                outDegrees[j] += 1;
            }
        }
    }

    //create adjacency matrix
    double matrix[num][num] = {};

    int pos1, pos2;
    for(int i = 0; i < size*2; i+=2) {
        //traverse through map pairs
        for(int j = 0; j < num; j++){
            //find unique codes in sites array
            if(map[i] == sites[j])
                pos1 = j;
            if(map[i+1] == sites[j])
                pos2 = j;
        }
        //plot point in matrix
        matrix[pos2][pos1] = 1.0/outDegrees[pos1];
    }

    double ranks[num] = {0};
    for(int i = 0; i < num; i++){
        ranks[i] = 1.0/num;
    }

    double newMatrix[num][num] = {};
    for(int i = 0; i < num; i++) {
        for(int j = 0; j < num; j++){
            newMatrix[i][j] = matrix[i][j];
        }
    }

    double currMatrix[num][num] = {};
    for(int i = 0; i < num; i++) {
        for(int j = 0; j < num; j++){
            currMatrix[i][j] = matrix[i][j];
        }
    }

    double value = 0;
    while(numIter > 2) {
        //multiply newMatrix with matrix numIter # of times
        for(int i = 0; i < num; i++) {
            for(int j = 0; j < num; j++) {
                newMatrix[i][j] = 0;
                for(int k = 0; k < num; k++) {
                    newMatrix[i][j] += currMatrix[i][k]*matrix[k][j];
                }
            }
        }

        for(int i = 0; i < num; i++) {
            for(int j = 0; j < num; j++){
                currMatrix[i][j] = newMatrix[i][j];
            }
        }
        numIter--;
    }

    //now newMatrix is the final matrix after iterations
    double product[num] = {0};
    for(int i = 0; i < num; i++) {
        for(int j = 0; j < num; j++){
            product[i] += newMatrix[i][j]*ranks[j];
        }
    }

    if(numIter == 1) {
        for(int i = 0; i < num; i++) {
            product[i] = ranks[i];
        }
    }

    //sort sites and product alphabetically
    string curr;
    double val;
    for(int i = 1; i < num; i++) {
		for(int j = 1; j < num; j++) {
			if(sites[j-1] > sites[j]) {
                //swap sites
				curr = sites[j-1];
				sites[j-1] = sites[j];
				sites[j] = curr;
                //swap product
                val = product[j-1];
                product[j-1] = product[j];
                product[j] = val;
			}
		}
	}

    //rounding to hundredths place and printing
    double round = 0.01;
    for(int i = 0; i < num; i++) {
        product[i] = floor(product[i]/round + 0.5) * round;
        cout << sites[i] << " ";
        cout << fixed << setprecision(2) << product[i] << endl;
    }
    return 0;
}
