#include <iostream>
#include <string>
#include <map>
#include <list>
#include <iomanip>

//these are some global variables I will be using
int numLines, numIterations; //number of lines of graph connections
std::map<std::string, int> table; //map from URLs to number IDS
std::map<int,int> outdegrees; //map from number IDs to outdegress for those respective IDs
int count = 0; //counts number of unique IDs/nodes
int** graphTable; //will store the graph connections to be later read into an adjacency matrix, after the number of unique IDs/nodes is determined
float** adjMatrix; //adjacency matrix (num nodes * num nodes) that will store not only graph connections but correct pagerank weight, will represent the matrix M
float *pageRank; //pageRank matrix (num nodes * 1) that will store pagerank results


void takeFirstLine() { //first take in number of lines and number of power iterations
    std::cin >> numLines >> numIterations;
}

void initTable() { //create dynamic 2D table for graph connections to be stored in
    graphTable = new int*[numLines];
    for (int i = 0; i < numLines; i++) {
        graphTable[i] = new int[2];
    }
}

void takeInput() { //takes in graph inputs
    for (int i = 0; i < numLines; i++) {
        std::string first, second;
        std::cin >> first >> second;

        //maps the strings to number IDs
        if (table.find(first) == table.end()) {
            table.insert({first, count});
            count++;
        }
        if (table.find(second) == table.end()) {
            table.insert({second, count});
            count++;
        }

        //stores graph connection into graph table
        graphTable[i][0] = table.find(first)->second;
        graphTable[i][1] = table.find(second)->second;

        //also calculates the number of outdegrees for nodes with outdegrees and updates each time a new connection is found
        if (outdegrees.find(graphTable[i][0]) == outdegrees.end()) {
            outdegrees.insert({graphTable[i][0], 1});
        }
        else {
            std::map<int,int>::iterator it = outdegrees.find(graphTable[i][0]);
            int numOut = it->second;
            numOut++;
            outdegrees[graphTable[i][0]] = numOut;


        }
    }

}

void initMatrices() { //creates dynamic matrices, one for the matrix M and the other for the pagerank vector/1D matrix
    adjMatrix = new float*[count]; //creates dynamic 2D matrix to store graph connection with pagerank algorithm weights
    for (int i = 0; i < count; i++) {
        adjMatrix[i] = new float[count];
    }
    for (int i = 0; i < count; i++) {//inits all values to 0 in the beginning
        for (int j = 0; j < count; j++) {
            adjMatrix[i][j] = 0;
        }
    }


    pageRank = new float[count]; //creates dynamic 1D matrix/vector for pagerank results
    for (int i = 0; i < count; i++) {//inits to 1/numNodes
        pageRank[i] = (1/(float)count);
    }

}

void calculateAdjMatrix() { //calculates the adj matrix M
    for (int i = 0; i < numLines; i++) {
        int first = graphTable[i][0];
        int second = graphTable[i][1];
        int numOut = outdegrees[first];
        adjMatrix[second][first] += (1/(float)numOut); //if there is a connection, put it into adj Matrix with the division by outdegrees of that outputting node
    }
}

void powerIterate() { //calculates power iterations for pagerank, does matrix multiplication
    float *tempPageRank = new float[count]; //stores temporary pagerank result values
    for (int a = 1; a < numIterations; a++) {//outer loop for number of power iterations
        for (int i = 0; i < count; i++) {
            float result = 0;
            for (int j = 0; j < count; j++) {
                result += adjMatrix[i][j]*pageRank[j]; //multiplication here
            }
            tempPageRank[i] = result;
        }
        for (int i = 0; i < count; i++) { //copies temporary pagerank into pagerank
            pageRank[i] = tempPageRank[i];
        }

    }
    delete[] tempPageRank; //when done deallocate temporary pagerank
}

void outputResults() { //outputs results
    std::cout << std::showpoint;
    std::cout << std::fixed;
    for (std::map<std::string, int>::iterator it = table.begin(); it != table.end(); it++ ) { //map is already ordered, so use table map to get number ID, to get pagerank value
        std::cout << it->first << " " << std::setprecision(2) << pageRank[it->second] << std::endl;
    }

}

void deleteMatrices() { //deallocates the global dynamic arrays
    for (int i = 0; i < numLines; i++) {
        delete[] graphTable[i];
    }
    delete graphTable;

    delete[] pageRank;

    for (int i = 0; i < count; i++) {
        delete[] adjMatrix[i];
    }
    delete[] adjMatrix;
}

int main() { //main

    //calls each method once
    takeFirstLine();
    initTable();
    takeInput();
    initMatrices();
    calculateAdjMatrix();
    powerIterate();
    outputResults();
    deleteMatrices();

    return 0;
}

