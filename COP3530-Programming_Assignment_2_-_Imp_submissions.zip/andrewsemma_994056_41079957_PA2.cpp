#include <iostream>
#include <iomanip> //used for std::precision to set the decimal to always be 2 decimal places
#include <string>
#include <vector>
#include <algorithm> //used for std::sort
#include <map>

//Class so that I can use these methods and have a graph
class Rank {
    public:
       void insertEdge(int in, int out, int outdegree);
       void rank(int numVertices, int iters, std::vector<std::string> links);
    private:
        const static int size = 100; //arrays need to be sized beforehand so I just picked the value of 100 to be safe, nothing should be greater than that
        double graph[size][size];
};

void Rank::insertEdge(int start, int end, int outdegree) {
    //checks for outdegree of 0 so we dont have divide by zero errors (I don't think it's possible to have an outdegree of zero, but you never know)
    if (outdegree == 0) {
        std::cout << "Outdegree cannot be zero, edge not added" << std::endl;
    }
    else {
        //inserts an edge into the graph where the rows are the vertex it is directed to and the columns are the the vertex it is directed from
        graph[end][start] =  1.0 / (double)outdegree;
        //sets the value of the edge to be 1 divided by the outdegree of the start vertex
    }
}

void Rank::rank(int numVertices, int iters, std::vector<std::string> links) {
    double result[numVertices]; //array that is the multiplier r(t) in M*r(t)
    double temp[numVertices]; //temp array when performing multiplication
    for (int i = 0; i < numVertices; i++) {
        //initializes the result to contain values of 1/vertices for the first multiplication
        result[i] = 1 / (double)numVertices;
    }
    int k = 1; //loop for n-1 iterations to get the rank result
    while (k < iters) {
        for (int i = 0; i < numVertices; i++) {
            double sum = 0; //matrix multiplication is row in M times column in r(t), adding up each entry after multiplication
            for (int j = 0; j < numVertices; j++) {
                sum += (graph[i][j] * result[j]);
            }
            temp[i] = sum; //hang onto sum value from the result of one row/column calculation, store it in appropriate edge row
        }
        for (int i = 0; i < numVertices; i++) {
            result[i] = temp[i]; //assign all the temp values back into result now that multiplication is done, used for next iteration
        }
        k++;
    }
    for (int i = 0; i < numVertices; i++) {
        //prints the appropriate edge and its rank set to a fixed precision of 2 decimal places
        std::cout << links[i] << " ";
        std::cout << std::setprecision(2)  << std::fixed << result[i] << std::endl;
    }

}

int main() {
    int lines = 0;
    int iters = 0;
    std::cin >> lines; //take in the number of edges total
    std::cin >> iters; //take in the number of iterations to perform to determine rank

    while (lines <= 0) {
        std::cout << "Invalid number of edges, please enter a valid number." << std::endl;
        std::cin >> lines;
    }

    while (iters <= 0) {
        std::cout << "Invalid number of iterations, please enter a valid number." << std::endl;
        std::cin >> iters;
    }

    std::string matrix[lines][2]; //holds all edges that are inputted
    std::vector<std::string> v; //used to get each unique edge that exists in the matrix later on
    std::map<std::string, int> m; //maps each unique url to a unique id

    for (int i = 0; i < lines; i++) {
        std::cin >> matrix[i][0]; //takes in the starting and ending edges, pushes each into the vector
        std::cin >> matrix[i][1];
        v.push_back(matrix[i][0]);
        v.push_back(matrix[i][1]);
    }

    //sorts the vector of all edges in alphabetical order
    std::sort(v.begin(), v.end());
    //removes duplicates from the entire vector, now left with each unique vertex in the graph
    v.erase(std::unique(v.begin(), v.end()), v.end());

    for (unsigned i = 0; i < v.size(); i++) {
        //inserts each unique vertex into the map along with its id to use to determine the edges in the adjacency matrix of being what vertex
        m.insert(std::pair<std::string, int> (v[i], i));
    }

    Rank r = Rank();

    for (int i = 0; i < lines; i++) {
        int outdegree = 0;
        for (int j = 0; j < lines; j++) {
            if (matrix[i][0] == matrix [j][0]) //counts how many times the start vertex is a starting vertex, is the outdegree
                outdegree++;
        }
        int start;
        int end;
        for(std::map<std::string, int>::iterator itr = m.begin(); itr != m.end(); itr++) {
            //iterate through the map to find the ids for the start and ending vertex so we can insert the edges there based on the ids
            if (itr->first == matrix[i][0]) //column 0 holds the starting vertices, first holds the names of the vertices
                start = itr->second; //second hold the id of the vertices
            else if (itr->first == matrix[i][1]) //column 1 holds the ending vertices
                end = itr->second;
        }
        r.insertEdge(start, end, outdegree);
    }
    std::map<std::string, int>::iterator itr = m.end();
    itr--; //find the last pair in the map, which is at end - 1
    int numVertices = itr->second + 1; //take the id of the last vertex in the map and add one to get the total number of vertices (ids start at 0)
    r.rank(numVertices, iters, v); //calculates the rank

    return 0;
}