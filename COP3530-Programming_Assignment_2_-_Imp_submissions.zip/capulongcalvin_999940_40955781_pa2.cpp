#include <iostream>
#include <queue>
#include <string>
#include <unordered_map>
#include <map>
#include <iomanip>

class Graph
{
	const static int MAXVERTICES = 100;
	double graph[MAXVERTICES][MAXVERTICES];
public:

	Graph()
	{
	}

	//Sets each edge to 1
	void insertEdge(int to, int from) {
		graph[from][to] = 1.0;
	}

	//Returns value of edge
	double getEdge(int a, int b) {
		return graph[a][b];
	}

	//Counts the number of "out" edges and sets each edge to 1/out
	void adjustWeights(int count) {
		for (int i = 1; i < count; i++) {
			double num = 0.0;

			for (int j = 1; j < count; j++) {
				if (graph[j][i] == 1)
					num += 1.0;
			}

			for (int j = 1; j < count; j++) {
				if (graph[j][i] == 1)
					graph[j][i] = (1.0 / num);
			}
		}
	}
};





int main()
{
	Graph *AMatrix = new Graph();
	int numEdges, rank;
	std::string inVert, outVert;
	std::cin >> numEdges;
	std::cin >> rank;

	//Maps each website name to its integer position on the graph and its rank value
	std::unordered_map<std::string, int> sites;
	std::map<std::string, double> ranks;
	double siteIndex = 1.0;

	//Scan inputs and places them into the maps and the graph
	for (int i = 0; i < numEdges; i++)
	{
		std::cin >> inVert;
		std::cin >> outVert;

		if (sites.find(inVert) == sites.end()) {
			sites[inVert] = siteIndex;
			ranks[inVert] = 1.0;
			siteIndex++;
		}
		if (sites.find(outVert) == sites.end()) {
			sites[outVert] = siteIndex;
			ranks[outVert] = 1.0;
			siteIndex++;
		}

		//Each edge on the adjacency matrix is initially set to 1.
		AMatrix->insertEdge(sites[inVert], sites[outVert]);
	}

	//Adjusts edges on the adjacency matrix from 1 to their true rank.
	AMatrix->adjustWeights(siteIndex);

	//Initializes the rank matrix by setting all of its values to 1/(numberOfSites)
	double rankMatrix[100][1];
	for (int i = 1; i < siteIndex; i++)
		rankMatrix[i][1] = (1.0 / (siteIndex - 1.0));

	//Multiplies the rank matrix with the adjacency matrix
	//Repeated by the given power iteration
	int temp = 1;
	while (temp != rank) {
		double tempMat[100][1];
		for (int i = 1; i < siteIndex; i++) {
			double sum = 0.0;
			for (int j = 1; j < siteIndex; j++) {
				double a = AMatrix->getEdge(i, j);
				double b = rankMatrix[j][1];
				sum += (a * b);
			}
			tempMat[i][1] = sum;
		}

		for (int k = 1; k < 100; k++)
			rankMatrix[k][1] = tempMat[k][1];

		temp++;
	}

	//Sets the output precision to two decimal places
	std::cout << std::fixed;
	std::cout << std::setprecision(2);

	//Adjusts the values of the rank map to the final rank values
	std::map<std::string, double>::iterator iterator;
	for (iterator = ranks.begin(); iterator != ranks.end(); iterator++) {
		ranks[iterator->first] = rankMatrix[sites[iterator->first]][1];
	}

	//Output the website names and their given ranks
	for (iterator = ranks.begin(); iterator != ranks.end(); iterator++) {
		std::cout << iterator->first << " " << iterator->second << "\n";
	}
}