//
//  main.cpp
//  Project 4
//
//  Created by Mark Lawrence on 11/28/18.
//  Copyright © 2018 Mark Lawrence. All rights reserved.
//

#include <iostream>
#include <queue>
#include <sstream>
#include <iomanip>

class PageRankGraph
{
    const static int MAXNUMVERTICES = 100;
    double theGraph[MAXNUMVERTICES][MAXNUMVERTICES];
    bool undirected;
    
public:
    PageRankGraph() {
        undirected = false;
    }
    
    void insertEdge(int to, int from, double weight) {
        theGraph[to][from] = weight;
    }
    void printGraph(int numberOfEntries){
        for (int i=0; i<numberOfEntries; i++){
            for (int j=0; j<numberOfEntries; j++){
                double test = theGraph[i][j];
            }

        }
    }
    
    std::vector <double> matrixMultiplication(int sizeOfArray, int numberOfPowerIterations){
        
        std::vector <double> multiplyBy;
        std::vector <double> multiplyByTemp;
        
        //populate multiply by. Start with 1/sizeOfArray
        for(int i=0; i<sizeOfArray; i++){
            multiplyByTemp.push_back(1/double(sizeOfArray));
            multiplyBy.push_back(1/double(sizeOfArray));
        }
        
        for(int i =1; i<numberOfPowerIterations; i++){
            for (int j=0; j<sizeOfArray; j++){
                double sumOfRows = 0;
                for (int k=0; k<sizeOfArray; k++){
                    sumOfRows = sumOfRows+(theGraph[j][k]*multiplyBy[k]);
                }
                multiplyByTemp[j] = sumOfRows;
            }
            multiplyBy = multiplyByTemp;
        }
        return multiplyBy;
    }
};

void printPageRank(std::vector<double> multiplyBy, std::vector<std::string> arrayOfURLs){
    //Prepare to print out the results
    for(int i=0; i<multiplyBy.size(); i++){
        std::ostringstream strs;
        strs << std::setprecision(2) << std::fixed << multiplyBy[i];
        std::string str = strs.str();
        
        arrayOfURLs[i].append(" ");
        arrayOfURLs[i].append(str);
    }
    
    sort (arrayOfURLs.begin(), arrayOfURLs.end());
    
    //Print the results
    for(int i=0; i<arrayOfURLs.size(); i++){
        std::cout<<arrayOfURLs[i]<<std::endl;
    }
}


PageRankGraph populatePageRankGraph(std::vector<std::string> arrayOfURLs, std::vector <std::string> fromPage, std::vector <std::string> toPage){
    PageRankGraph *theGraph = new PageRankGraph();
    //Calculate the weight for each site, then fill out the graph
    for (int i=0; i<arrayOfURLs.size(); i++){
        std::string currentSite = arrayOfURLs[i];
        int weight = 0;
        
        //Checking the weight (how mnay times the site is in fromPage)
        for (int j=0; j<fromPage.size(); j++){
            if(currentSite.compare(fromPage[j]) == 0){
                weight++;
            }
        }
        
        for (int j=0; j<fromPage.size(); j++){
            if(currentSite.compare(fromPage[j]) == 0){
                //find index in the matrix
                for(int k=0; k<arrayOfURLs.size(); k++){
                    if (arrayOfURLs[k].compare(toPage[j])==0){
                        theGraph->insertEdge(k, i, double(1/double(weight)));
                    }
                }
            }
        }
    }
    return *theGraph;
}


int main() {
    PageRankGraph *theGraph = new PageRankGraph();
    int numberOfEntires, numOfPowerIterations;
    std::cout<<"start"<<std::endl;
    std::cin >> numberOfEntires;
    std::cin >> numOfPowerIterations;
    
    
    std::vector <double> multiplyBy;
    std::vector <std::string> arrayOfURLs;
    std::vector <std::string> fromPage;
    std::vector <std::string> toPage;
    bool fromPageChecker = false;
    
    std::string newURL;
    
    std::cin >> newURL;
    arrayOfURLs.push_back(newURL);
    fromPage.push_back(newURL);
   
    
    //Read in data from the user, populate arrayOfURLs, fromPage, and toPage vectors
    for (int i=1; i<numberOfEntires*2; i++){
        bool newEntry = true;
        std::cin >> newURL;
        if (fromPageChecker){
            fromPage.push_back(newURL);
            fromPageChecker = false;
        } else{
            toPage.push_back(newURL);
            fromPageChecker = true;
        }
        
        for (int j=0; j<arrayOfURLs.size(); j++){
            if (arrayOfURLs[j].compare(newURL) == 0){
                newEntry = false;
            }
        }
        if (newEntry){
            arrayOfURLs.push_back(newURL);
        }
    }
    
    *theGraph = populatePageRankGraph(arrayOfURLs, fromPage, toPage);
    multiplyBy = theGraph->matrixMultiplication(arrayOfURLs.size(), numOfPowerIterations);
    printPageRank(multiplyBy, arrayOfURLs);
    
    
}

