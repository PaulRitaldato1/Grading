#include <iostream>
#include "Matrix.h"
#include "Webpage.h"


int main()
{

    unsigned int numVert, powerIt;
    std::cin>>numVert; std::cin>>powerIt;

    //accepts the number of origin points && number of power iterations
    Matrix<std::string, std::string> *tab = new Matrix<std::string, std::string>(2*numVert);
    std::string origin, dest;

    for(int i = 0; i < numVert; i++)
    {
        std::cin>>origin;
        std::cin>>dest;
        tab->insertPair(origin, dest); //will insert the pair into the matrix list and link them together as origin pointing to destination
    }//after this loop, all of the websites will be inputted into the director

    tab->sMatrix();
    tab->mult(powerIt);
    tab->printPageRanks();

  return 0;
}//end of main