#include <iostream>
#include <map>
#include <list>
#include <string>
#include <vector>
#include <iomanip>
#include <set>

bool stringInList(std::list<std::string> ls, std::string str)
{
    std::list <std::string> :: iterator it; 
    for(it = ls.begin(); it != ls.end(); ++it)
    { 
        if ((*it).compare(str) == 0)
        {
            return true;
        } 
    }
    return false;
}

int main(){
    int E, powerOfIterations;
    std::cin >> E;
    std::cin >> powerOfIterations;

    std::string fromUrl, toUrl;
    std::map< std::string, std::list<std::string> > adjacencyList;
    std::set< std::string > urlSet;
    for (int i=0; i<E; i++){
        std::cin >> fromUrl;
        std::cin >> toUrl;
        urlSet.insert(fromUrl);
        urlSet.insert(toUrl);
        if (adjacencyList.count(fromUrl)){
            adjacencyList[fromUrl].push_back(toUrl);
        }
        else{
            std::list<std::string> newList;
            newList.push_back(toUrl);
            adjacencyList[fromUrl]=newList;
        }
    }

    //save url list as an array with their corresponding index
    //NEED TO ADD THE URLS THAT ARE NOT A FROMURL
    int V = urlSet.size();
    std::vector< std::string > allUrls(urlSet.begin(), urlSet.end());
    //std::cout<<V<<std::endl;
    // std::string allUrls[V];
    // std::map <std::string, std::list<std::string> > :: iterator itr; 
    // int index = 0;
    // for (itr = adjacencyList.begin(); itr != adjacencyList.end(); ++itr) 
    // {
    //     allUrls[index] = itr->first;
    //     index += 1;
    // } 

    //convert adjacency list to adjacency matrix
    float adjacencyMatrix[V][V];
    for (int i=0; i<V; i++)
    {
        std::string url = allUrls[i];
        //std::cout<<url;
        if (adjacencyList.count(url)<=0)
        {
            for (int j=0; j<V; j++)
            {
                adjacencyMatrix[j][i] = 0.0;
            }
        }
        else{
            int outDegree = adjacencyList[url].size();
            for (int j=0; j<V; j++)
            {
                //this thing doesnt work
                if (stringInList(adjacencyList[url], allUrls[j]))
                {
                    //std::cout<<allUrls[j];
                    adjacencyMatrix[j][i] = 1.0/outDegree;
                }
                else
                {
                    //std::cout<<"checking";
                    adjacencyMatrix[j][i] = 0.0;
                }
            }
            //std::cout<<std::endl;
        }
    }

    std::vector<float> R;
    std::vector<float> RTemp;
    for (int i=0; i<V; i++)
    {
        R.push_back(1.0/V);
        RTemp.push_back(0.0);
    }

    //power iterations
    for (int i=1; i<powerOfIterations; i++)
    {
        for (int j=0; j<V; j++)
        {
            RTemp.at(j) = 0;
            for (int k=0; k<V; k++)
            {
                RTemp.at(j) += adjacencyMatrix[j][k]*R[k];
            }
        }
        R.swap(RTemp);
    }

    for (int i=0; i<V; i++){
        std::cout << allUrls[i] << " ";
        std::cout << std::fixed << std::setprecision(2) << R[i] << std::endl;
    }

    // for(int i=0; i<V; i++)
    // {
    //     for(int j=0; j<V; j++)
    //     {
    //         std::cout<<adjacencyMatrix[i][j]<<"\t";
    //     }
    //     std::cout<<"\n";
    // }

    // std::map <std::string, std::list<std::string> > :: iterator itrr; 
    // std::cout << "\nThe adjacency list is : \n"; 
    // std::cout << "\tKEY\tELEMENT\n"; 
    // for (itrr = adjacencyList.begin(); itrr != adjacencyList.end(); ++itrr) 
    // { 
    //     std::cout  <<  '\t' << itrr->first<<  '\t';
    //     std::list <std::string> :: iterator it; 
    //     for(it = itrr->second.begin(); it != itrr->second.end(); ++it)
    //     { 
    //         std::cout << ' ' << *it; 
    //     }
    //     std::cout << '\n'; 
    // } 
    // std::cout << std::endl; 

    return 0;
}